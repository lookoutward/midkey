const fs = require('fs');
const path = require('path');

const distDir = path.join(__dirname, '../dist');
const outDir = path.join(__dirname, '../dist');

if (!fs.existsSync(outDir)) {
  fs.mkdirSync(outDir);
}

let html = fs.readFileSync(path.join(distDir, 'index.html'), 'utf8');

// CSS
html = html.replace(/<link rel="stylesheet"[^>]*href="(.+?)"[^>]*>/g, (m, href) => {
  const file = path.join(distDir, href.replace(/^\//,''));
  const css = fs.readFileSync(file, 'utf8');
  return `<style>\n${css}\n</style>`;
});

// JS
html = html.replace(/<script type="module"[^>]*src="(.+?)"><\/script>/g, (m, src) => {
  const file = path.join(distDir, src.replace(/^\//,''));
  const js = fs.readFileSync(file, 'utf8');
  return `<script type="module">\n${js}\n</script>`;
});

fs.writeFileSync(path.join(outDir, 'MidkeyVault.html'), html);

console.log('✅ 单文件HTML生成成功');