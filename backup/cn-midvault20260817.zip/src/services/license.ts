export type LicensePlan = 'free' | 'pro';

export interface LicensePayload {
  v: 1;
  id: string;     // 绑定 Vault ID (全等匹配)
  plan: LicensePlan;
  exp?: string;   // ISO 格式日期
  feats?: string[]; 
  iat?: string;   // 签发时间
}

export interface LicenseStatus {
  valid: boolean;
  reason?: string;
  payload?: LicensePayload;
}

// 你的 Ed25519 公钥 (32 字节 Base64URL)
const PUBLIC_KEY_B64URL = '9ng5oUeYi8FO6n4xq3KcyALPEd87hxj_J5YfVEVVSA8';
const LS_KEY = 'midkey.licenseKey.v1';

/* =========================
   工具函数
========================= */

function b64UrlToBytes(b64url: string): Uint8Array {
  const s = (b64url || '').trim().replace(/\s/g, '');
  let base64 = s.replace(/-/g, '+').replace(/_/g, '/');
  while (base64.length % 4 !== 0) base64 += '=';
  
  const binStr = atob(base64);
  const bytes = new Uint8Array(binStr.length);
  for (let i = 0; i < binStr.length; i++) {
    bytes[i] = binStr.charCodeAt(i);
  }
  return bytes;
}

function isExpired(exp?: string): boolean {
  if (!exp) return false;
  const t = Date.parse(exp);
  return isNaN(t) ? true : t < Date.now();
}

/* =========================
   License Service
========================= */

export const LicenseService = {
  getStoredKey(): string {
    return localStorage.getItem(LS_KEY) || '';
  },

  storeKey(licenseKey: string): void {
    localStorage.setItem(LS_KEY, licenseKey);
  },

  /**
   * 核心验证函数：适配 JSON 格式的长授权码
   * 格式：Base64URL(JSON_Payload).Base64URL(Signature)
   */
  async verifyLicenseKey(licenseKey: string): Promise<LicenseStatus> {
    const key = (licenseKey || '').trim();
    if (!key) return { valid: false, reason: '请输入专业版授权码' };

    // 1. 拆分 Payload 和 Signature
    const parts = key.split('.');
    if (parts.length !== 2) {
      return { valid: false, reason: '授权码格式错误' };
    }
    const [payloadB64, sigB64] = parts;

    let payloadBytes: Uint8Array;
    let sigBytes: Uint8Array;
    let pubBytes: Uint8Array;

    try {
      payloadBytes = b64UrlToBytes(payloadB64);
      sigBytes = b64UrlToBytes(sigB64).slice(0, 64);
      pubBytes = b64UrlToBytes(PUBLIC_KEY_B64URL).slice(0, 32);
    } catch (e) {
      return { valid: false, reason: 'Base64 解码失败' };
    }

    // 2. 使用 Web Crypto API 验证签名
    try {
      const cryptoKey = await window.crypto.subtle.importKey(
        'raw',
        pubBytes,
        { name: 'Ed25519', namedCurve: 'Ed25519' },
        false,
        ['verify']
      );

      // 注意：验证的对象是 payloadB64 字符串的字节
      // 这必须与 a.cjs 中的签名对象 (Buffer.from(payloadB64)) 保持绝对一致
      const ok = await window.crypto.subtle.verify(
        { name: 'Ed25519' },
        cryptoKey,
        sigBytes,
        new TextEncoder().encode(payloadB64) 
      );

      if (!ok) return { valid: false, reason: '签名验证失败' };
      } catch (e: any) 
      {
        const msg = e?.message || String(e)

        // WebCrypto 不支持 / 算法不支持（360常见）
        if (
          msg.includes("Unrecognized name") ||
          msg.includes("Algorithm") ||
          msg.includes("subtle") ||
          msg.includes("importKey")
        ) {
          return {
            valid: false,
            reason: "当前浏览器不支持加密模块(WebCrypto)，请使用 Chrome / Edge / Firefox。"
          }
        }

        // 其它未知错误
        return {
          valid: false,
          reason: "安全模块初始化失败，请更换浏览器或升级浏览器版本。"
        }
      }

    // 3. 解析 JSON 内容 (代替原有的 parsePayloadString)
    try {
      const payload: LicensePayload = JSON.parse(new TextDecoder().decode(payloadBytes));
      
      // 基础验证
      if (payload.v !== 1) throw new Error('版本不匹配');
      if (!payload.id) throw new Error('未绑定设备 ID');

      if (isExpired(payload.exp)) {
        return { valid: false, reason: '授权已过期', payload };
      }

      return { valid: true, payload };
    } catch (e: any) {
      return { valid: false, reason: `JSON 解析失败: ${e.message}` };
    }
  },

  clear(): void {
    localStorage.removeItem(LS_KEY);
  }
};