const crypto = require('crypto');

// --- 配置信息 ---
const PRIVATE_KEY_B64 = 'EwwbC4sXM4hFtrK3pCRt__Du-_bBYn6icVspc9EuUHo';
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

const privBuffer = Buffer.from(PRIVATE_KEY_B64, 'base64url');
const pkcs8Header = Buffer.from([0x30,0x2e,0x02,0x01,0x00,0x30,0x05,0x06,0x03,0x2b,0x65,0x70,0x04,0x22,0x04,0x20]);
const privateKey = crypto.createPrivateKey({
  key: Buffer.concat([pkcs8Header, privBuffer]),
  format: 'der',
  type: 'pkcs8'
});

/**
 * 极致压缩版生成器 (确保 25 位以内)
 */
function generateStrict5x5(shortId, plan, expDate) {
  // 1. 构造紧凑 Payload (6字节 ID + 1字节 Plan + 4字节 时间戳 = 11字节)
  const idBuf = Buffer.alloc(6); 
  idBuf.write(shortId.slice(0, 6), 'utf8');
  
  const infoBuf = Buffer.alloc(5);
  infoBuf.writeUint8(plan === 'pro' ? 1 : 0, 0);
  const ts = Math.floor(new Date(expDate).getTime() / 1000);
  infoBuf.writeUInt32BE(ts, 1);

  const payload = Buffer.concat([idBuf, infoBuf]);

  // 2. 签名并取前 4 字节 (为了凑够总数 15 字节，这样 Base32 刚好 24-25 位)
  const fullSig = crypto.sign(null, payload, privateKey);
  const shortSig = fullSig.slice(0, 4);

  // 3. 合并 (总计 15 字节)
  const finalBuffer = Buffer.concat([payload, shortSig]);

  // 4. 转 Base32
  let bits = '';
  for (const b of finalBuffer) bits += b.toString(2).padStart(8, '0');
  
  let out = '';
  for (let i = 0; i < bits.length; i += 5) {
    out += ALPHABET[parseInt(bits.slice(i, i + 5), 2)];
  }

  return 'MVK-' + out.match(/.{1,5}/g).join('-');
}

/**
 * 对应的验证逻辑
 */
function verifyStrict5x5(licenseKey) {
  const clean = licenseKey.replace(/MVK-/g, '').replace(/-/g, '');
  
  // Base32 解码
  let bits = '';
  for (const c of clean) bits += ALPHABET.indexOf(c).toString(2).padStart(5, '0');
  
  const bytes = [];
  for (let i = 0; i + 8 <= bits.length; i += 8) {
    bytes.push(parseInt(bits.slice(i, i + 8), 2));
  }
  const buf = Buffer.from(bytes);

  if (buf.length < 15) return { isValid: false, reason: '数据残缺' };

  // 拆分
  const payload = buf.slice(0, 11);
  const sigInKey = buf.slice(11, 15);

  // 验证
  const expectedSig = crypto.sign(null, payload, privateKey).slice(0, 4);
  const isValid = sigInKey.equals(expectedSig);

  return {
    isValid,
    data: {
      id: payload.slice(0, 6).toString().replace(/\0/g, ''),
      plan: payload.readUint8(6) === 1 ? 'pro' : 'free',
      exp: new Date(payload.readUInt32BE(7) * 1000).toLocaleString()
    }
  };
}

// --- 测试 ---
const key = generateStrict5x5('JoZSRs', 'pro', '2030-01-01');
console.log('生成的 5x5 Key:', key);

const res = verifyStrict5x5(key);
console.log('结果:', res.isValid ? '✅ 通过' : '❌ 失败');
console.log('解析:', res.data);