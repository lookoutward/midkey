import { CryptoUtil } from './crypto';
import type { DecryptedVault, EncryptedVault, VaultEntry, VaultGroup } from '../types';

export const VaultService = {
  id(prefix = 'id'): string {
    const b = CryptoUtil.randomBytes(16);
    return `${prefix}_${CryptoUtil.bytesToB64(b).replace(/=+/g, '').replace(/[+/]/g, '_')}`;
  },

  nowIso(): string {
    return new Date().toISOString();
  },

  createEmptyDecryptedVault({ name }: { name: string }): DecryptedVault {
    const rootId = this.id('grp');
    return {
      schemaVersion: 1,
      vaultId: this.id('vault'),
      name: name || '未命名密码库',
      createdAt: this.nowIso(),
      updatedAt: this.nowIso(),
      settings: {
        autoLockMinutes: 5,
        clipboardClearSeconds: 20,
      },
      groups: [
        {
          id: rootId,
          name: '根分组',
          parentId: null,
          order: 0,
          createdAt: this.nowIso(),
          modifiedAt: this.nowIso(),
        },
      ],
      rootGroupId: rootId,
      entries: [],
      meta: {},
    };
  },

  wrapEncrypted({
    name,
    kdf,
    cipher,
    factors,
    ciphertextB64,
    vaultId,
    updatedAt,
  }: any): EncryptedVault {
    return {
      format: 'OfflinePasswordManagerVault',
      version: 1,
      name: name || 'Vault',
      vaultId,
      updatedAt,
      kdf,
      cipher,
      factors,
      dataB64: ciphertextB64,
    };
  },

  assertEncryptedShape(obj: any): void {
    if (!obj || obj.format !== 'OfflinePasswordManagerVault' || obj.version !== 1) {
      throw new Error('不是受支持的加密密码库格式');
    }
    if (!obj.kdf?.iterations || !obj.kdf?.saltB64 || !obj.cipher?.ivB64 || !obj.dataB64) {
      throw new Error('加密密码库缺少必要字段');
    }
  },

  async encryptVault({
    decryptedVault,
    masterPassword,
    keyfileBytes,
    iterations,
    saltBytes,
    factors,
  }: any): Promise<EncryptedVault> {
    const kdfMaterial = await CryptoUtil.buildKdfMaterial({ masterPassword, keyfileBytes });
    const key = await CryptoUtil.deriveAesKey({
      kdfMaterial,
      saltBytes,
      iterations,
    });

    const ivBytes = CryptoUtil.randomBytes(12);
    const aadBytes = CryptoUtil.utf8ToBytes(`opm:v1:${decryptedVault.vaultId}`);

    decryptedVault.updatedAt = this.nowIso();

    const ciphertextB64 = await CryptoUtil.encryptJson({
      key,
      ivBytes,
      jsonObj: decryptedVault,
      aadBytes,
    });

    return this.wrapEncrypted({
      name: decryptedVault.name,
      vaultId: decryptedVault.vaultId,
      updatedAt: decryptedVault.updatedAt,
      kdf: {
        name: 'PBKDF2',
        hash: 'SHA-256',
        iterations,
        saltB64: CryptoUtil.bytesToB64(saltBytes),
      },
      cipher: {
        name: 'AES-GCM',
        keyBits: 256,
        ivB64: CryptoUtil.bytesToB64(ivBytes),
      },
      factors: {
        keyfile: !!factors?.keyfile,
      },
      ciphertextB64,
    });
  },

  async decryptVault({
    encrypted,
    masterPassword,
    keyfileBytes,
  }: any): Promise<DecryptedVault> {
    this.assertEncryptedShape(encrypted);

    const saltBytes = CryptoUtil.b64ToBytes(encrypted.kdf.saltB64);
    const ivBytes = CryptoUtil.b64ToBytes(encrypted.cipher.ivB64);
    const iterations = encrypted.kdf.iterations;

    const kdfMaterial = await CryptoUtil.buildKdfMaterial({ masterPassword, keyfileBytes });
    const key = await CryptoUtil.deriveAesKey({ kdfMaterial, saltBytes, iterations });

    const aadBytes = CryptoUtil.utf8ToBytes(`opm:v1:${encrypted.vaultId}`);

    const vault = await CryptoUtil.decryptJson({
      key,
      ivBytes,
      ciphertextB64: encrypted.dataB64,
      aadBytes,
    });

    if (!vault || vault.schemaVersion !== 1 || !Array.isArray(vault.groups) || !Array.isArray(vault.entries)) {
      throw new Error('解密成功但密码库结构无效/已损坏');
    }
    return vault;
  },

  // Data operations
  addGroup(vault: DecryptedVault, { name, parentId }: { name: string; parentId: string | null }): VaultGroup {
    const g: VaultGroup = {
      id: this.id('grp'),
      name: name || '新分组',
      parentId: parentId ?? null,
      order: this.computeNextGroupOrder(vault, parentId ?? null),
      createdAt: this.nowIso(),
      modifiedAt: this.nowIso(),
    };
    vault.groups.push(g);
    vault.updatedAt = this.nowIso();
    return g;
  },

  updateGroup(vault: DecryptedVault, groupId: string, patch: Partial<VaultGroup>): VaultGroup {
    const g = vault.groups.find((x) => x.id === groupId);
    if (!g) throw new Error('分组不存在');
    Object.assign(g, patch);
    g.modifiedAt = this.nowIso();
    vault.updatedAt = this.nowIso();
    return g;
  },

  deleteGroup(vault: DecryptedVault, groupId: string): void {
    if (groupId === vault.rootGroupId) throw new Error('不能删除根分组');
    const hasChildren = vault.groups.some((g) => g.parentId === groupId);
    if (hasChildren) throw new Error('该分组下还有子分组，请先移动/删除子分组');

    const g = vault.groups.find((x) => x.id === groupId);
    if (!g) throw new Error('分组不存在');

    const fallback = g.parentId ?? vault.rootGroupId;
    vault.entries.forEach((e) => {
      if (e.groupId === groupId) e.groupId = fallback;
    });

    vault.groups = vault.groups.filter((x) => x.id !== groupId);
    vault.updatedAt = this.nowIso();
  },

  computeNextGroupOrder(vault: DecryptedVault, parentId: string | null): number {
    const siblings = vault.groups.filter((g) => (g.parentId ?? null) === (parentId ?? null));
    return siblings.length ? Math.max(...siblings.map((s) => s.order ?? 0)) + 1 : 0;
  },

  computeNextEntryOrder(vault: DecryptedVault, groupId: string): number {
    const siblings = vault.entries.filter((e) => e.groupId === groupId);
    return siblings.length ? Math.max(...siblings.map((s) => s.order ?? 0)) + 1 : 0;
  },

  addEntry(vault: DecryptedVault, entry: Partial<VaultEntry>): VaultEntry {
    const now = this.nowIso();
    const e: VaultEntry = {
      id: this.id('ent'),
      title: entry.title || '新条目',
      username: entry.username || '',
      password: entry.password || '',
      url: entry.url || '',
      notes: entry.notes || '',
      tags: Array.isArray(entry.tags) ? entry.tags : [],
      customFields: Array.isArray(entry.customFields) ? entry.customFields : [],
      favorite: !!entry.favorite,
      groupId: entry.groupId || vault.rootGroupId,
      order: this.computeNextEntryOrder(vault, entry.groupId || vault.rootGroupId),
      attachments: Array.isArray(entry.attachments) ? entry.attachments : [],
      createdAt: now,
      modifiedAt: now,
    };
    vault.entries.push(e);
    vault.updatedAt = now;
    return e;
  },

  updateEntry(vault: DecryptedVault, entryId: string, patch: Partial<VaultEntry>): VaultEntry {
    const e = vault.entries.find((x) => x.id === entryId);
    if (!e) throw new Error('条目不存在');
    Object.assign(e, patch);
    e.modifiedAt = this.nowIso();
    vault.updatedAt = this.nowIso();
    return e;
  },

  deleteEntry(vault: DecryptedVault, entryId: string): void {
    vault.entries = vault.entries.filter((x) => x.id !== entryId);
    vault.updatedAt = this.nowIso();
  },

  batchDeleteEntries(vault: DecryptedVault, entryIds: string[]): void {
    const ids = new Set(entryIds);
    vault.entries = vault.entries.filter((x) => !ids.has(x.id));
    vault.updatedAt = this.nowIso();
  },

  listTags(vault: DecryptedVault): string[] {
    const set = new Set<string>();
    vault.entries.forEach((e) => (e.tags || []).forEach((t) => set.add(t)));
    return Array.from(set).sort((a, b) => a.localeCompare(b, 'zh-CN'));
  },

  async addAttachment(
    vault: DecryptedVault,
    entryId: string,
    {
      name,
      size,
      type,
      ivB64,
      dataB64,
      compressed,
    }: {
      name: string;
      size: number;
      type: string;
      ivB64: string;
      dataB64: string;
      compressed: boolean;
    }
  ) {
    const e = vault.entries.find((x) => x.id === entryId);
    if (!e) throw new Error('条目不存在');
    if (!e.attachments) e.attachments = [];

    const att = {
      id: this.id('att'),
      name,
      size,
      type,
      ivB64,
      dataB64,
      compressed,
    };
    e.attachments.push(att);
    e.modifiedAt = this.nowIso();
    vault.updatedAt = this.nowIso();
    return att;
  },

  deleteAttachment(vault: DecryptedVault, entryId: string, attachmentId: string) {
    const e = vault.entries.find((x) => x.id === entryId);
    if (!e) throw new Error('条目不存在');
    e.attachments = e.attachments.filter((a) => a.id !== attachmentId);
    e.modifiedAt = this.nowIso();
    vault.updatedAt = this.nowIso();
  },
};
