import pako from 'pako';

/**
 * Crypto utilities for Midkey Vault
 * AES-256-GCM, PBKDF2, SHA-256
 */

export const CryptoUtil = {
  bytesToB64(bytes: Uint8Array): string {
    let bin = '';
    for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
    return btoa(bin);
  },

  b64ToBytes(b64: string): Uint8Array {
    const bin = atob(b64);
    const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  },

  utf8ToBytes(str: string): Uint8Array {
    return new TextEncoder().encode(str);
  },

  bytesToUtf8(bytes: Uint8Array): string {
    return new TextDecoder().decode(bytes);
  },

  randomBytes(len: number): Uint8Array {
    const b = new Uint8Array(len);
    crypto.getRandomValues(b);
    return b;
  },

  async sha256(bytes: Uint8Array): Promise<Uint8Array> {
    const hash = await crypto.subtle.digest('SHA-256', bytes);
    return new Uint8Array(hash);
  },

  readFileAsArrayBuffer(file: File): Promise<ArrayBuffer> {
    return new Promise((resolve, reject) => {
      const fr = new FileReader();
      fr.onerror = () => reject(new Error('读取文件失败'));
      fr.onload = () => resolve(fr.result as ArrayBuffer);
      fr.readAsArrayBuffer(file);
    });
  },

  async buildKdfMaterial({
    masterPassword,
    keyfileBytes,
  }: {
    masterPassword?: string;
    keyfileBytes?: ArrayBuffer | null;
  }): Promise<string> {
    const parts: string[] = [];
    parts.push(masterPassword ?? '');
    parts.push('\u0000');

    if (keyfileBytes && keyfileBytes.byteLength) {
      const hash = await this.sha256(new Uint8Array(keyfileBytes));
      parts.push(this.bytesToB64(hash));
    } else {
      parts.push('');
    }

    return parts.join('');
  },

  async deriveAesKey({
    kdfMaterial,
    saltBytes,
    iterations,
  }: {
    kdfMaterial: string;
    saltBytes: Uint8Array;
    iterations: number;
  }): Promise<CryptoKey> {
    if (!iterations || iterations < 100000) {
      throw new Error('PBKDF2 迭代次数必须 ≥ 100,000');
    }
    const baseKey = await crypto.subtle.importKey(
      'raw',
      this.utf8ToBytes(kdfMaterial),
      'PBKDF2',
      false,
      ['deriveKey']
    );

    return crypto.subtle.deriveKey(
      {
        name: 'PBKDF2',
        salt: saltBytes,
        iterations,
        hash: 'SHA-256',
      },
      baseKey,
      {
        name: 'AES-GCM',
        length: 256,
      },
      false,
      ['encrypt', 'decrypt']
    );
  },

  async encryptJson({
    key,
    ivBytes,
    jsonObj,
    aadBytes,
  }: {
    key: CryptoKey;
    ivBytes: Uint8Array;
    jsonObj: any;
    aadBytes?: Uint8Array;
  }): Promise<string> {
    const plaintext = this.utf8ToBytes(JSON.stringify(jsonObj));
    const alg: AesGcmParams = { name: 'AES-GCM', iv: ivBytes };
    if (aadBytes) alg.additionalData = aadBytes;

    const ct = await crypto.subtle.encrypt(alg, key, plaintext);
    return this.bytesToB64(new Uint8Array(ct));
  },

  async decryptJson({
    key,
    ivBytes,
    ciphertextB64,
    aadBytes,
  }: {
    key: CryptoKey;
    ivBytes: Uint8Array;
    ciphertextB64: string;
    aadBytes?: Uint8Array;
  }): Promise<any> {
    const ctBytes = this.b64ToBytes(ciphertextB64);
    const alg: AesGcmParams = { name: 'AES-GCM', iv: ivBytes };
    if (aadBytes) alg.additionalData = aadBytes;

    let pt;
    try {
      pt = await crypto.subtle.decrypt(alg, key, ctBytes);
    } catch (e) {
      throw new Error('解密失败：主密码/因子错误或密码库已损坏');
    }
    const json = this.bytesToUtf8(new Uint8Array(pt));
    return JSON.parse(json);
  },

  estimatePasswordStrength(pw: string): { score: number; bits: number; label: string } {
    const s = pw || '';
    let pool = 0;
    if (/[a-z]/.test(s)) pool += 26;
    if (/[A-Z]/.test(s)) pool += 26;
    if (/[0-9]/.test(s)) pool += 10;
    if (/[^A-Za-z0-9]/.test(s)) pool += 33;
    if (pool === 0) return { score: 0, bits: 0, label: '空' };

    const bits = Math.log2(pool) * s.length;
    let score = 0;
    if (bits > 20) score = 1;
    if (bits > 35) score = 2;
    if (bits > 55) score = 3;
    if (bits > 75) score = 4;

    const labels = ['很弱', '弱', '一般', '强', '很强'];
    return { score, bits: Math.round(bits), label: labels[score] };
  },

  generatePassword({
    length,
    upper,
    lower,
    nums,
    syms,
  }: {
    length: number;
    upper: boolean;
    lower: boolean;
    nums: boolean;
    syms: boolean;
  }): string {
    const U = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const L = 'abcdefghijklmnopqrstuvwxyz';
    const N = '0123456789';
    const S = '!@#$%^&*()-_=+[]{};:,.<>/?|~';

    let chars = '';
    if (upper) chars += U;
    if (lower) chars += L;
    if (nums) chars += N;
    if (syms) chars += S;
    if (!chars) throw new Error('至少选择一种字符集');

    const out: string[] = [];
    const rnd = this.randomBytes(length);
    for (let i = 0; i < length; i++) {
      out.push(chars[rnd[i] % chars.length]);
    }
    return out.join('');
  },

  async encryptAttachment({
    key,
    file,
    compress = true,
  }: {
    key: CryptoKey;
    file: File;
    compress?: boolean;
  }): Promise<{ ivB64: string; dataB64: string; compressed: boolean }> {
    let data = new Uint8Array(await this.readFileAsArrayBuffer(file));
    let isCompressed = false;

    if (compress) {
      try {
        data = pako.deflate(data);
        isCompressed = true;
      } catch (e) {
        console.warn('压缩失败，将使用原始数据', e);
      }
    }

    const ivBytes = this.randomBytes(12);
    const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv: ivBytes }, key, data);

    return {
      ivB64: this.bytesToB64(ivBytes),
      dataB64: this.bytesToB64(new Uint8Array(ct)),
      compressed: isCompressed,
    };
  },

  async decryptAttachment({
    key,
    ivB64,
    dataB64,
    compressed,
  }: {
    key: CryptoKey;
    ivB64: string;
    dataB64: string;
    compressed: boolean;
  }): Promise<Uint8Array> {
    const ivBytes = this.b64ToBytes(ivB64);
    const ctBytes = this.b64ToBytes(dataB64);

    const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: ivBytes }, key, ctBytes);
    let data = new Uint8Array(pt);

    if (compressed) {
      data = pako.inflate(data);
    }

    return data;
  },
};
