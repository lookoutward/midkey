export interface KdfConfig {
  name: string;
  hash: string;
  iterations: number;
  saltB64: string;
}

export interface CipherConfig {
  name: string;
  keyBits: number;
  ivB64: string;
}

export interface FactorsConfig {
  passphrase: boolean;
  keyfile: boolean;
}

export interface EncryptedVault {
  format: 'OfflinePasswordManagerVault';
  version: number;
  name: string;
  vaultId: string;
  updatedAt: string;
  kdf: KdfConfig;
  cipher: CipherConfig;
  factors: FactorsConfig;
  dataB64: string;
}

export interface CustomField {
  key: string;
  value: string;
}

export interface Attachment {
  id: string;
  name: string;
  size: number;
  type: string;
  ivB64: string;
  dataB64: string;
  compressed: boolean;
}

export interface PasswordHistoryItem {
  password: string;
  date: string;
}

export interface VaultEntry {
  id: string;
  title: string;
  username: string;
  password: string;
  url: string;
  notes: string;
  tags: string[];
  customFields: CustomField[];
  favorite: boolean;
  groupId: string;
  order: number;
  attachments: Attachment[];
  createdAt: string;
  modifiedAt: string;
  passwordHistory?: PasswordHistoryItem[];
}

export interface VaultGroup {
  id: string;
  name: string;
  parentId: string | null;
  order: number;
  createdAt: string;
  modifiedAt: string;
}

export interface VaultSettings {
  autoLockMinutes: number;
  clipboardClearSeconds: number;
}

export interface DecryptedVault {
  schemaVersion: number;
  vaultId: string;
  name: string;
  createdAt: string;
  updatedAt: string;
  settings: VaultSettings;
  groups: VaultGroup[];
  rootGroupId: string;
  entries: VaultEntry[];
  meta: Record<string, any>;
}
