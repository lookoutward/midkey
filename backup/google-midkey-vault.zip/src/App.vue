<script setup lang="ts">
import { ref, reactive, onMounted, computed, watch } from 'vue';
import { 
  Lock, Unlock, Settings, LogOut, Plus, Star, Search, Trash2, 
  Copy, Eye, EyeOff, ChevronRight, Folder, Tag, Download, Save,
  Sun, Moon, Shield, FileJson, Edit, GripVertical, Heart, Sparkles, Menu, HelpCircle, Database, Paperclip, File as FileIcon, User
} from 'lucide-vue-next';
import { CryptoUtil } from './services/crypto';
import { VaultService } from './services/vault';
import { LicenseService } from './services/license';
import type { DecryptedVault, EncryptedVault, VaultEntry, VaultGroup, CustomField } from './types';

// --- State ---
const isUnlocked = ref(false);
const isLightMode = ref(false);
const encryptedVault = ref<EncryptedVault | null>(null);
const vault = ref<DecryptedVault | null>(null);
const fileName = ref('未选择文件');
const fileHandle = ref<any>(null);

const auth = reactive({
  masterPassword: '',
  keyfile: null as File | null,
  useKeyfile: false,
  newVaultName: '',
  newMaster: '',
  newMaster2: '',
  newKeyfile: null as File | null,
  kdfIterations: 200000,
});

const ui = reactive({
  currentGroupId: null as string | null,
  currentEntryId: null as string | null,
  showFavorites: false,
  searchQuery: '',
  tagFilter: '',
  unlockMsg: { text: '请先点击“打开 Vault”选择 JSON 文件，然后输入主密码解锁。', type: 'info' },
  createMsg: { text: '', type: 'info' },
  showJsonModal: false,
  jsonContent: '',
  showSettings: false,
  showEntryModal: false,
  showGroupModal: false,
  showLogoutConfirm: false,
  showMobileMenu: false,
  showPrivacyModal: false,
  showHelpModal: false,
  helpTab: 'usage' as 'usage' | 'faq',
  mobileTab: 'groups' as 'groups' | 'entries',
  isDirty: false,
  editingEntryId: null as string | null,
  editingGroupId: null as string | null,
  draggedGroupId: null as string | null,
  draggedEntryId: null as string | null,
  settingsTab: 'security' as 'info' | 'security' | 'about',
  tempVaultName: '',
  vaultNameMsg: '',
  vaultNameMsgType: 'info' as 'info' | 'error' | 'ok',
  keyfileMsg: '',
  keyfileMsgType: 'info' as 'info' | 'error' | 'ok',
  isProcessingAttachment: false,
  selectedEntryIds: [] as string[],
  showHistoryIdx: -1,
  changePw: {
    old: '',
    new: '',
    confirm: '',
    msg: '',
    msgType: 'info' as 'info' | 'error' | 'ok'
  }
});

const entryForm = reactive({
  title: '',
  username: '',
  password: '',
  url: '',
  notes: '',
  tags: '',
  favorite: false,
  groupId: '',
  customFields: [] as CustomField[],
  showPassword: false,
});

const groupForm = reactive({
  name: '',
  parentId: null as string | null,
});

const generator = reactive({
  length: 16,
  upper: true,
  lower: true,
  nums: true,
  syms: true,
  output: '',
});

// --- Computed ---
const filteredEntries = computed(() => {
  if (!vault.value) return [];
  let list = [...vault.value.entries];

  if (ui.showFavorites) {
    list = list.filter(e => e.favorite);
  } else if (ui.currentGroupId) {
    list = list.filter(e => e.groupId === ui.currentGroupId);
  }

  if (ui.tagFilter) {
    list = list.filter(e => e.tags.includes(ui.tagFilter));
  }

  const q = ui.searchQuery.trim().toLowerCase();
  if (q) {
    list = list.filter(e => {
      const hay = [
        e.title, e.username, e.url, e.notes,
        ...e.tags,
        ...e.customFields.flatMap(cf => [cf.key, cf.value])
      ].join('\n').toLowerCase();
      return hay.includes(q);
    });
  }

  return list.sort((a, b) => a.order - b.order);
});

const groupTree = computed(() => {
  if (!vault.value) return [];
  const groups = vault.value.groups;
  const tree: (VaultGroup & { depth: number })[] = [];
  
  const walk = (parentId: string | null, depth: number) => {
    const children = groups.filter(g => g.parentId === parentId)
      .sort((a, b) => a.order - b.order);
    
    for (const g of children) {
      tree.push({ ...g, depth });
      walk(g.id, depth + 1);
    }
  };
  
  walk(null, 0);
  return tree;
});

const currentEntry = computed(() => {
  return vault.value?.entries.find(e => e.id === ui.currentEntryId);
});

const editingEntry = computed(() => {
  return vault.value?.entries.find(e => e.id === ui.editingEntryId);
});

const allTags = computed(() => {
  if (!vault.value) return [];
  return VaultService.listTags(vault.value);
});

const passwordStrength = computed(() => {
  return CryptoUtil.estimatePasswordStrength(entryForm.password);
});

const canWriteBack = computed(() => {
  return !!fileHandle.value && typeof window.showOpenFilePicker === 'function' && window.isSecureContext;
});

const license = reactive({
  keyInput: '',
  statusText: '',
  statusType: 'info' as 'info' | 'error' | 'ok',
  payload: null as any,
  isPro: false,
});

const refreshLicenseStatus = async () => {
  const stored = LicenseService.getStoredKey();
  if (!stored) {
    license.isPro = false;
    license.payload = null;
    license.statusText = '未授权（免费版）';
    license.statusType = 'info';
    return;
  }
  const st = await LicenseService.verifyLicenseKey(stored);
  if (!st.valid) {
    license.isPro = false;
    license.payload = st.payload || null;
    license.statusText = `授权无效：${st.reason || '未知原因'}`;
    license.statusType = 'error';
    return;
  }

  // ⭐ 新增：Vault绑定校验
  if (st.payload?.id !== vault.value?.vaultId) {
    license.isPro = false;
    license.payload = st.payload;
    license.statusText = 'License 不属于当前 Vault';
    license.statusType = 'error';
    return;
  }
  
  license.payload = st.payload || null;
  license.isPro = st.payload?.plan === 'pro';
  license.statusText = license.isPro ? '已授权：Pro' : '已授权：Free';
  license.statusType = 'ok';
};

const verifyAndActivateLicense = async () => {
  try {
    license.statusText = '正在验证授权...';
    license.statusType = 'info';
    const st = await LicenseService.verifyLicenseKey(license.keyInput);
    if (!st.valid) {
      license.statusText = st.reason || '授权无效';
      license.statusType = 'error';
      return;
    }
    // ⭐ 新增：Vault绑定校验
    if (st.payload?.id !== vault.value?.vaultId) {
      license.statusText = 'License 不属于当前 Vault';
      license.statusType = 'error';
      return;
    }

    LicenseService.storeKey(license.keyInput.trim());
    license.keyInput = '';
    await refreshLicenseStatus();
  } catch (e: any) {
    license.statusText = e?.message || '验证失败';
    license.statusType = 'error';
  }
};

const clearLicense = async () => {
  if (!confirm('确定清除授权信息？')) return;
  LicenseService.clear();
  await refreshLicenseStatus();
};

// --- Methods ---
const toggleTheme = () => {
  isLightMode.value = !isLightMode.value;
  document.body.classList.toggle('light', isLightMode.value);
};

const setMsg = (target: 'unlock' | 'create', text: string, type: 'info' | 'error' | 'ok' = 'info') => {
  if (target === 'unlock') ui.unlockMsg = { text, type };
  else ui.createMsg = { text, type };
};

const handleFileSelect = async (event: Event) => {
  const input = event.target as HTMLInputElement;
  const file = input.files?.[0];
  if (!file) return;
  
  try {
    const text = await file.text();
    const obj = JSON.parse(text);
    VaultService.assertEncryptedShape(obj);
    encryptedVault.value = obj;
    fileName.value = file.name;
    fileHandle.value = null;
    setMsg('unlock', `已打开：${fileName.value}（只读方式）。请输入主密码后点击“解锁”。`, 'ok');
  } catch (e: any) {
    setMsg('unlock', e.message, 'error');
  } finally {
    input.value = '';
  }
};

const openVaultAuto = async () => {
  if (typeof window.showOpenFilePicker === 'function' && window.isSecureContext) {
    try {
      const [handle] = await window.showOpenFilePicker({
        multiple: false,
        excludeAcceptAllOption: true,
        types: [{
          description: 'Vault JSON',
          accept: { 'application/json': ['.json'] }
        }]
      });

      const file = await handle.getFile();
      const text = await file.text();
      const obj = JSON.parse(text);
      VaultService.assertEncryptedShape(obj);
      
      encryptedVault.value = obj;
      fileHandle.value = handle;
      fileName.value = file.name;
      setMsg('unlock', `已打开：${fileName.value}。请输入主密码后点击“解锁”。`, 'ok');
    } catch (e: any) {
      if (e.name === 'AbortError') {
        // User cancelled - silent handle or friendly hint
        console.log('User cancelled file selection');
        return;
      }
      setMsg('unlock', e.message, 'error');
    }
    return;
  }
  
  // Fallback
  document.getElementById('fileInput')?.click();
};

const unlockVault = async () => {
  if (!encryptedVault.value) {
    setMsg('unlock', '请先点击“打开 Vault”选择 JSON 文件', 'error');
    return;
  }
  if (!auth.masterPassword) {
    setMsg('unlock', '请输入主密码', 'error');
    return;
  }

  try {
    setMsg('unlock', '解锁中…');
    let keyfileBytes = null;
    if (auth.keyfile) {
      keyfileBytes = await CryptoUtil.readFileAsArrayBuffer(auth.keyfile);
    }

    const decrypted = await VaultService.decryptVault({
      encrypted: encryptedVault.value,
      masterPassword: auth.masterPassword,
      keyfileBytes
    });

    vault.value = decrypted;
    isUnlocked.value = true;
    ui.currentGroupId = decrypted.rootGroupId;
    ui.isDirty = false;
    setMsg('unlock', '解锁成功', 'ok');
  } catch (e: any) {
    setMsg('unlock', e.message, 'error');
  }
};

const createVault = async () => {
  const vaultNameRegex = /^[\w\u4e00-\u9fa5 -]{1,32}$/;
  if (!auth.newVaultName || !vaultNameRegex.test(auth.newVaultName)) {
    setMsg('create', '密码库名称无效（1-32位，支持中文、英文、数字、空格、-、_）', 'error');
    return;
  }
  if (!auth.newMaster || auth.newMaster.length < 8) {
    setMsg('create', '主密码至少 8 位', 'error');
    return;
  }
  if (auth.newMaster !== auth.newMaster2) {
    setMsg('create', '两次输入的主密码不一致', 'error');
    return;
  }

  try {
    setMsg('create', '创建中…');
    let keyfileBytes = null;
    if (auth.useKeyfile && auth.newKeyfile) {
      keyfileBytes = await CryptoUtil.readFileAsArrayBuffer(auth.newKeyfile);
    }

    const newVault = VaultService.createEmptyDecryptedVault({ name: auth.newVaultName });
    const iterations = auth.kdfIterations;
    const saltBytes = CryptoUtil.randomBytes(16);

    const encrypted = await VaultService.encryptVault({
      decryptedVault: newVault,
      masterPassword: auth.newMaster,
      keyfileBytes,
      iterations,
      saltBytes,
      factors: { keyfile: auth.useKeyfile }
    });

    encryptedVault.value = encrypted;
    vault.value = newVault;
    isUnlocked.value = true;
    ui.currentGroupId = newVault.rootGroupId;
    ui.isDirty = true;
    setMsg('create', '创建成功', 'ok');
    alert('密码库已创建。请点击右上角“保存密码库”保存为文件。');
  } catch (e: any) {
    setMsg('create', e.message, 'error');
  }
};

const viewVaultJson = async () => {
  if (!vault.value || !isUnlocked.value) return;

  try {
    const saltBytes = CryptoUtil.b64ToBytes(encryptedVault.value!.kdf.saltB64);
    const iterations = encryptedVault.value!.kdf.iterations;

    let keyfileBytes = null;
    if (auth.keyfile) keyfileBytes = await CryptoUtil.readFileAsArrayBuffer(auth.keyfile);
    else if (auth.newKeyfile) keyfileBytes = await CryptoUtil.readFileAsArrayBuffer(auth.newKeyfile);

    const encrypted = await VaultService.encryptVault({
      decryptedVault: vault.value,
      masterPassword: auth.masterPassword || auth.newMaster,
      keyfileBytes,
      iterations,
      saltBytes,
      factors: encryptedVault.value!.factors
    });

    ui.jsonContent = JSON.stringify(encrypted, null, 2);
    ui.showJsonModal = true;
  } catch (e: any) {
    alert('生成 JSON 失败: ' + e.message);
  }
};

const saveVault = async () => {
  if (!vault.value || !isUnlocked.value || !ui.isDirty) return;

  try {
    // Re-encrypt with current credentials
    // Note: In a real app, we'd store the credentials in memory during the session
    // For this refactor, we assume auth.masterPassword is still valid if unlocked
    // (In a more robust version, we'd prompt or keep derived key in memory)
    
    // For now, let's use the current encryptedVault's KDF params
    const saltBytes = CryptoUtil.b64ToBytes(encryptedVault.value!.kdf.saltB64);
    const iterations = encryptedVault.value!.kdf.iterations;

    let keyfileBytes = null;
    if (auth.keyfile) keyfileBytes = await CryptoUtil.readFileAsArrayBuffer(auth.keyfile);
    else if (auth.newKeyfile) keyfileBytes = await CryptoUtil.readFileAsArrayBuffer(auth.newKeyfile);

    const encrypted = await VaultService.encryptVault({
      decryptedVault: vault.value,
      masterPassword: auth.masterPassword || auth.newMaster,
      keyfileBytes,
      iterations,
      saltBytes,
      factors: encryptedVault.value!.factors
    });

    encryptedVault.value = encrypted;

    if (canWriteBack.value) {
      const writable = await fileHandle.value.createWritable();
      await writable.write(JSON.stringify(encrypted, null, 2));
      await writable.close();
      alert('已保存到原文件');
    } else {
      const blob = new Blob([JSON.stringify(encrypted, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${VaultService.id('vault')}.json`;
      a.click();
      URL.revokeObjectURL(url);
    }
    ui.isDirty = false;
  } catch (e: any) {
    if (e.name === 'AbortError' || e.name === 'NotAllowedError') {
      console.log('Save cancelled or permission denied');
      return;
    }
    alert('保存失败: ' + e.message);
  }
};

const logout = () => {
  if (ui.isDirty && !ui.showLogoutConfirm) {
    ui.showLogoutConfirm = true;
    return;
  }
  isUnlocked.value = false;
  vault.value = null;
  auth.masterPassword = '';
  auth.keyfile = null;
  ui.currentEntryId = null;
  ui.editingEntryId = null;
  ui.showLogoutConfirm = false;
  ui.isDirty = false;
  ui.selectedEntryIds = [];
  
  // Clear file info
  fileName.value = '未选择文件';
  fileHandle.value = null;
  encryptedVault.value = null;
  
  setMsg('unlock', '已退出', 'info');
};

const openSettings = () => {
  if (!vault.value) return;
  ui.tempVaultName = vault.value.name;
  ui.vaultNameMsg = '';
  ui.showSettings = true;
};

const saveVaultName = () => {
  if (!vault.value) return;
  const vaultNameRegex = /^[\w\u4e00-\u9fa5 -]{1,32}$/;
  if (!ui.tempVaultName || !vaultNameRegex.test(ui.tempVaultName)) {
    ui.vaultNameMsg = '名称无效（1-32位，支持中文、英文、数字、空格、-、_）';
    ui.vaultNameMsgType = 'error';
    return;
  }
  vault.value.name = ui.tempVaultName;
  ui.isDirty = true;
  ui.vaultNameMsg = '名称已更新';
  ui.vaultNameMsgType = 'ok';
};

const changeMasterPassword = async () => {
  if (!vault.value || !isUnlocked.value) return;
  
  if (ui.changePw.old !== auth.masterPassword) {
    ui.changePw.msg = '旧主密码错误';
    ui.changePw.msgType = 'error';
    return;
  }
  if (!ui.changePw.new || ui.changePw.new.length < 8) {
    ui.changePw.msg = '新密码至少 8 位';
    ui.changePw.msgType = 'error';
    return;
  }
  if (ui.changePw.new === auth.masterPassword) {
    ui.changePw.msg = '新密码不能与旧密码相同';
    ui.changePw.msgType = 'error';
    return;
  }
  if (ui.changePw.new !== ui.changePw.confirm) {
    ui.changePw.msg = '两次输入的新密码不一致';
    ui.changePw.msgType = 'error';
    return;
  }
  
  try {
    ui.changePw.msg = '正在重新加密密码库...';
    ui.changePw.msgType = 'info';
    
    const saltBytes = CryptoUtil.randomBytes(16);
    const iterations = auth.kdfIterations;
    
    let keyfileBytes = null;
    if (auth.keyfile) keyfileBytes = await CryptoUtil.readFileAsArrayBuffer(auth.keyfile);

    const encrypted = await VaultService.encryptVault({
      decryptedVault: vault.value,
      masterPassword: ui.changePw.new,
      keyfileBytes,
      iterations,
      saltBytes,
      factors: { keyfile: !!auth.keyfile }
    });
    
    encryptedVault.value = encrypted;
    auth.masterPassword = ui.changePw.new;
    ui.isDirty = true;
    
    ui.changePw.old = '';
    ui.changePw.new = '';
    ui.changePw.confirm = '';
    ui.changePw.msg = '主密码修改成功！请记得保存密码库。';
    ui.changePw.msgType = 'ok';
  } catch (e: any) {
    ui.changePw.msg = '修改失败: ' + e.message;
    ui.changePw.msgType = 'error';
  }
};

const manageKeyfile = async (action: 'add' | 'replace' | 'delete', event?: Event) => {
  if (!vault.value || !isUnlocked.value) return;
  
  if (action === 'delete' && !confirm('确定移除 Keyfile 验证？这会降低密码库的安全性。')) return;

  try {
    let file: File | null = null;
    if (action !== 'delete' && event) {
      const input = event.target as HTMLInputElement;
      file = input.files?.[0] || null;
      if (!file) return;
    }

    ui.keyfileMsg = '正在重新加密密码库...';
    ui.keyfileMsgType = 'info';
    
    let newKeyfileBytes = null;
    if (action !== 'delete' && file) {
      newKeyfileBytes = await CryptoUtil.readFileAsArrayBuffer(file);
    }
    
    const saltBytes = CryptoUtil.randomBytes(16);
    const iterations = auth.kdfIterations;
    
    const encrypted = await VaultService.encryptVault({
      decryptedVault: vault.value,
      masterPassword: auth.masterPassword || auth.newMaster,
      keyfileBytes: newKeyfileBytes,
      iterations,
      saltBytes,
      factors: { keyfile: action !== 'delete' }
    });
    
    encryptedVault.value = encrypted;
    auth.keyfile = (action !== 'delete' && file) ? file : null;
    ui.isDirty = true;
    
    ui.keyfileMsg = action === 'delete' ? '2FA 已移除' : (action === 'add' ? '2FA 已启用' : '2FA 已更新');
    ui.keyfileMsgType = 'ok';
    
    // Reset file input if any
    if (event) (event.target as HTMLInputElement).value = '';
  } catch (e: any) {
    ui.keyfileMsg = '操作失败: ' + e.message;
    ui.keyfileMsgType = 'error';
  }
};

// --- Entry Operations ---
const openEntryModal = (entryId: string | null = null) => {
  ui.editingEntryId = entryId;
  ui.showHistoryIdx = -1;
  if (entryId && vault.value) {
    const entry = vault.value.entries.find(e => e.id === entryId);
    if (entry) {
      Object.assign(entryForm, {
        ...entry,
        tags: entry.tags.join(', '),
        customFields: JSON.parse(JSON.stringify(entry.customFields))
      });
    }
  } else {
    Object.assign(entryForm, {
      title: '',
      username: '',
      password: '',
      url: '',
      notes: '',
      tags: '',
      favorite: false,
      groupId: ui.currentGroupId || vault.value?.rootGroupId || '',
      customFields: [],
      showPassword: false,
    });
  }
  ui.showEntryModal = true;
};

const saveEntry = async () => {
  if (!vault.value) return;
  
  const patch: any = {
    ...entryForm,
    tags: entryForm.tags.split(',').map(t => t.trim()).filter(Boolean),
    title: entryForm.title.trim() || '未命名条目'
  };

  if (ui.editingEntryId) {
    const oldEntry = vault.value.entries.find(e => e.id === ui.editingEntryId);
    if (oldEntry && oldEntry.password !== entryForm.password && license.isPro) {
      // Save to history
      const history = oldEntry.passwordHistory || [];
      history.unshift({
        password: oldEntry.password,
        date: new Date().toISOString()
      });
      // Keep only 5
      patch.passwordHistory = history.slice(0, 5);
    }
    VaultService.updateEntry(vault.value, ui.editingEntryId, patch);
  } else {
    const e = VaultService.addEntry(vault.value, patch);
    ui.currentEntryId = e.id;
  }
  
  ui.isDirty = true;
  ui.showEntryModal = false;
};

const batchDeleteEntries = () => {
  if (!vault.value || ui.selectedEntryIds.length === 0) return;
  if (!confirm(`确定删除选中的 ${ui.selectedEntryIds.length} 个条目？`)) return;
  
  VaultService.batchDeleteEntries(vault.value, ui.selectedEntryIds);
  ui.selectedEntryIds = [];
  ui.isDirty = true;
};

const toggleSelectEntry = (id: string) => {
  const idx = ui.selectedEntryIds.indexOf(id);
  if (idx > -1) {
    ui.selectedEntryIds.splice(idx, 1);
  } else {
    ui.selectedEntryIds.push(id);
  }
};

const toggleSelectAll = () => {
  if (ui.selectedEntryIds.length === filteredEntries.value.length) {
    ui.selectedEntryIds = [];
  } else {
    ui.selectedEntryIds = filteredEntries.value.map(e => e.id);
  }
};

const deleteEntry = () => {
  if (!vault.value || !ui.editingEntryId) return;
  if (!confirm('确定删除该条目？')) return;
  
  VaultService.deleteEntry(vault.value, ui.editingEntryId);
  ui.currentEntryId = null;
  ui.isDirty = true;
  ui.showEntryModal = false;
};

// --- Timers ---
let inactivityTimer: any = null;
let clipboardTimer: any = null;

const resetInactivityTimer = () => {
  if (!isUnlocked.value || !vault.value) return;
  if (inactivityTimer) clearTimeout(inactivityTimer);
  
  const ms = (vault.value.settings.autoLockMinutes || 5) * 60 * 1000;
  inactivityTimer = setTimeout(() => {
    logout();
    alert('由于长时间未操作，密码库已自动锁定');
  }, ms);
};

const scheduleClipboardClear = () => {
  if (clipboardTimer) clearTimeout(clipboardTimer);
  
  const sec = vault.value?.settings.clipboardClearSeconds || 20;
  clipboardTimer = setTimeout(async () => {
    try {
      await navigator.clipboard.writeText('');
    } catch (e) {
      console.warn('Failed to clear clipboard');
    }
  }, sec * 1000);
};

const copyToClipboard = async (text: string) => {
  try {
    await navigator.clipboard.writeText(text);
    scheduleClipboardClear();
  } catch (e) {
    alert('复制失败');
  }
};

// --- Group Operations ---
const openGroupModal = (groupId: string | null = null) => {
  ui.editingGroupId = groupId;
  if (groupId && vault.value) {
    const group = vault.value.groups.find(g => g.id === groupId);
    if (group) {
      groupForm.name = group.name;
      groupForm.parentId = group.parentId;
    }
  } else {
    groupForm.name = '';
    groupForm.parentId = ui.currentGroupId;
  }
  ui.showGroupModal = true;
};

const saveGroup = () => {
  if (!vault.value) return;
  if (!groupForm.name) return;

  // Enforce 3-level limit
  if (groupForm.parentId && groupForm.parentId !== vault.value.rootGroupId) {
    const parent = vault.value.groups.find(g => g.id === groupForm.parentId);
    if (parent) {
      // Check depth of parent
      let depth = 1;
      let curr = parent;
      while (curr.parentId && curr.parentId !== vault.value.rootGroupId) {
        depth++;
        const next = vault.value.groups.find(g => g.id === curr.parentId);
        if (!next) break;
        curr = next;
      }
      if (depth >= 3) {
        alert('系统支持最多 3 层分组结构。');
        return;
      }
    }
  }

  if (ui.editingGroupId) {
    VaultService.updateGroup(vault.value, ui.editingGroupId, { ...groupForm });
  } else {
    VaultService.addGroup(vault.value, { ...groupForm });
  }
  ui.isDirty = true;
  ui.showGroupModal = false;
};

const handleGroupDragStart = (groupId: string) => {
  ui.draggedGroupId = groupId;
};

const handleGroupDragOver = (e: DragEvent) => {
  e.preventDefault();
};

const handleGroupDrop = (targetGroupId: string) => {
  if (!vault.value || !ui.draggedGroupId || ui.draggedGroupId === targetGroupId) return;

  const groups = vault.value.groups;
  const draggedIdx = groups.findIndex(g => g.id === ui.draggedGroupId);
  const targetIdx = groups.findIndex(g => g.id === targetGroupId);

  if (draggedIdx === -1 || targetIdx === -1) return;

  const dragged = groups[draggedIdx];
  const target = groups[targetIdx];

  // Only allow same-level sorting
  if (dragged.parentId !== target.parentId) return;

  // Reorder
  const sameLevelGroups = groups.filter(g => g.parentId === dragged.parentId)
    .sort((a, b) => a.order - b.order);
  
  const dIdx = sameLevelGroups.findIndex(g => g.id === ui.draggedGroupId);
  const tIdx = sameLevelGroups.findIndex(g => g.id === targetGroupId);

  sameLevelGroups.splice(dIdx, 1);
  sameLevelGroups.splice(tIdx, 0, dragged);

  // Update orders
  sameLevelGroups.forEach((g, index) => {
    g.order = index;
  });

  ui.isDirty = true;
  ui.draggedGroupId = null;
};

const handleEntryDragStart = (entryId: string) => {
  ui.draggedEntryId = entryId;
};

const handleEntryDragOver = (e: DragEvent) => {
  e.preventDefault();
};

const handleEntryDrop = (targetEntryId: string) => {
  if (!vault.value || !ui.draggedEntryId || ui.draggedEntryId === targetEntryId) return;

  const entries = vault.value.entries;
  const draggedIdx = entries.findIndex(e => e.id === ui.draggedEntryId);
  const targetIdx = entries.findIndex(e => e.id === targetEntryId);

  if (draggedIdx === -1 || targetIdx === -1) return;

  const dragged = entries[draggedIdx];
  const target = entries[targetIdx];

  // Only allow same-level sorting (same group or both favorites)
  if (ui.showFavorites) {
    if (!dragged.favorite || !target.favorite) return;
  } else {
    if (dragged.groupId !== target.groupId) return;
  }

  // Reorder
  let listToReorder: VaultEntry[] = [];
  if (ui.showFavorites) {
    listToReorder = entries.filter(e => e.favorite).sort((a, b) => a.order - b.order);
  } else {
    listToReorder = entries.filter(e => e.groupId === dragged.groupId).sort((a, b) => a.order - b.order);
  }

  const dIdx = listToReorder.findIndex(e => e.id === ui.draggedEntryId);
  const tIdx = listToReorder.findIndex(e => e.id === targetEntryId);

  listToReorder.splice(dIdx, 1);
  listToReorder.splice(tIdx, 0, dragged);

  // Update orders
  listToReorder.forEach((e, index) => {
    e.order = index;
  });

  ui.isDirty = true;
  ui.draggedEntryId = null;
};

const deleteGroup = () => {
  if (!vault.value || !ui.editingGroupId) return;
  if (!confirm('确定删除该分组？该分组下条目将自动移动到父分组。')) return;
  
  try {
    VaultService.deleteGroup(vault.value, ui.editingGroupId);
    ui.currentGroupId = vault.value.rootGroupId;
    ui.isDirty = true;
    ui.showGroupModal = false;
  } catch (e: any) {
    alert(e.message);
  }
};

const generatePassword = () => {
  generator.output = CryptoUtil.generatePassword({
    length: generator.length,
    upper: generator.upper,
    lower: generator.lower,
    nums: generator.nums,
    syms: generator.syms
  });
};

const useGeneratedPassword = () => {
  if (generator.output) {
    entryForm.password = generator.output;
  }
};

const addCustomField = () => {
  entryForm.customFields.push({ key: '', value: '' });
};

const removeCustomField = (index: number) => {
  if (!confirm('确定删除该自定义字段？')) return;
  entryForm.customFields.splice(index, 1);
};

// --- Attachment Operations ---
const handleAttachmentUpload = async (event: Event) => {
  if (!license.isPro) {
    alert('附件功能仅限 Pro 用户使用。请在设置中激活授权。');
    return;
  }
  if (!vault.value || !ui.editingEntryId) return;
  const input = event.target as HTMLInputElement;
  const file = input.files?.[0];
  if (!file) return;

  try {
    ui.isProcessingAttachment = true;
    
    // Derive key for attachment encryption
    const saltBytes = CryptoUtil.b64ToBytes(encryptedVault.value!.kdf.saltB64);
    const iterations = encryptedVault.value!.kdf.iterations;
    let keyfileBytes = null;
    if (auth.keyfile) keyfileBytes = await CryptoUtil.readFileAsArrayBuffer(auth.keyfile);
    else if (auth.newKeyfile) keyfileBytes = await CryptoUtil.readFileAsArrayBuffer(auth.newKeyfile);

    const kdfMaterial = await CryptoUtil.buildKdfMaterial({ 
      masterPassword: auth.masterPassword || auth.newMaster, 
      keyfileBytes 
    });
    const key = await CryptoUtil.deriveAesKey({ kdfMaterial, saltBytes, iterations });

    const encrypted = await CryptoUtil.encryptAttachment({ key, file });

    await VaultService.addAttachment(vault.value, ui.editingEntryId, {
      name: file.name,
      size: file.size,
      type: file.type,
      ...encrypted
    });

    ui.isDirty = true;
    // Update entryForm to reflect changes in modal
    const entry = vault.value.entries.find(e => e.id === ui.editingEntryId);
    if (entry) {
      Object.assign(entryForm, {
        ...entry,
        tags: entry.tags.join(', '),
        customFields: JSON.parse(JSON.stringify(entry.customFields))
      });
    }
  } catch (e: any) {
    alert('上传附件失败: ' + e.message);
  } finally {
    ui.isProcessingAttachment = false;
    input.value = '';
  }
};

const deleteAttachment = (attachmentId: string) => {
  if (!vault.value || !ui.editingEntryId) return;
  if (!confirm('确定删除该附件？')) return;

  VaultService.deleteAttachment(vault.value, ui.editingEntryId, attachmentId);
  ui.isDirty = true;
  
  // Update entryForm
  const entry = vault.value.entries.find(e => e.id === ui.editingEntryId);
  if (entry) {
    Object.assign(entryForm, {
      ...entry,
      tags: entry.tags.join(', '),
      customFields: JSON.parse(JSON.stringify(entry.customFields))
    });
  }
};

const downloadAttachment = async (attachment: any) => {
  if (!vault.value || !isUnlocked.value) return;

  try {
    const saltBytes = CryptoUtil.b64ToBytes(encryptedVault.value!.kdf.saltB64);
    const iterations = encryptedVault.value!.kdf.iterations;
    let keyfileBytes = null;
    if (auth.keyfile) keyfileBytes = await CryptoUtil.readFileAsArrayBuffer(auth.keyfile);
    else if (auth.newKeyfile) keyfileBytes = await CryptoUtil.readFileAsArrayBuffer(auth.newKeyfile);

    const kdfMaterial = await CryptoUtil.buildKdfMaterial({ 
      masterPassword: auth.masterPassword || auth.newMaster, 
      keyfileBytes 
    });
    const key = await CryptoUtil.deriveAesKey({ kdfMaterial, saltBytes, iterations });

    const data = await CryptoUtil.decryptAttachment({
      key,
      ivB64: attachment.ivB64,
      dataB64: attachment.dataB64,
      compressed: attachment.compressed
    });

    const blob = new Blob([data], { type: attachment.type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = attachment.name;
    a.click();
    URL.revokeObjectURL(url);
  } catch (e: any) {
    alert('下载附件失败: ' + e.message);
  }
};

const formatSize = (bytes: number) => {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

const formatDate = (iso: string) => {
  if (!iso) return '—';
  const d = new Date(iso);
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  const hh = String(d.getHours()).padStart(2, '0');
  const mi = String(d.getMinutes()).padStart(2, '0');
  const ss = String(d.getSeconds()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd} ${hh}-${mi}-${ss}`;
};

// --- Lifecycle ---
const generateDemoVault = async () => {
  try {
    ui.unlockMsg = { text: '正在生成演示数据...', type: 'info' };
    const demoVault = VaultService.createEmptyDecryptedVault({ name: '演示密码库 (Demo)' });
    
    const categories: Record<string, string[]> = {
      "互联网": ["邮箱", "社交账号", "购物网站", "论坛"],
      "金融": ["银行", "支付", "投资", "交易所"],
      "工作": ["企业邮箱", "办公系统", "项目管理工具"],
      "设备": ["路由器", "NAS", "IoT 设备", "服务器登录"],
      "教育/学习": ["学习平台账号", "培训网站"],
      "娱乐": ["游戏账号", "影音会员", "社交娱乐"]
    };

    const groupMap: Record<string, string> = {};
    for (const catName of Object.keys(categories)) {
      const g = VaultService.addGroup(demoVault, { name: catName, parentId: demoVault.rootGroupId });
      groupMap[catName] = g.id;
    }

    for (let i = 1; i <= 100; i++) {
      const catNames = Object.keys(categories);
      const cat = catNames[Math.floor(Math.random() * catNames.length)];
      const subcats = categories[cat];
      const subcat = subcats[Math.floor(Math.random() * subcats.length)];
      
      VaultService.addEntry(demoVault, {
        title: `${subcat}示例 ${i}`,
        username: `user${i}@example.com`,
        password: CryptoUtil.generatePassword({ length: 16, upper: true, lower: true, nums: true, syms: true }),
        url: `https://example${i}.com`,
        notes: `这是第 ${i} 条演示数据，分类属于 ${cat} - ${subcat}。`,
        tags: [cat, subcat],
        groupId: groupMap[cat],
        favorite: Math.random() > 0.8
      });
    }

    const saltBytes = CryptoUtil.randomBytes(16);
    const encrypted = await VaultService.encryptVault({
      decryptedVault: demoVault,
      masterPassword: 'test1234',
      keyfileBytes: null,
      iterations: 200000,
      saltBytes,
      factors: { keyfile: false }
    });

    const blob = new Blob([JSON.stringify(encrypted, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `demo-vault-test1234.json`;
    a.click();
    URL.revokeObjectURL(url);
    
    ui.unlockMsg = { text: '演示密码库已生成并下载。主密码为: test1234', type: 'ok' };
  } catch (e: any) {
    ui.unlockMsg = { text: '生成失败: ' + e.message, type: 'error' };
  }
};

onMounted(() => {
  refreshLicenseStatus();
  // Default to dark mode as requested, ignore system preference for now
  // if (window.matchMedia('(prefers-color-scheme: light)').matches) {
  //   isLightMode.value = true;
  //   document.body.classList.add('light');
  // }

  const events = ['mousemove', 'mousedown', 'keydown', 'scroll', 'touchstart'];
  events.forEach(evt => window.addEventListener(evt, resetInactivityTimer, { passive: true }));

  // Ctrl+F support
  window.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'f') {
      e.preventDefault();
      const searchInput = document.querySelector('input[placeholder="搜索条目..."]') as HTMLInputElement;
      searchInput?.focus();
    }
  });
});

watch(isUnlocked, (val) => {
  if (val) resetInactivityTimer();
  else if (inactivityTimer) clearTimeout(inactivityTimer);
});
</script>

<template>
  <div class="h-screen flex flex-col overflow-hidden">
    <!-- Header -->
    <header class="topbar">
      <div class="brand">
        <Shield class="w-5 h-5 text-[var(--primary)]" />
        <span class="brand-title">Midkey Vault 离线密码管理器</span>
        <span v-if="isUnlocked" class="badge hide-mobile">已登录</span>
      </div>

      <!-- Desktop Actions -->
      <div class="topbar-actions hide-mobile">
        <button 
          :class="['btn small', ui.isDirty ? 'save-dirty' : 'save-clean']" 
          :disabled="!isUnlocked || !ui.isDirty" 
          @click="saveVault"
          :title="ui.isDirty ? '保存 (有未保存更改)' : '无需保存'"
        >
          <Save class="w-4 h-4" />
        </button>
        <button class="btn ghost small" :disabled="!isUnlocked" @click="openSettings" title="设置">
          <Settings class="w-4 h-4" />
        </button>
        <button class="btn ghost small" @click="ui.showHelpModal = true" title="帮助手册">
          <HelpCircle class="w-4 h-4" />
        </button>
        <button class="btn ghost small" @click="toggleTheme" :title="isLightMode ? '深色模式' : '浅色模式'">
          <Sun v-if="!isLightMode" class="w-4 h-4" />
          <Moon v-else class="w-4 h-4" />
        </button>
        <!-- <a href="https://www.midkey.xyz" target="_blank" class="btn ghost small text-[var(--muted)] hover:text-[var(--danger)]" title="捐赠支持">
          <Heart class="w-4 h-4" />
        </a> -->
        <button v-if="isUnlocked" class="btn ghost small text-[var(--danger)]" @click="logout" title="退出">
          <LogOut class="w-4 h-4" />
        </button>
      </div>

      <!-- Mobile Menu Toggle -->
      <div class="md:hidden flex items-center gap-2">
        <button 
          v-if="isUnlocked"
          :class="['btn small', ui.isDirty ? 'save-dirty' : 'save-clean']" 
          :disabled="!ui.isDirty"
          @click="saveVault"
        >
          <Save class="w-4 h-4" />
        </button>
        <button class="btn ghost small" @click="ui.showMobileMenu = true">
          <Menu class="w-5 h-5" />
        </button>
      </div>
    </header>

    <!-- Mobile Menu Overlay -->
    <div v-if="ui.showMobileMenu" class="mobile-menu-overlay" @click="ui.showMobileMenu = false">
      <div class="mobile-menu-content" @click.stop>
        <div class="flex items-center justify-between mb-8">
          <div class="flex items-center gap-2">
            <Shield class="w-5 h-5 text-[var(--primary)]" />
            <span class="font-bold">菜单</span>
          </div>
          <button class="btn ghost small" @click="ui.showMobileMenu = false">✕</button>
        </div>

        <div class="space-y-2">
          <button class="mobile-menu-item w-full" @click="ui.showHelpModal = true; ui.showMobileMenu = false">
            <HelpCircle class="w-4 h-4" /> 帮助手册
          </button>
          <button 
            class="mobile-menu-item w-full" 
            :disabled="!isUnlocked || !ui.isDirty" 
            @click="saveVault(); ui.showMobileMenu = false"
            :class="ui.isDirty ? 'text-[var(--primary)]' : 'text-[var(--muted)]'"
          >
            <Save class="w-4 h-4" /> 保存 Vault {{ ui.isDirty ? '(有更新)' : '' }}
          </button>
          <button class="mobile-menu-item w-full" :disabled="!isUnlocked" @click="openSettings(); ui.showMobileMenu = false">
            <Settings class="w-4 h-4" /> 设置
          </button>
          <button class="mobile-menu-item w-full" @click="toggleTheme(); ui.showMobileMenu = false">
            <Sun v-if="!isLightMode" class="w-4 h-4" />
            <Moon v-else class="w-4 h-4" />
            {{ isLightMode ? '深色模式' : '浅色模式' }}
          </button>
          <a href="https://www.midkey.xyz" target="_blank" class="mobile-menu-item w-full">
            <Heart class="w-4 h-4 text-[var(--danger)]" /> 捐赠支持
          </a>
          <div class="pt-4 mt-4 border-t border-white/5">
            <button v-if="isUnlocked" class="mobile-menu-item w-full text-[var(--danger)]" @click="logout(); ui.showMobileMenu = false">
              <LogOut class="w-4 h-4" /> 退出密码库
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Auth View -->
    <main v-if="!isUnlocked" class="flex-1 flex items-start justify-center p-4 md:p-8 overflow-y-auto">
      <div class="auth-container py-4">
        <div class="text-center mb-6">
          <p class="text-sm muted mt-2">【内测中】基础版永久免费。本地 AES-256 加密与零知识架构，数据完全由用户掌控。</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
          <!-- Unlock Panel -->
          <div class="card h-full flex flex-col">
            <h2 class="text-lg font-semibold mb-4 flex items-center gap-2">
              <Unlock class="w-5 h-5 text-[var(--primary)]" /> 解锁现有密码库
            </h2>
            
            <div class="space-y-4 flex-1">
              <div>
                <label>Vault JSON 文件</label>
                <div class="flex items-center gap-3">
                  <button class="btn primary flex-1" @click="openVaultAuto">
                    <FileJson class="w-4 h-4" /> 打开 Vault
                  </button>
                </div>
                <p v-if="fileName !== '未选择文件'" class="text-[10px] muted mt-2 truncate">已选择: {{ fileName }}</p>
                <input type="file" id="fileInput" class="hidden" accept=".json" @change="handleFileSelect" />
              </div>

              <div>
                <label>主密码</label>
                <input v-model="auth.masterPassword" type="password" placeholder="Master Password" @keyup.enter="unlockVault" />
              </div>

              <details class="text-sm border border-white/5 rounded-xl p-3 bg-black/10">
                <summary class="cursor-pointer muted text-xs font-medium">▶ 密钥文件（额外安全保护）</summary>
                <div class="mt-4 space-y-4">
                  <div>
                    <label>Keyfile (2FA 密钥文件)</label>
                    <input type="file" class="text-xs" @change="(e: any) => auth.keyfile = e.target.files[0]" />
                  </div>
                </div>
              </details>

              <button class="btn primary w-full py-3 font-bold" @click="unlockVault">解锁密码库</button>
              
              <p v-if="ui.unlockMsg.text" :class="['text-xs text-center p-2 rounded-lg', ui.unlockMsg.type === 'error' ? 'bg-[var(--danger)]/10 text-[var(--danger)]' : 'bg-[var(--ok)]/10 text-[var(--ok)]']">
                {{ ui.unlockMsg.text }}
              </p>

              <div class="pt-4 border-t border-white/5">
                <button class="btn ghost w-full text-xs" @click="generateDemoVault">
                  <Sparkles class="w-3.5 h-3.5 mr-1" /> 生成演示数据 (密码: test1234)
                </button>
              </div>
            </div>
          </div>

          <!-- Create Panel -->
          <div class="card h-full flex flex-col">
            <h2 class="text-lg font-semibold mb-4 flex items-center gap-2">
              <PlusCircle class="w-5 h-5 text-[var(--primary)]" /> 创建新密码库
            </h2>
            
            <div class="space-y-4 flex-1">
              <div>
                <label>密码库名称 <span class="text-[var(--danger)]">*</span></label>
                <input v-model="auth.newVaultName" type="text" placeholder="例如: 我的密码库" />
              </div>
              <div>
                <label>主密码</label>
                <input v-model="auth.newMaster" type="password" placeholder="至少 8 位" />
              </div>
              <div>
                <label>确认主密码</label>
                <input v-model="auth.newMaster2" type="password" placeholder="再次输入" />
              </div>

              <details class="text-sm border border-white/5 rounded-xl p-3 bg-black/10">
                <summary class="cursor-pointer muted text-xs font-medium">▶ 密钥文件（额外安全保护）</summary>
                <div class="mt-4 space-y-4">
                  <label class="flex items-center gap-2 cursor-pointer">
                    <input v-model="auth.useKeyfile" type="checkbox" /> 启用 2FA (Keyfile)
                  </label>
                  <input v-if="auth.useKeyfile" type="file" class="text-xs" @change="(e: any) => auth.newKeyfile = e.target.files[0]" />

                  <!-- PBKDF2 迭代次数保持内部固定配置，这里不再展示给用户 -->
                </div>
              </details>

              <button class="btn w-full py-3 font-bold" @click="createVault">创建并解锁</button>
              <p v-if="ui.createMsg.text" class="text-xs text-center p-2 rounded-lg bg-[var(--danger)]/10 text-[var(--danger)]">{{ ui.createMsg.text }}</p>
            </div>
          </div>
        </div>

        <!-- Footer -->
        <footer class="mt-12 pt-8 border-t border-white/5 text-center">
          <div class="flex flex-col items-center gap-2">
            <div class="flex items-center gap-2 text-[10px] font-bold text-[var(--muted)] uppercase tracking-widest">
              <span>© 2026 Midkey Vault</span>
              <span class="opacity-20">|</span>
              <span>v1.0.0</span>
              <span class="opacity-20">|</span>
              <span class="hover:text-[var(--primary)] cursor-pointer transition-colors" @click="ui.showPrivacyModal = true">隐私声明</span>
            </div>
            <p class="text-[10px] text-[var(--muted)]/50 max-w-md">
              您的数据仅存储在本地，我们不收集任何个人信息。
            </p>
            <div class="mt-4 space-y-1 text-[10px] text-[var(--muted)]/40">
              <p>推荐浏览器：Chrome / Edge</p>
              <p>Midkey Vault 依赖现代浏览器的 Web Crypto 与本地文件 API</p>
            </div>
          </div>
        </footer>
      </div>
    </main>

    <!-- App View (Responsive Layout) -->
    <main v-else class="flex-1 flex overflow-hidden relative">
      <!-- 1. Left Sidebar (Groups) - Shown on md+ OR on mobile when mobileTab is 'groups' -->
      <aside 
        :class="['md:flex md:w-1/5 min-w-[200px] border-r border-white/5 bg-black/10 flex-col p-3 overflow-y-auto',
                 ui.currentEntryId ? 'hidden md:flex' : (ui.mobileTab === 'groups' ? 'flex w-full' : 'hidden md:flex')]"
      >
        <div class="flex items-center justify-between mb-4 px-1">
          <div 
            @click="ui.showFavorites = true; ui.currentGroupId = null; ui.mobileTab = 'entries'"
            :class="['flex items-center gap-2 px-2 py-1 rounded-lg cursor-pointer transition-colors text-sm', ui.showFavorites ? 'bg-[var(--primary)]/15 text-[var(--primary)]' : 'hover:bg-white/5']"
          >
            <Star class="w-4 h-4" /> 收藏
          </div>
          <button class="btn ghost small p-1" @click="openGroupModal(null)" title="添加分组"><Plus class="w-3.5 h-3.5" /></button>
        </div>

        <div class="space-y-0.5 mb-6">
          <div 
            @click="ui.showFavorites = false; ui.currentGroupId = vault?.rootGroupId || null; ui.mobileTab = 'entries'"
            :class="['sidebar-item', !ui.showFavorites && ui.currentGroupId === vault?.rootGroupId ? 'bg-[var(--primary)]/15 text-[var(--primary)]' : 'hover:bg-white/5']"
          >
            <div class="flex items-center gap-2.5">
              <Database class="w-4 h-4" /> 数据库
            </div>
          </div>

          <div class="pt-2 space-y-0.5">
            <template v-for="group in groupTree" :key="group.id">
              <div 
                v-if="group.id !== vault?.rootGroupId"
                @click="ui.showFavorites = false; ui.currentGroupId = group.id; ui.mobileTab = 'entries'"
                :class="['sidebar-item', 'group', !ui.showFavorites && ui.currentGroupId === group.id ? 'bg-[var(--primary)]/15 text-[var(--primary)]' : 'hover:bg-white/5']"
                :style="{ paddingLeft: (group.depth * 16 + 8) + 'px' }"
                draggable="true"
                @dragstart="handleGroupDragStart(group.id)"
                @dragover="handleGroupDragOver"
                @drop="handleGroupDrop(group.id)"
              >
                <div class="flex items-center gap-2.5 truncate">
                  <Folder class="w-4 h-4 opacity-40" />
                  <span class="truncate">{{ group.name }}</span>
                </div>
                <div class="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button class="p-1 hover:bg-white/10 rounded cursor-grab active:cursor-grabbing" title="拖拽排序">
                    <GripVertical class="w-3 h-3" />
                  </button>
                  <button class="p-1 hover:bg-white/10 rounded" @click.stop="openGroupModal(group.id)" title="编辑分组">
                    <Edit class="w-3 h-3" />
                  </button>
                </div>
              </div>
            </template>
          </div>
        </div>

        <div class="mt-auto pt-4 border-t border-white/5">
          <span class="text-[10px] font-bold text-[var(--muted)] uppercase tracking-widest block mb-2 px-1">标签筛选</span>
          <select v-model="ui.tagFilter" class="text-xs h-8">
            <option value="">全部标签</option>
            <option v-for="tag in allTags" :key="tag" :value="tag">#{{ tag }}</option>
          </select>
        </div>
      </aside>

      <!-- 2. Middle Column (Entry List) - Full width on mobile if no entry selected and mobileTab is 'entries' -->
      <section 
        :class="['flex flex-col min-w-0 bg-black/5 border-r border-white/5', 
                 ui.currentEntryId ? 'hidden md:flex md:w-[40%]' : (ui.mobileTab === 'entries' ? 'flex-1 md:w-[40%]' : 'hidden md:flex')]"
      >
        <!-- Search & Add -->
        <div class="p-3 border-b border-white/5 flex items-center gap-2">
          <button class="btn ghost small md:hidden" @click="ui.mobileTab = 'groups'">
            <ChevronRight class="w-5 h-5 rotate-180" />
          </button>
          <div class="relative flex-1">
            <Search class="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[var(--muted)]" />
            <input v-model="ui.searchQuery" type="text" placeholder="搜索条目..." class="!pl-10 h-10 text-sm" />
          </div>
          <button class="btn primary h-10 px-4" @click="openEntryModal(null)">
            <Plus class="w-4 h-4" /> <span class="hide-mobile">新建</span>
          </button>
        </div>

        <!-- Batch Actions -->
        <div v-if="filteredEntries.length > 0" class="px-3 py-2 border-b border-white/5 bg-black/10 flex items-center justify-between">
          <div class="flex items-center gap-2">
            <input 
              type="checkbox" 
              :checked="ui.selectedEntryIds.length === filteredEntries.length && filteredEntries.length > 0" 
              @change="toggleSelectAll" 
              class="w-3.5 h-3.5 rounded border-white/10 accent-[var(--primary)]" 
            />
            <span class="text-[10px] muted font-medium">全选 ({{ ui.selectedEntryIds.length }}/{{ filteredEntries.length }})</span>
          </div>
          <button v-if="ui.selectedEntryIds.length > 0" class="btn danger small py-1 px-2 h-7" @click="batchDeleteEntries">
            <Trash2 class="w-3 h-3" /> <span class="text-[10px]">删除选中</span>
          </button>
        </div>

        <!-- Entry List -->
        <div class="flex-1 overflow-y-auto p-2 space-y-1">
          <div v-if="filteredEntries.length === 0" class="p-12 text-center muted text-sm">
            没有找到匹配的条目
          </div>
          <div 
            v-for="entry in filteredEntries" 
            :key="entry.id"
            @click="ui.currentEntryId = entry.id"
            :class="['list-item', 'group', ui.currentEntryId === entry.id ? 'active' : '']"
            draggable="true"
            @dragstart="handleEntryDragStart(entry.id)"
            @dragover="handleEntryDragOver"
            @drop="handleEntryDrop(entry.id)"
          >
            <!-- Checkbox for batch delete -->
            <div class="shrink-0 mr-1" @click.stop>
              <input 
                type="checkbox" 
                :checked="ui.selectedEntryIds.includes(entry.id)" 
                @change="toggleSelectEntry(entry.id)" 
                class="w-4 h-4 rounded border-white/10 accent-[var(--primary)]" 
              />
            </div>
            <div class="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center shrink-0">
              <Shield class="w-5 h-5 text-[var(--muted)]" />
            </div>
            <div class="flex-1 min-w-0">
              <div class="flex items-center justify-between gap-2">
                <span class="font-medium text-sm truncate">{{ entry.title }}</span>
                <Star v-if="entry.favorite" class="w-3.5 h-3.5 text-[var(--warn)] fill-current shrink-0" />
              </div>
              <div class="text-[11px] muted truncate mt-0.5">
                {{ entry.username || '—' }}
              </div>
            </div>
            <ChevronRight class="w-4 h-4 muted md:hidden" />
            <GripVertical class="w-4 h-4 muted opacity-0 group-hover:opacity-100 cursor-grab shrink-0 hide-mobile" />
          </div>
        </div>
      </section>

      <!-- 3. Right Panel (Details) - Full width on mobile if entry selected -->
      <section 
        :class="['flex-1 flex flex-col min-w-0 bg-black/10', 
                 ui.currentEntryId ? 'flex' : 'hidden md:flex']"
      >
        <div v-if="!currentEntry" class="h-full flex flex-col items-center justify-center text-[var(--muted)] p-12 text-center">
          <Shield class="w-16 h-16 mb-6 opacity-10" />
          <p class="text-sm">选择一个条目查看详情</p>
        </div>
        
        <div v-else class="flex-1 flex flex-col overflow-hidden">
          <!-- Detail Header -->
          <div class="p-4 border-b border-white/5 flex items-center justify-between bg-black/20">
            <div class="flex items-center gap-3 min-w-0">
              <button class="btn ghost small md:hidden" @click="ui.currentEntryId = null">
                <ChevronRight class="w-5 h-5 rotate-180" />
              </button>
              <div class="min-w-0">
                <div class="flex items-center gap-2">
                  <h1 class="text-lg font-bold truncate">{{ currentEntry.title }}</h1>
                  <button class="p-1 hover:bg-white/5 rounded" @click="VaultService.updateEntry(vault!, currentEntry!.id, { favorite: !currentEntry!.favorite }); ui.isDirty = true">
                    <Star :class="['w-4 h-4', currentEntry.favorite ? 'text-[var(--warn)] fill-current' : 'muted']" />
                  </button>
                </div>
                <p class="text-[10px] muted uppercase tracking-wider mt-0.5">
                  分组: {{ vault?.groups.find(g => g.id === currentEntry?.groupId)?.name || '根分组' }}
                </p>
              </div>
            </div>
            <div class="flex gap-1.5 shrink-0">
              <button class="btn ghost small" @click="openEntryModal(currentEntry.id)" title="编辑">
                <Edit class="w-4 h-4" />
              </button>
              <button class="btn danger small" @click="deleteEntry" title="删除">
                <Trash2 class="w-4 h-4" />
              </button>
            </div>
          </div>

          <!-- Detail Body -->
          <div class="flex-1 overflow-y-auto p-5 space-y-6">
            <!-- Fields -->
            <div class="space-y-4">
              <div class="space-y-1.5">
                <label class="text-[10px] font-bold muted uppercase tracking-widest px-1">用户名</label>
                <div class="panel flex items-center justify-between gap-3">
                  <span class="font-mono text-sm truncate">{{ currentEntry.username || '—' }}</span>
                  <button v-if="currentEntry.username" class="btn ghost small p-1.5" @click="copyToClipboard(currentEntry.username)">
                    <Copy class="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div class="space-y-1.5">
                <label class="text-[10px] font-bold muted uppercase tracking-widest px-1">密码</label>
                <div class="panel flex items-center justify-between gap-3">
                  <span class="font-mono text-sm truncate">{{ entryForm.showPassword ? currentEntry.password : '••••••••••••' }}</span>
                  <div class="flex items-center gap-1">
                    <button class="btn ghost small p-1.5" @click="entryForm.showPassword = !entryForm.showPassword">
                      <EyeOff v-if="!entryForm.showPassword" class="w-4 h-4" />
                      <Eye v-else class="w-4 h-4" />
                    </button>
                    <button class="btn ghost small p-1.5" @click="copyToClipboard(currentEntry.password)">
                      <Copy class="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>

              <div class="space-y-1.5">
                <label class="text-[10px] font-bold muted uppercase tracking-widest px-1">URL</label>
                <div class="panel flex items-center justify-between gap-3">
                  <a :href="currentEntry.url" target="_blank" class="text-[var(--primary)] hover:underline text-sm truncate">{{ currentEntry.url || '—' }}</a>
                  <button v-if="currentEntry.url" class="btn ghost small p-1.5" @click="copyToClipboard(currentEntry.url)">
                    <Copy class="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

            <!-- Custom Fields -->
            <div v-if="currentEntry.customFields.length > 0" class="space-y-3">
              <h3 class="text-[10px] font-bold muted uppercase tracking-widest px-1">自定义字段</h3>
              <div class="grid grid-cols-1 gap-3">
                <div v-for="(field, idx) in currentEntry.customFields" :key="idx" class="panel space-y-1">
                  <label class="text-[10px] muted">{{ field.key }}</label>
                  <div class="flex items-center justify-between gap-3">
                    <span class="font-mono text-sm truncate">{{ field.value || '—' }}</span>
                    <button v-if="field.value" class="btn ghost small p-1.5" @click="copyToClipboard(field.value)">
                      <Copy class="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <!-- Tags & Notes -->
            <div class="space-y-4">
              <div v-if="currentEntry.tags.length > 0" class="space-y-2">
                <h3 class="text-[10px] font-bold muted uppercase tracking-widest px-1">标签</h3>
                <div class="flex flex-wrap gap-1.5">
                  <span v-for="tag in currentEntry.tags" :key="tag" class="tag">#{{ tag }}</span>
                </div>
              </div>

              <div v-if="currentEntry.notes" class="space-y-2">
                <h3 class="text-[10px] font-bold muted uppercase tracking-widest px-1">备注</h3>
                <div class="panel text-sm whitespace-pre-wrap leading-relaxed">
                  {{ currentEntry.notes }}
                </div>
              </div>

              <!-- Attachments in Details -->
              <div v-if="currentEntry.attachments && currentEntry.attachments.length > 0" class="space-y-3">
                <h3 class="text-[10px] font-bold muted uppercase tracking-widest px-1">附件 ({{ currentEntry.attachments.length }})</h3>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div v-for="att in currentEntry.attachments" :key="att.id" class="panel flex items-center justify-between gap-3 p-3">
                    <div class="flex items-center gap-3 min-w-0">
                      <div class="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center shrink-0">
                        <FileIcon class="w-4 h-4 muted" />
                      </div>
                      <div class="min-w-0">
                        <p class="text-xs font-medium truncate">{{ att.name }}</p>
                        <p class="text-[10px] muted">{{ formatSize(att.size) }}</p>
                      </div>
                    </div>
                    <button class="btn ghost small p-1.5" @click="downloadAttachment(att)" title="下载">
                      <Download class="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>

    <!-- Entry Modal -->
    <div v-if="ui.showEntryModal" class="modal">
      <div class="modal-card max-w-2xl">
        <div class="modal-head">
          <h2>{{ ui.editingEntryId ? '编辑条目' : '新建条目' }}</h2>
          <button class="btn ghost small" @click="ui.showEntryModal = false">✕</button>
        </div>
        <div class="modal-body space-y-4">
          <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label>标题</label>
              <input v-model="entryForm.title" type="text" />
            </div>
            <div>
              <label>分组</label>
              <select v-model="entryForm.groupId">
                <option v-for="g in vault?.groups" :key="g.id" :value="g.id">{{ g.name }}</option>
              </select>
            </div>
            <div>
              <label>用户名</label>
              <input v-model="entryForm.username" type="text" />
            </div>
            <div>
              <label>URL</label>
              <input v-model="entryForm.url" type="url" />
            </div>
            <div class="md:col-span-2">
              <label>密码</label>
              <div class="flex gap-2">
                <input v-model="entryForm.password" :type="entryForm.showPassword ? 'text' : 'password'" class="font-mono" />
                <button class="btn small ghost" @click="entryForm.showPassword = !entryForm.showPassword">
                  <EyeOff v-if="!entryForm.showPassword" class="w-4 h-4" />
                  <Eye v-else class="w-4 h-4" />
                </button>
              </div>
              <div class="mt-2 h-1.5 bg-black/20 rounded-full overflow-hidden">
                <div 
                  class="h-full transition-all duration-500" 
                  :style="{ 
                    width: (passwordStrength.score + 1) * 20 + '%',
                    backgroundColor: passwordStrength.score < 2 ? 'var(--danger)' : passwordStrength.score < 3 ? 'var(--warn)' : 'var(--ok)'
                  }"
                ></div>
              </div>
              <p class="text-[10px] muted mt-1">强度: {{ passwordStrength.label }} ({{ passwordStrength.bits }} bits)</p>
            </div>
          </div>

          <div>
            <label>标签 (逗号分隔)</label>
            <input v-model="entryForm.tags" type="text" placeholder="工作, 个人, 社交" />
          </div>

          <div>
            <label>备注</label>
            <textarea v-model="entryForm.notes" rows="3"></textarea>
          </div>

          <div class="flex items-center gap-2">
            <input v-model="entryForm.favorite" type="checkbox" id="favCheck" />
            <label for="favCheck" class="mb-0">标记为收藏</label>
          </div>

          <div class="space-y-2">
            <div class="flex items-center justify-between">
              <label class="mb-0">自定义字段</label>
              <button class="btn small ghost" @click="addCustomField"><Plus class="w-3 h-3" /> 添加</button>
            </div>
            <div v-for="(field, idx) in entryForm.customFields" :key="idx" class="flex gap-2">
              <input v-model="field.key" placeholder="Key" class="flex-1" />
              <input v-model="field.value" placeholder="Value" class="flex-1" />
              <button class="btn small danger" @click="removeCustomField(idx)"><Trash2 class="w-3 h-3" /></button>
            </div>
          </div>

          <!-- Attachments in Modal -->
          <div v-if="ui.editingEntryId" class="space-y-2">
            <div class="flex items-center justify-between">
              <label class="mb-0 flex items-center gap-1.5">
                附件
                <span v-if="!license.isPro" class="text-[9px] px-1.5 py-0.5 rounded bg-[var(--primary)]/10 text-[var(--primary)] font-bold">PRO</span>
              </label>
              <div class="flex items-center gap-2">
                <span v-if="ui.isProcessingAttachment" class="text-[10px] muted animate-pulse">处理中...</span>
                <label
                  class="btn small ghost cursor-pointer"
                  :class="[ui.isProcessingAttachment ? 'opacity-50 pointer-events-none' : '', !license.isPro ? 'opacity-50' : '']"
                >
                  <Paperclip class="w-3 h-3" /> 上传
                  <input type="file" class="hidden" @change="handleAttachmentUpload" :disabled="!license.isPro" />
                </label>
              </div>
            </div>
            <div v-if="entryForm.attachments && entryForm.attachments.length > 0" class="space-y-2">
              <div v-for="att in entryForm.attachments" :key="att.id" class="panel flex items-center justify-between gap-3 p-2">
                <div class="flex items-center gap-2 min-w-0">
                  <FileIcon class="w-3.5 h-3.5 muted shrink-0" />
                  <div class="min-w-0">
                    <p class="text-xs truncate">{{ att.name }}</p>
                    <p class="text-[9px] muted">{{ formatSize(att.size) }}</p>
                  </div>
                </div>
                <div class="flex items-center gap-1">
                  <button class="btn ghost small p-1" @click="downloadAttachment(att)" title="下载">
                    <Download class="w-3.5 h-3.5" />
                  </button>
                  <button class="btn ghost small p-1 text-[var(--danger)]" @click="deleteAttachment(att.id)" title="删除">
                    <Trash2 class="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
            <p v-else class="text-[10px] muted text-center py-2 border border-dashed border-white/10 rounded-lg">暂无附件</p>
          </div>
          <div v-else class="p-3 bg-black/20 rounded-lg text-center">
            <p class="text-[10px] muted">创建条目后即可上传附件</p>
          </div>

          <details class="border border-white/5 rounded-lg p-3 bg-black/5">
            <summary class="cursor-pointer text-sm muted">密码生成器</summary>
            <div class="mt-4 space-y-4">
              <div class="flex items-center gap-4">
                <label class="mb-0 text-xs">长度: {{ generator.length }}</label>
                <input v-model.number="generator.length" type="range" min="8" max="64" class="flex-1" />
              </div>
              <div class="flex flex-wrap gap-4 text-xs">
                <label class="flex items-center gap-1"><input v-model="generator.upper" type="checkbox" /> 大写</label>
                <label class="flex items-center gap-1"><input v-model="generator.lower" type="checkbox" /> 小写</label>
                <label class="flex items-center gap-1"><input v-model="generator.nums" type="checkbox" /> 数字</label>
                <label class="flex items-center gap-1"><input v-model="generator.syms" type="checkbox" /> 符号</label>
              </div>
              <div class="flex gap-2">
                <input v-model="generator.output" readonly class="font-mono text-sm bg-black/40" />
                <button class="btn small primary" @click="generatePassword">生成</button>
                <button class="btn small ghost" @click="useGeneratedPassword">应用</button>
              </div>
            </div>
          </details>

          <!-- Password History (Pro) -->
          <div v-if="ui.editingEntryId" class="space-y-2 pt-2 border-t border-white/5">
          <div class="flex items-center justify-between">
            <label class="mb-0 flex items-center gap-1.5 text-[var(--muted)]">
              密码历史记录
              <span v-if="!license.isPro" class="text-[9px] px-1.5 py-0.5 rounded bg-[var(--primary)]/10 text-[var(--primary)] font-bold">PRO</span>
            </label>
            <span class="text-[10px] muted">最多保存 5 条</span>
          </div>

            <div v-if="license.isPro && editingEntry?.passwordHistory?.length" class="space-y-1.5">
              <div v-for="(h, idx) in editingEntry.passwordHistory" :key="idx" class="panel flex items-center justify-between py-1.5 px-3 bg-black/10">
                <div class="flex flex-col min-w-0">
                  <span class="text-[9px] muted">{{ formatDate(h.date) }}</span>
                  <span class="font-mono text-xs truncate">{{ ui.showHistoryIdx === idx ? h.password : '••••••••' }}</span>
                </div>
                <div class="flex items-center gap-1">
                  <button class="btn ghost small p-1" @click="ui.showHistoryIdx = ui.showHistoryIdx === idx ? -1 : idx">
                    <Eye v-if="ui.showHistoryIdx !== idx" class="w-3 h-3" />
                    <EyeOff v-else class="w-3 h-3" />
                  </button>
                  <button class="btn ghost small p-1" @click="copyToClipboard(h.password)">
                    <Copy class="w-3 h-3" />
                  </button>
                </div>
              </div>
            </div>

            <p v-else-if="license.isPro" class="text-[10px] muted text-center py-2 border border-dashed border-white/10 rounded-lg">
              暂无历史记录。以后每次修改密码并保存，会自动记录上一条密码。
            </p>
            <p v-else class="text-[10px] muted text-center py-2 border border-dashed border-white/10 rounded-lg">
              该功能为 Pro 专属：激活授权后，会记录最近 5 次历史密码。
            </p>
          </div>
        </div>
        <div class="modal-foot">
          <button v-if="ui.editingEntryId" class="btn danger" @click="deleteEntry">删除</button>
          <div class="flex-1"></div>
          <button class="btn ghost mr-2" @click="ui.showEntryModal = false">取消</button>
          <button class="btn primary px-8" @click="saveEntry">保存</button>
        </div>
      </div>
    </div>

    <!-- Group Modal -->
    <div v-if="ui.showGroupModal" class="modal">
      <div class="modal-card max-w-md">
        <div class="modal-head">
          <h2>{{ ui.editingGroupId ? '编辑分组' : '新建分组' }}</h2>
          <button class="btn ghost small" @click="ui.showGroupModal = false">✕</button>
        </div>
        <div class="modal-body space-y-4">
          <div>
            <label>名称</label>
            <input v-model="groupForm.name" type="text" />
          </div>
          <div>
            <label>父分组</label>
            <select v-model="groupForm.parentId">
              <option v-if="vault" :value="vault.rootGroupId">数据库 (Root)</option>
              <template v-for="g in groupTree" :key="g.id">
                <option v-if="g.id !== ui.editingGroupId && g.depth < 3" :value="g.id">
                  {{ ' '.repeat(g.depth) }}{{ g.name }}
                </option>
              </template>
            </select>
          </div>
        </div>
        <div class="modal-foot">
          <button v-if="ui.editingGroupId" class="btn danger" @click="deleteGroup">删除</button>
          <div class="flex-1"></div>
          <button class="btn ghost mr-2" @click="ui.showGroupModal = false">取消</button>
          <button class="btn primary px-8" @click="saveGroup">保存</button>
        </div>
      </div>
    </div>

    <!-- Settings Modal -->
    <div v-if="ui.showSettings" class="modal">
      <div class="modal-card max-w-lg">
        <div class="modal-head">
          <h2 class="text-lg font-bold">设置</h2>
          <button class="btn ghost small" @click="ui.showSettings = false">✕</button>
        </div>
        
        <!-- Tabs -->
        <div class="flex border-b border-white/5 px-4">
          <button 
            v-for="tab in [{id:'info', label:'文件信息'}, {id:'security', label:'安全设置'}, {id:'license', label:'授权'}, {id:'about', label:'关于'}]" 
            :key="tab.id"
            @click="ui.settingsTab = tab.id as any"
            :class="['px-4 py-3 text-sm font-medium transition-colors border-b-2 -mb-[2px]', 
              ui.settingsTab === tab.id ? 'text-[var(--primary)] border-[var(--primary)]' : 'text-[var(--muted)] border-transparent hover:text-[var(--text)]']"
          >
            {{ tab.label }}
          </button>
        </div>

        <div class="modal-body overflow-y-auto">
          <!-- Tab: Info -->
          <div v-if="ui.settingsTab === 'info'" class="space-y-6">
            <div class="panel">
              <h3 class="text-sm font-bold mb-4">密码库详情</h3>
              <div class="space-y-4 text-sm">
                <div>
                  <label class="text-xs muted mb-1 block">密码库名称</label>
                  <div class="flex gap-2">
                    <input v-model="ui.tempVaultName" type="text" class="flex-1" placeholder="1-32位，支持中文/英文/数字/空格/-/_" />
                    <button class="btn primary small" @click="saveVaultName">保存</button>
                  </div>
                  <p v-if="ui.vaultNameMsg" :class="['text-[10px] mt-1', ui.vaultNameMsgType === 'error' ? 'text-[var(--danger)]' : 'text-[var(--ok)]']">
                    {{ ui.vaultNameMsg }}
                  </p>
                </div>
                <div class="flex justify-between"><span class="muted">文件路径</span><span class="truncate ml-4">{{ fileName }}</span></div>
                <div class="flex justify-between"><span class="muted">条目总数</span><span>{{ vault?.entries.length }}</span></div>
                <div class="flex justify-between"><span class="muted">分组总数</span><span>{{ vault?.groups.length }}</span></div>
                <div class="flex justify-between"><span class="muted">创建时间</span><span>{{ vault?.createdAt ? new Date(vault.createdAt).toLocaleString() : '-' }}</span></div>
              </div>
            </div>
            <div v-if="encryptedVault" class="panel">
              <h3 class="text-sm font-bold mb-4">加密信息</h3>
              <div class="space-y-4 text-sm">
                <div class="flex justify-between"><span class="muted">加密算法</span><span>{{ encryptedVault?.cipher?.name || 'AES-256-GCM' }}</span></div>
                <div class="flex justify-between"><span class="muted">密钥派生函数</span><span>{{ encryptedVault?.kdf?.name || 'PBKDF2' }}</span></div>
                <div class="flex justify-between"><span class="muted">迭代次数</span><span>{{ encryptedVault?.kdf?.iterations ?? 200000 }}</span></div>
                <div class="flex justify-between"><span class="muted">密钥文件</span><span>{{ encryptedVault?.factors?.keyfile ? '已启用' : '未启用' }}</span></div>
              </div>
              <p class="text-[10px] muted mt-3">用于高级用户在紧急情况下手动解密。</p>
            </div>

            <div class="panel space-y-4">
              <h3 class="text-sm font-bold">文件内容</h3>
              <button class="btn ghost w-full border border-white/10" @click="viewVaultJson">
                <FileJson class="w-4 h-4" /> 查看 JSON 内容
              </button>
            </div>


            <div :class="['p-3 rounded-lg border text-xs', canWriteBack ? 'bg-[var(--ok)]/5 border-[var(--ok)]/20 text-[var(--ok)]' : 'bg-[var(--warn)]/5 border-[var(--warn)]/20 text-[var(--warn)]']">
              {{ canWriteBack ? '✓ 支持直接写回原文件' : '⚠ 当前为只读/下载模式，保存将下载新文件' }}
            </div>
          </div>

          <!-- Tab: Security -->
          <div v-if="ui.settingsTab === 'security'" class="space-y-6">
            <div class="panel">
              <h3 class="text-sm font-bold mb-4">常规安全</h3>
              
              <div class="space-y-4">
                <div class="flex items-center gap-4">
                  <label class="mb-0 text-sm w-36 shrink-0">自动锁定 (分钟)</label>
                  <input v-if="vault" v-model.number="vault.settings.autoLockMinutes" type="number" class="flex-1" />
                </div>
                <div class="flex items-center gap-4">
                  <label class="mb-0 text-sm w-36 shrink-0">剪贴板清空 (秒)</label>
                  <input v-if="vault" v-model.number="vault.settings.clipboardClearSeconds" type="number" class="flex-1" />
                </div>
              </div>

            </div>

            <div class="panel">
              <h3 class="text-sm font-bold mb-4">2FA (Keyfile) 管理</h3>
              <div class="space-y-4">
                <div class="flex items-center justify-between">
                  <div class="text-sm">
                    <p class="font-medium">状态: {{ encryptedVault?.factors?.keyfile ? '已启用' : '未启用' }}</p>
                    <p class="text-xs muted">启用 2FA 后，解锁需要主密码和密钥文件。</p>
                  </div>
                  <div v-if="encryptedVault?.factors?.keyfile" class="flex gap-2">
                    <label class="btn ghost small cursor-pointer">
                      替换
                      <input type="file" class="hidden" @change="(e) => manageKeyfile('replace', e)" />
                    </label>
                    <button class="btn danger small" @click="manageKeyfile('delete')">移除</button>
                  </div>
                  <div v-else>
                    <label class="btn primary small cursor-pointer">
                      添加 Keyfile
                      <input type="file" class="hidden" @change="(e) => manageKeyfile('add', e)" />
                    </label>
                  </div>
                </div>
                <p v-if="ui.keyfileMsg" :class="['text-xs text-center p-2 rounded-lg', ui.keyfileMsgType === 'error' ? 'bg-[var(--danger)]/10 text-[var(--danger)]' : 'bg-[var(--ok)]/10 text-[var(--ok)]']">
                  {{ ui.keyfileMsg }}
                </p>
              </div>
            </div>

            <div class="panel">
              <h3 class="text-sm font-bold mb-4">修改主密码</h3>
              <div class="space-y-3">
                <div>
                  <label class="text-xs muted mb-1">当前主密码</label>
                  <input v-model="ui.changePw.old" type="password" placeholder="验证当前身份" />
                </div>
                <div>
                  <label class="text-xs muted mb-1">新主密码</label>
                  <input v-model="ui.changePw.new" type="password" placeholder="至少 8 位" />
                </div>
                <div>
                  <label class="text-xs muted mb-1">确认新主密码</label>
                  <input v-model="ui.changePw.confirm" type="password" placeholder="再次输入" />
                </div>
                <button class="btn primary w-full mt-2" @click="changeMasterPassword">更新主密码</button>
                <p v-if="ui.changePw.msg" :class="['text-xs text-center mt-2', ui.changePw.msgType === 'error' ? 'text-[var(--danger)]' : 'text-[var(--ok)]']">
                  {{ ui.changePw.msg }}
                </p>
              </div>
            </div>
          </div>

          <!-- Tab: License -->
          <div v-if="ui.settingsTab === 'license'" class="space-y-6">
            <div class="panel">
              <h3 class="text-sm font-bold mb-4">授权管理</h3>
              <div class="space-y-4">
                <div :class="['p-4 rounded-lg border flex items-center gap-4', 
                  license.statusType === 'ok' ? 'bg-[var(--ok)]/5 border-[var(--ok)]/20 text-[var(--ok)]' : 
                  license.statusType === 'error' ? 'bg-[var(--danger)]/5 border-[var(--danger)]/20 text-[var(--danger)]' : 
                  'bg-white/5 border-white/10 text-[var(--muted)]']">
                  <div class="w-10 h-10 rounded-full bg-current/10 flex items-center justify-center shrink-0">
                    <Shield v-if="license.isPro" class="w-5 h-5" />
                    <User v-else class="w-5 h-5" />
                  </div>
                  <div class="min-w-0">
                    <p class="font-bold text-sm">{{ license.statusText }}</p>
                    <p v-if="license.payload?.id" class="text-[10px] opacity-70 truncate">ID: {{ license.payload.id }}</p>
                    <p v-if="license.payload?.exp" class="text-[10px] opacity-70">有效期至: {{ license.payload.exp }}</p>
                  </div>
                </div>

                <div v-if="!license.isPro" class="space-y-3">
                  <p class="text-xs muted">输入您的 License Key 以激活 Pro 功能（如附件加密、高级搜索等）。</p>
                  <div class="flex gap-2">
                    <input v-model="license.keyInput" type="text" placeholder="payload.signature" class="flex-1" />
                    <button class="btn primary small" @click="verifyAndActivateLicense">激活</button>
                  </div>
                </div>
                <div v-else class="pt-2">
                  <button class="btn ghost small w-full border border-white/10" @click="clearLicense">清除授权</button>
                </div>
              </div>
            </div>

            <div class="panel">
              <h3 class="text-sm font-bold mb-4">Pro 功能列表</h3>
              <div class="space-y-2 text-xs">
                <div class="flex items-center gap-2"><div class="w-1.5 h-1.5 rounded-full bg-[var(--ok)]"></div> 附件加密存储 (AES-GCM)</div>
                <div class="flex items-center gap-2"><div class="w-1.5 h-1.5 rounded-full bg-[var(--ok)]"></div> 离线压缩 (Gzip)</div>
                <div class="flex items-center gap-2"><div class="w-1.5 h-1.5 rounded-full bg-[var(--ok)]"></div> 密码库多重加密 (Keyfile)</div>
                <div class="flex items-center gap-2"><div class="w-1.5 h-1.5 rounded-full bg-[var(--ok)]"></div> 更多高级功能即将推出...</div>
              </div>
            </div>
          </div>

          <!-- Tab: About -->
          <div v-if="ui.settingsTab === 'about'" class="space-y-6 text-center py-4">
            <div class="flex flex-col items-center">
              <Shield class="w-16 h-16 text-[var(--primary)] mb-4 opacity-20" />
              <h3 class="text-xl font-bold">Midkey Vault</h3>
              <p class="text-sm muted">版本 1.0.0 (Stable)</p>
            </div>
            
            <div class="panel text-left">
              <p class="text-sm mb-4">Midkey Vault 是一个完全运行在浏览器中的离线密码管理器。它使用 AES-256-GCM 加密您的数据，且绝不会将您的密码上传到任何服务器。</p>
              <div class="space-y-2 text-sm">
                <p>• 100% 客户端加密</p>
                <p>• 主密码 + 可选密钥文件 (Keyfile)</p>
                <p>• 响应式设计，支持移动端</p>
              </div>
            </div>

            <div class="pt-4">
              <p class="text-xs muted mb-4">如果您觉得这个工具有所帮助，欢迎支持开发者</p>
              <div class="flex justify-center gap-4">
                <button class="btn ghost small border border-white/10">☕ 请喝咖啡</button>
                <button class="btn ghost small border border-white/10">⭐ 捐赠支持</button>
              </div>
            </div>
          </div>
        </div>

        <div class="modal-foot">
          <div class="flex-1"></div>
          <button class="btn primary px-8" @click="ui.showSettings = false">确定</button>
        </div>
      </div>
    </div>

    <!-- Logout Confirmation Modal -->
    <div v-if="ui.showLogoutConfirm" class="modal">
      <div class="modal-card max-w-sm">
        <div class="modal-head">
          <h2 class="text-lg font-bold">确认退出</h2>
          <button class="btn ghost small" @click="ui.showLogoutConfirm = false">✕</button>
        </div>
        <div class="modal-body py-8 text-center">
          <p class="text-sm mb-2">您有未保存的更改。</p>
          <p class="text-xs muted">退出后未保存的数据将会丢失，是否确认退出？</p>
        </div>
        <div class="modal-foot gap-3">
          <button class="btn ghost flex-1" @click="ui.showLogoutConfirm = false">取消</button>
          <button class="btn danger flex-1" @click="logout">确认退出</button>
        </div>
      </div>
    </div>

    <!-- View JSON Modal -->
    <div v-if="ui.showJsonModal" class="modal">
      <div class="modal-card max-w-2xl">
        <div class="modal-head">
          <h2 class="text-lg font-bold">Vault JSON 内容</h2>
          <button class="btn ghost small" @click="ui.showJsonModal = false">✕</button>
        </div>
        <div class="modal-body">
          <p class="text-xs muted mb-4">这是您的加密密码库数据。您可以将其复制并保存到文本文件中。请确保不要泄露此内容。</p>
          <textarea 
            readonly 
            class="w-full h-64 font-mono text-[10px] p-3 bg-black/20 border border-white/5 rounded-lg focus:outline-none"
            v-model="ui.jsonContent"
          ></textarea>
        </div>
        <div class="modal-foot gap-3">
          <button class="btn ghost flex-1" @click="ui.showJsonModal = false">关闭</button>
          <button class="btn primary flex-1" @click="copyToClipboard(ui.jsonContent)">
            <Copy class="w-4 h-4" /> 复制到剪贴板
          </button>
        </div>
      </div>
    </div>

    <!-- Privacy Modal -->
    <div v-if="ui.showPrivacyModal" class="modal">
      <div class="modal-card max-w-lg">
        <div class="modal-head">
          <h2 class="text-lg font-bold">隐私声明</h2>
          <button class="btn ghost small" @click="ui.showPrivacyModal = false">✕</button>
        </div>
        <div class="modal-body space-y-6">
          <section>
            <h3 class="text-sm font-bold mb-2 flex items-center gap-2">
              <Shield class="w-4 h-4 text-[var(--primary)]" /> 数据存储方式
            </h3>
            <p class="text-xs muted leading-relaxed">
              所有用户数据均保存在本地浏览器或用户设备上，不会上传到任何服务器或云端。您的密码库完全由您自己掌控。
            </p>
          </section>

          <section>
            <h3 class="text-sm font-bold mb-2 flex items-center gap-2">
              <Lock class="w-4 h-4 text-[var(--primary)]" /> 加密方式
            </h3>
            <p class="text-xs muted leading-relaxed">
              使用 AES-256 + PBKDF2 或零知识加密算法保护数据安全。加密过程完全在本地执行，主密码不会离开您的设备。
            </p>
          </section>

          <section>
            <h3 class="text-sm font-bold mb-2 flex items-center gap-2">
              <EyeOff class="w-4 h-4 text-[var(--primary)]" /> 访问权限
            </h3>
            <p class="text-xs muted leading-relaxed">
              本网站/应用不会收集用户任何个人信息、主密码或存储的账户凭据。我们无法访问您的任何数据。
            </p>
          </section>

          <section>
            <h3 class="text-sm font-bold mb-2 flex items-center gap-2">
              <Sparkles class="w-4 h-4 text-[var(--primary)]" /> 第三方声明
            </h3>
            <p class="text-xs muted leading-relaxed">
              所有加密和存储功能均在浏览器端执行。我们不使用任何第三方分析工具或追踪脚本。
            </p>
          </section>

          <section class="pt-4 border-t border-white/5">
            <h3 class="text-sm font-bold mb-2">联系方式</h3>
            <p class="text-xs muted">
              如有问题，请访问官网：<a href="https://www.midkey.xyz" target="_blank" class="text-[var(--primary)] hover:underline">https://www.midkey.xyz</a>
            </p>
          </section>
        </div>
        <div class="modal-foot">
          <button class="btn primary w-full" @click="ui.showPrivacyModal = false">我已了解</button>
        </div>
      </div>
    </div>

    <!-- Help Modal -->
    <div v-if="ui.showHelpModal" class="modal">
      <div class="modal-card max-w-lg">
        <div class="modal-head">
          <h2 class="text-lg font-bold">帮助手册</h2>
          <button class="btn ghost small" @click="ui.showHelpModal = false">✕</button>
        </div>
        
        <!-- Tabs -->
        <div class="flex border-b border-white/5 bg-black/10">
          <button 
            class="flex-1 px-4 py-3 text-sm font-medium transition-all border-b-2"
            :class="ui.helpTab === 'usage' ? 'border-[var(--primary)] text-[var(--primary)] bg-[var(--primary)]/10' : 'border-transparent text-[var(--muted)] hover:text-[var(--text)] hover:bg-white/5'"
            @click="ui.helpTab = 'usage'"
          >
            使用说明
          </button>
          <button 
            class="flex-1 px-4 py-3 text-sm font-medium transition-all border-b-2"
            :class="ui.helpTab === 'faq' ? 'border-[var(--primary)] text-[var(--primary)] bg-[var(--primary)]/10' : 'border-transparent text-[var(--muted)] hover:text-[var(--text)] hover:bg-white/5'"
            @click="ui.helpTab = 'faq'"
          >
            常见问题
          </button>
        </div>

        <div class="modal-body space-y-6 overflow-y-auto">
          <!-- Usage Tab -->
          <div v-if="ui.helpTab === 'usage'" class="space-y-6">
            <section>
              <h3 class="text-sm font-bold mb-2 flex items-center gap-2 text-[var(--text)]">
                <Plus class="w-4 h-4 text-[var(--primary)]" /> 创建与打开
              </h3>
              <p class="text-xs text-[var(--text)] opacity-70 leading-relaxed">
                首次使用请点击“创建新密码库”；已有用户请点击“打开 Vault”选择您的 JSON 文件。
              </p>
            </section>

            <section>
              <h3 class="text-sm font-bold mb-2 flex items-center gap-2 text-[var(--text)]">
                <Lock class="w-4 h-4 text-[var(--primary)]" /> 主密码安全
              </h3>
              <p class="text-xs text-[var(--text)] opacity-70 leading-relaxed">
                主密码是解锁数据的唯一凭据。由于数据完全本地加密，如果您丢失了主密码，我们将无法帮您找回数据。
              </p>
            </section>

            <section>
              <h3 class="text-sm font-bold mb-2 flex items-center gap-2 text-[var(--text)]">
                <Save class="w-4 h-4 text-[var(--primary)]" /> 保存与备份
              </h3>
              <p class="text-xs text-[var(--text)] opacity-70 leading-relaxed">
                每次修改后请点击顶部的“保存”按钮。建议定期通过“设置”导出并备份您的 JSON 文件到安全的地方。
              </p>
            </section>

            <section>
              <h3 class="text-sm font-bold mb-2 flex items-center gap-2 text-[var(--text)]">
                <Shield class="w-4 h-4 text-[var(--primary)]" /> 离线使用
              </h3>
              <p class="text-xs text-[var(--text)] opacity-70 leading-relaxed">
                本应用支持完全离线使用。为了极致安全，您可以在加载页面后断开网络连接进行所有操作。
              </p>
            </section>

            <section>
              <h3 class="text-sm font-bold mb-2 flex items-center gap-2 text-[var(--text)]">
                <Search class="w-4 h-4 text-[var(--primary)]" /> 快捷操作
              </h3>
              <p class="text-xs text-[var(--text)] opacity-70 leading-relaxed">
                使用 Ctrl+F (或 Cmd+F) 快速聚焦搜索框。点击条目右侧的图标可快速复制用户名或密码。
              </p>
            </section>
          </div>

          <!-- FAQ Tab -->
          <div v-else-if="ui.helpTab === 'faq'" class="space-y-4">
            <div v-for="(item, idx) in [
              { q: 'Midkey Vault 会上传我的密码吗？', a: '不会。所有加密和解密都在浏览器本地完成，密码不会上传到服务器。' },
              { q: '忘记主密码怎么办？', a: '主密码无法恢复。如果忘记主密码，数据库将无法解密。' },
              { q: '我的密码保存在哪里？', a: '保存在本地的数据库 JSON 文件中，需要主密码才能打开。' },
              { q: '数据库文件安全吗？', a: '是安全的。文件中的数据已经加密，没有主密码无法查看。' },
              { q: '可以备份数据库吗？', a: '可以。只需要备份数据库 JSON 文件即可。' },
              { q: '可以修改数据库文件名吗？', a: '可以。文件名不会影响数据库内容。' },
              { q: 'Midkey Vault 需要联网吗？', a: '不需要。创建、打开、编辑数据库都可以离线完成。' },
              { q: '支持哪些浏览器？', a: '推荐使用 Chrome、Edge、Firefox 或 Safari。' },
              { q: '数据库文件可以放在云盘吗？', a: '可以。因为数据是加密的，放在云盘也不会泄露密码。' },
              { q: 'Midkey Vault 适合谁使用？', a: '适合希望自己掌控密码数据、喜欢离线密码管理的用户。' }
            ]" :key="idx" class="border-b border-white/5 pb-3 last:border-0">
              <h4 class="text-xs font-bold text-[var(--text)] mb-1">{{ idx + 1 }}. {{ item.q }}</h4>
              <p class="text-xs text-[var(--text)] opacity-70 leading-relaxed">{{ item.a }}</p>
            </div>
          </div>
        </div>
        <div class="modal-foot">
          <button class="btn primary w-full" @click="ui.showHelpModal = false">开始使用</button>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
@reference "tailwindcss";

.modal {
  @apply fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50;
}

.modal-card {
  @apply bg-[var(--panel)] border border-white/10 rounded-[var(--radius)] shadow-2xl w-full max-h-[90vh] flex flex-col overflow-hidden;
}

.modal-head {
  @apply p-4 border-b border-white/5 flex items-center justify-between;
}

.modal-body {
  @apply p-6 overflow-y-auto;
}

.modal-foot {
  @apply p-4 border-t border-white/5 bg-black/10 flex items-center;
}

.panel {
  @apply bg-black/10 border border-white/5 rounded-xl p-4;
}

label {
  @apply block text-xs font-medium text-[var(--muted)] mb-1.5;
}

.muted {
  @apply text-[var(--muted)];
}

::-webkit-scrollbar {
  width: 6px;
}

::-webkit-scrollbar-track {
  background: transparent;
}

::-webkit-scrollbar-thumb {
  @apply bg-white/10 rounded-full;
}

::-webkit-scrollbar-thumb:hover {
  @apply bg-white/20;
}
</style>
