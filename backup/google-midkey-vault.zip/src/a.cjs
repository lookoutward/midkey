const crypto = require('crypto');

/**
 * --- 配置信息 ---
 * 请确保这里的私钥与你前端代码中的公钥是一对
 */
const PRIVATE_KEY_B64 = 'EwwbC4sXM4hFtrK3pCRt__Du-_bBYn6icVspc9EuUHo';

// Ed25519 私钥初始化
const privBuffer = Buffer.from(PRIVATE_KEY_B64, 'base64url');
const pkcs8Header = Buffer.from([
  0x30, 0x2e, 0x02, 0x01, 0x00, 0x30, 0x05, 0x06, 0x03, 0x2b, 0x65, 0x70, 0x04, 0x22, 0x04, 0x20
]);
const privateKey = crypto.createPrivateKey({
  key: Buffer.concat([pkcs8Header, privBuffer]),
  format: 'der',
  type: 'pkcs8'
});

/**
 * 生成长授权码
 * @param {string} vaultId - 完整的 Vault ID (例如 vault_JoZSRs...)
 * @param {string} plan - 'pro' | 'free'
 * @param {string} expDate - 过期日期 (例如 '2030-01-01')
 */
function generateLicense(vaultId, plan, expDate) {
  // 1. 构建明文负载 (Payload)
  // 包含版本、ID、计划、过期时间、签发时间
  const payload = {
    v: 1,
    id: vaultId,
    plan: plan,
    exp: new Date(expDate).toISOString(),
    iat: new Date().toISOString()
  };

  // 2. 序列化并转为 Base64URL (这是授权码的前半部分)
  const payloadStr = JSON.stringify(payload);
  const payloadB64 = Buffer.from(payloadStr).toString('base64url');

  // 3. 使用 Ed25519 进行数字签名
  // 签名对象是 payloadB64 字符串本身
  const signature = crypto.sign(null, Buffer.from(payloadB64), privateKey);
  const sigB64 = signature.toString('base64url');

  // 4. 拼接最终授权码: Payload.Signature
  return `${payloadB64}.${sigB64}`;
}

// --- 自动化生成逻辑 ---

// 这里的 ID 必须和你图片中显示的 vaultId 完全一致
const MY_VAULT_ID = 'vault_JoZSRsyUatQS8AiQ1OMQeQ'; 

console.log('-------------------------------------------');
console.log('   Midkey Vault 授权码生成工具 (安全长码版)');
console.log('-------------------------------------------');
console.log('目标 Vault ID:', MY_VAULT_ID);

const licenseKey = generateLicense(MY_VAULT_ID, 'pro', '2030-01-01');

console.log('\n生成的授权码 (直接复制全段):');
console.log('-------------------------------------------');
console.log(licenseKey);
console.log('-------------------------------------------');

/**
 * 自检逻辑: 模拟前端验证程序
 */
function selfTest(key) {
  const [pB64, sB64] = key.split('.');
  const data = JSON.parse(Buffer.from(pB64, 'base64url').toString());
  console.log('\n[自检] 解析结果:');
  console.log('- 绑定 ID:', data.id);
  console.log('- 方案:', data.plan);
  console.log('- 有效期:', data.exp);
}

selfTest(licenseKey);