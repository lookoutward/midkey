export type ThreatType = 
  | 'EAVESDROPPING' // 监听攻击 -> AES
  | 'MITM'         // 中间人攻击 -> 数字证书/TLS
  | 'REPLAY'       // 重放攻击 -> HMAC + Nonce
  | 'RAINBOW_TABLE'// 彩虹表 -> Salt + bcrypt
  | 'QUANTUM'      // 量子攻击 -> Kyber
  | 'DB_LEAK'      // 数据库泄漏 -> 加密存储
  | 'SIDE_CHANNEL' // 侧信道攻击 -> 常量时间操作
  | 'KEY_LEAK'     // 密钥泄露 -> 公钥加密
  | 'DANGER'       // 红色/白色威胁块（不可点击，干扰块）
  | 'COMBINED';    // 组合块 (AES + HMAC)

export type ToolType =
  | 'AES'
  | 'CERT_TLS'
  | 'HMAC_NONCE'
  | 'SALT_BCRYPT'
  | 'KYBER'
  | 'ENC_STORAGE'
  | 'CONST_TIME'
  | 'ASYM_KEY'
  | 'NONE'; // For danger block click, representing failure or no defense tool

export interface CryptographyInfo {
  name: string;
  threatName: string;
  threatDesc: string;
  toolName: string;
  toolDesc: string;
  easyExplain: string; // 浅显易懂的比喻
  expertExplain: string; // 密码学专业术语说明
  icon: string;
}

export interface LevelConfig {
  id: number;
  name: string;
  bpm: number;
  speed: number; // Downward scroll rate
  spawnInterval: number; // spawn rate in ms
  duration: number; // total duration in seconds
  activeThreats: ThreatType[]; // Threats appearing in this level
  dangerProbability: number; // Probability of showing danger blocks (0 to 1)
  bossWave?: boolean; // Whether is a boss level
  scoreThreshold: number; // Score to pass level
  initialHealth?: number; // Initial health (default 5)
}

export interface Chapter {
  id: number;
  title: string;
  subtitle: string;
  description: string;
  unlockedAt: number; // Levels count
  levels: LevelConfig[];
}

export interface GameState {
  score: number;
  combo: number;
  maxCombo: number;
  health: number; // 0 to 100
  levelId: number;
  chapterId: number;
  isPlaying: boolean;
  isPaused: boolean;
  isFinished: boolean;
  unlockedTools: ToolType[];
  accuracy: number; // percentage of correct hits
  totalSpawned: number;
  hits: number;
  misses: number;
}
