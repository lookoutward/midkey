import { LevelConfig, Chapter, ToolType, ThreatType } from '../types';

// Comprehensive tool and threat registry
export const CRYPTOGRAPHY_REGISTRY: Record<ToolType, { 
  name: string; 
  color: string; 
  description: string;
  unlockLevel: number;
}> = {
  'AES': {
    name: '对称加密 (AES)',
    color: '#3b82f6',
    description: '使用相同的密钥进行数据加解密，速度快，适合大规模数据。',
    unlockLevel: 1
  },
  'CERT_TLS': {
    name: '数字证书 (TLS)',
    color: '#a855f7',
    description: '通过受信任的第三方（CA）验证服务器身份，防止中间人攻击。',
    unlockLevel: 2
  },
  'HMAC_NONCE': {
    name: '一次性随机数 (Nonce)',
    color: '#eab308',
    description: '在通信中加入只使用一次的随机数，防止重放攻击。',
    unlockLevel: 2
  },
  'SALT_BCRYPT': {
    name: '密码哈希 (bcrypt)',
    color: '#f97316',
    description: '为每个密码添加独特的"盐"值并进行慢速哈希，对抗彩虹表。',
    unlockLevel: 3
  },
  'KYBER': {
    name: '后量子加密 (Kyber)',
    color: '#06b6d4',
    description: '基于格密码学的算法，能够抵御未来量子计算机的破解。',
    unlockLevel: 4
  },
  'ENC_STORAGE': {
    name: '透明存储加密',
    color: '#ec4899',
    description: '在数据写入硬盘前自动加密，即使物理介质被盗也无法读取。',
    unlockLevel: 5
  },
  'CONST_TIME': {
    name: '常量时间操作',
    color: '#22c55e',
    description: '确保代码执行时间不随输入数据变化，防止旁道攻击。',
    unlockLevel: 6
  },
  'ASYM_KEY': {
    name: '公钥加密 (RSA/ECC)',
    color: '#ef4444',
    description: '使用公钥加密、私钥解密，实现无需事先交换密钥的安全通信。',
    unlockLevel: 7
  },
  'NONE': {
    name: '无防御',
    color: '#9ca3af',
    description: '未激活任何防御机制。',
    unlockLevel: 999
  }
};

export const THREAT_REGISTRY: Record<ThreatType, { 
  name: string; 
  color: string; 
  description: string;
  emoji: string;
}> = {
  'EAVESDROPPING': {
    name: '流量窃听',
    color: '#3b82f6',
    description: '攻击者在网络链路中截获并读取传输的数据内容。',
    emoji: '📡'
  },
  'MITM': {
    name: '中间人劫持',
    color: '#a855f7',
    description: '攻击者伪装成通信双方，拦截、窃取甚至篡改通信内容。',
    emoji: '👺'
  },
  'REPLAY': {
    name: '重放攻击',
    color: '#eab308',
    description: '攻击者截获合法的数据包后，重新发送以达到欺骗目的。',
    emoji: '🔄'
  },
  'RAINBOW_TABLE': {
    name: '彩虹表爆破',
    color: '#f97316',
    description: '使用预先计算好的哈希值表，快速反查原始密码。',
    emoji: '🌈'
  },
  'QUANTUM': {
    name: '量子毁灭',
    color: '#06b6d4',
    description: '利用量子计算机的超强算力，瞬间破解传统加密算法。',
    emoji: '💥'
  },
  'DB_LEAK': {
    name: '数据库拖库',
    color: '#ec4899',
    description: '攻击者通过SQL注入等手段，批量窃取数据库中的所有用户数据。',
    emoji: '🗄️'
  },
  'SIDE_CHANNEL': {
    name: '侧信道探测',
    color: '#22c55e',
    description: '通过分析硬件功耗、电磁辐射或运算时间，间接破解密钥。',
    emoji: '🕵️'
  },
  'KEY_LEAK': {
    name: '密钥泄露',
    color: '#ef4444',
    description: '由于存储不当或内部人员泄露，加密密钥被攻击者获取。',
    emoji: '🔓'
  },
  'DANGER': {
    name: '致命漏洞',
    color: '#dc2626',
    description: '高危漏洞，必须立即处理！',
    emoji: '⚠️'
  },
  'COMBINED': {
    name: '复合攻击',
    color: '#6366f1',
    description: '多种攻击方式组合使用，防御难度极高。',
    emoji: '🔮'
  }
};

// 预设关卡 (10关)
// 所有关卡统一：10组，满分10分，每组5个小方块
// 速度1.25倍递增
export const PRESET_LEVELS: LevelConfig[] = [
  {
    id: 1,
    name: '01 节点拦截风暴',
    bpm: 80,
    speed: 100,
    spawnInterval: 2000,
    duration: 100,
    activeThreats: ['EAVESDROPPING', 'REPLAY', 'MITM', 'RAINBOW_TABLE', 'QUANTUM', 'DB_LEAK', 'SIDE_CHANNEL', 'KEY_LEAK'],
    dangerProbability: 0,
    scoreThreshold: 10,
    initialHealth: 10
  },
  {
    id: 2,
    name: '02 系统背景暗杂',
    bpm: 85,
    speed: 125,
    spawnInterval: 2000,
    duration: 100,
    activeThreats: ['EAVESDROPPING', 'REPLAY', 'MITM', 'RAINBOW_TABLE', 'QUANTUM', 'DB_LEAK', 'SIDE_CHANNEL', 'KEY_LEAK'],
    dangerProbability: 0.1,
    scoreThreshold: 10,
    initialHealth: 10
  },
  {
    id: 3,
    name: '03 全对称加密极限',
    bpm: 90,
    speed: 156,
    spawnInterval: 2000,
    duration: 100,
    activeThreats: ['EAVESDROPPING', 'REPLAY', 'MITM', 'RAINBOW_TABLE', 'QUANTUM', 'DB_LEAK', 'SIDE_CHANNEL', 'KEY_LEAK'],
    dangerProbability: 0.15,
    scoreThreshold: 10,
    initialHealth: 10
  },
  {
    id: 4,
    name: '04 指令篡改迷局',
    bpm: 95,
    speed: 195,
    spawnInterval: 2000,
    duration: 100,
    activeThreats: ['EAVESDROPPING', 'REPLAY', 'MITM', 'RAINBOW_TABLE', 'QUANTUM', 'DB_LEAK', 'SIDE_CHANNEL', 'KEY_LEAK'],
    dangerProbability: 0.2,
    scoreThreshold: 10,
    initialHealth: 10
  },
  {
    id: 5,
    name: '05 爆破彩虹云端',
    bpm: 100,
    speed: 244,
    spawnInterval: 2000,
    duration: 100,
    activeThreats: ['EAVESDROPPING', 'REPLAY', 'MITM', 'RAINBOW_TABLE', 'QUANTUM', 'DB_LEAK', 'SIDE_CHANNEL', 'KEY_LEAK'],
    dangerProbability: 0.25,
    scoreThreshold: 10,
    initialHealth: 10
  },
  {
    id: 6,
    name: '06 完整性协议誓约',
    bpm: 105,
    speed: 305,
    spawnInterval: 2000,
    duration: 100,
    activeThreats: ['EAVESDROPPING', 'REPLAY', 'MITM', 'RAINBOW_TABLE', 'QUANTUM', 'DB_LEAK', 'SIDE_CHANNEL', 'KEY_LEAK'],
    dangerProbability: 0.3,
    scoreThreshold: 10,
    initialHealth: 10,
    bossWave: true
  },
  {
    id: 7,
    name: '07 劫持透明网络',
    bpm: 110,
    speed: 381,
    spawnInterval: 2000,
    duration: 100,
    activeThreats: ['EAVESDROPPING', 'REPLAY', 'MITM', 'RAINBOW_TABLE', 'QUANTUM', 'DB_LEAK', 'SIDE_CHANNEL', 'KEY_LEAK'],
    dangerProbability: 0.35,
    scoreThreshold: 10,
    initialHealth: 10
  },
  {
    id: 8,
    name: '08 拖库灾厄预警',
    bpm: 115,
    speed: 477,
    spawnInterval: 2000,
    duration: 100,
    activeThreats: ['EAVESDROPPING', 'REPLAY', 'MITM', 'RAINBOW_TABLE', 'QUANTUM', 'DB_LEAK', 'SIDE_CHANNEL', 'KEY_LEAK'],
    dangerProbability: 0.4,
    scoreThreshold: 10,
    initialHealth: 10
  },
  {
    id: 9,
    name: '09 完美传输会合',
    bpm: 120,
    speed: 596,
    spawnInterval: 2000,
    duration: 100,
    activeThreats: ['EAVESDROPPING', 'REPLAY', 'MITM', 'RAINBOW_TABLE', 'QUANTUM', 'DB_LEAK', 'SIDE_CHANNEL', 'KEY_LEAK'],
    dangerProbability: 0.45,
    scoreThreshold: 10,
    initialHealth: 10,
    bossWave: true
  },
  {
    id: 10,
    name: '10 微秒级影子幽灵',
    bpm: 125,
    speed: 745,
    spawnInterval: 2000,
    duration: 100,
    activeThreats: ['EAVESDROPPING', 'REPLAY', 'MITM', 'RAINBOW_TABLE', 'QUANTUM', 'DB_LEAK', 'SIDE_CHANNEL', 'KEY_LEAK'],
    dangerProbability: 0.5,
    scoreThreshold: 10,
    initialHealth: 10
  }
];

export const getGeneratedLevel = (id: number): LevelConfig => {
  const level = PRESET_LEVELS.find(l => l.id === id);
  if (!level) {
    const lastLevel = PRESET_LEVELS[PRESET_LEVELS.length - 1];
    const multiplier = Math.pow(1.25, id - lastLevel.id);
    return {
      ...lastLevel,
      id,
      name: `${id.toString().padStart(2, '0')} 终极挑战`,
      speed: Math.floor(lastLevel.speed * multiplier),
      spawnInterval: 2000,
      scoreThreshold: 10,
      initialHealth: 10,
      duration: 100
    };
  }
  return level;
};

// 章节配置
export const CHAPTERS: Chapter[] = [
  {
    id: 1,
    title: '第一章：窃听与篡改',
    description: '掌握基础的对称加密与传输层安全协议。',
    levelIds: [1, 2, 3]
  },
  {
    id: 2,
    title: '第二章：认证与完整性',
    description: '了解哈希、签名与消息验证码的使用。',
    levelIds: [4, 5, 6]
  },
  {
    id: 3,
    title: '第三章：身份与密钥',
    description: '深入公钥基础设施与密钥交换协议。',
    levelIds: [7, 8, 9]
  },
  {
    id: 4,
    title: '第四章：未来与侧信道',
    description: '探索后量子密码学与物理层面的攻防。',
    levelIds: [10]
  }
];

export function getToolDisplayName(tool: ToolType): string {
  return CRYPTOGRAPHY_REGISTRY[tool]?.name || tool;
}

export function getToolColor(tool: ToolType): string {
  return CRYPTOGRAPHY_REGISTRY[tool]?.color || '#9ca3af';
}

export function getRequiredToolForThreat(threat: ThreatType): ToolType {
  switch (threat) {
    case 'EAVESDROPPING': return 'AES';
    case 'MITM': return 'CERT_TLS';
    case 'REPLAY': return 'HMAC_NONCE';
    case 'RAINBOW_TABLE': return 'SALT_BCRYPT';
    case 'QUANTUM': return 'KYBER';
    case 'DB_LEAK': return 'ENC_STORAGE';
    case 'SIDE_CHANNEL': return 'CONST_TIME';
    case 'KEY_LEAK': return 'ASYM_KEY';
    default: return 'NONE'; // White noise, clicking causes damage
  }
}

export function getThreatDisplayName(threat: ThreatType): string {
  return THREAT_REGISTRY[threat]?.name || threat;
}

export function getThreatColor(threat: ThreatType): string {
  return THREAT_REGISTRY[threat]?.color || '#9ca3af';
}

export function getThreatDescription(threat: ThreatType): string {
  return THREAT_REGISTRY[threat]?.description || '';
}
