import React from 'react';
import { ThreatType } from '../types';
import { CRYPTOGRAPHY_REGISTRY } from '../data/cryptographyData';
import { Shield, Milestone, RotateCcw, Database, Atom, LogOut, Clock, HelpCircle, AlertCircle, Play } from 'lucide-react';

interface KnowledgeCardProps {
  threatType: ThreatType;
  onClose: () => void;
}

export const KnowledgeCard: React.FC<KnowledgeCardProps> = ({ threatType, onClose }) => {
  // Safe fallbacks
  const actualThreat = threatType === 'DANGER' ? 'EAVESDROPPING' : threatType;
  const info = CRYPTOGRAPHY_REGISTRY[actualThreat];

  if (!info) return null;

  // Render appropriate icons based on threat
  const renderIcon = () => {
    const size = 38;
    const className = "text-emerald-400";
    switch (actualThreat) {
      case 'EAVESDROPPING': return <Shield size={size} className={className} />;
      case 'MITM': return <Milestone size={size} className={className} />;
      case 'REPLAY': return <RotateCcw size={size} className={className} />;
      case 'RAINBOW_TABLE': return <Database size={size} className={className} />;
      case 'QUANTUM': return <Atom size={size} className={className} />;
      case 'DB_LEAK': return <LogOut size={size} className={className} />;
      case 'SIDE_CHANNEL': return <Clock size={size} className={className} />;
      default: return <HelpCircle size={size} className={className} />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-cyber-dark/85 backdrop-blur-md transition-all">
      <div className="w-full max-w-lg border-2 border-cyber-green/55 bg-cyber-panel rounded-2xl overflow-hidden shadow-[0_0_40px_rgba(0,255,156,0.2)] flex flex-col max-h-[90vh]">
        
        {/* Banner header resembling a computer diagnostic alert */}
        <div className="bg-cyber-dark/80 border-b border-cyber-green/20 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-cyber-green/10 p-2 rounded-lg border border-cyber-green/30">
              <AlertCircle className="text-cyber-green w-5 h-5 animate-pulse" />
            </div>
            <div>
              <p className="text-[10px] font-display text-cyber-green uppercase tracking-widest font-bold">
                Threat Detected & Countermeasure Unlocked
              </p>
              <h3 className="text-sm font-display text-slate-100 font-bold uppercase">
                未知威胁档案：{info.name}
              </h3>
            </div>
          </div>
          <span className="text-xs font-mono text-cyber-green bg-cyber-dark px-2 py-0.5 rounded border border-cyber-green/20">
            CLASS-A
          </span>
        </div>

        {/* Content Section (Scrollable on smaller heights) */}
        <div className="flex-1 p-6 overflow-y-auto space-y-6">
          
          {/* Main info card: Threat vs Defensive Tool */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-4 bg-cyber-dark/40 p-4 rounded-xl border border-cyber-green/20">
            <div className="md:col-span-3 flex md:flex-col items-center justify-center gap-3 bg-cyber-green/5 border border-cyber-green/20 rounded-lg p-3">
              {renderIcon()}
              <div className="text-center md:text-center text-left">
                <span className="text-[10px] font-display font-medium text-cyber-green">COUNTER-KEY</span>
                <p className="text-base font-display font-bold text-cyber-green">{info.toolName.split(' ')[0]}</p>
              </div>
            </div>

            <div className="md:col-span-9 space-y-2">
              <div className="flex flex-col">
                <span className="text-[10px] font-display font-bold text-red-400 uppercase tracking-wider">
                  ⚠️ 网络安全威胁
                </span>
                <h4 className="text-base font-bold text-red-200">{info.threatName}</h4>
                <p className="text-xs text-slate-400 leading-relaxed font-mono">{info.threatDesc}</p>
              </div>

              <div className="border-t border-cyber-green/15 my-2 pt-2 flex flex-col">
                <span className="text-[10px] font-display font-bold text-cyber-green uppercase tracking-wider">
                  🛡️ 密码合规对策
                </span>
                <h4 className="text-base font-bold text-emerald-300">{info.toolName}</h4>
                <p className="text-xs text-slate-400 leading-relaxed font-mono">{info.toolDesc}</p>
              </div>
            </div>
          </div>

          {/* Section A: Easy Analogy */}
          <div className="space-y-2 bg-[#0038ff]/5 p-4 rounded-xl border border-cyber-blue/20">
            <h5 className="text-xs font-display font-bold text-cyber-blue flex items-center gap-1">
              <HelpCircle size={14} /> 通俗物理比喻 :
            </h5>
            <p className="text-sm text-slate-300 leading-relaxed italic">
              “ {info.easyExplain} ”
            </p>
          </div>

          {/* Section B: Technical Expert Explaining */}
          <div className="space-y-2 bg-cyber-dark/40 p-4 rounded-xl border border-cyber-green/20">
            <h5 className="text-xs font-display font-bold text-cyber-green">
              📊 密码学专家深度解析 (Cryptographical Proof) :
            </h5>
            <p className="text-xs text-slate-400 leading-relaxed font-mono">
              {info.expertExplain}
            </p>
          </div>
        </div>

        {/* CTA Footer action */}
        <div className="bg-cyber-dark/60 p-4 border-t border-cyber-green/20 flex justify-end">
          <button
            onClick={onClose}
            className="flex items-center gap-2 px-6 py-2.5 bg-cyber-green hover:bg-cyber-green/85 text-cyber-dark font-display font-bold text-sm rounded-lg transition-all shadow-[0_0_15px_rgba(0,255,156,0.3)] hover:scale-[1.03] outline-none cursor-pointer"
          >
            <Play size={16} fill="currentColor" /> 加载防护装置，点击部署防线
          </button>
        </div>

      </div>
    </div>
  );
};
