import React, { useEffect, useRef, useCallback } from 'react';
import Phaser from 'phaser';
import { GameScene, GameSceneData } from '../game/GameScene';
import { LevelConfig, ToolType, ThreatType } from '../types';
import soundEngine from '../utils/AudioEngine';

interface GameCanvasProps {
  levelConfig: LevelConfig;
  activeTool: ToolType;
  lastTrigger: { tool: ToolType; timestamp: number } | null;
  isPaused: boolean;
  score: number;
  onScoreUpdate: (score: number, combo: number, accuracy: number, health: number, hits: number, misses: number) => void;
  onShowTutorial: (threat: ThreatType) => void;
  onLevelFinished: (success: boolean) => void;
  onGoToLevel: (levelId: number) => void;
}

export const GameCanvas: React.FC<GameCanvasProps> = ({
  levelConfig,
  activeTool,
  lastTrigger,
  isPaused,
  score,
  onScoreUpdate,
  onShowTutorial,
  onLevelFinished,
  onGoToLevel,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const gameRef = useRef<Phaser.Game | null>(null);
  const sceneRef = useRef<GameScene | null>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    const config: Phaser.Types.Core.GameConfig = {
      type: Phaser.AUTO,
      width: 360,
      height: 480,
      parent: containerRef.current,
      backgroundColor: '#04060b',
      physics: {
        default: 'arcade',
        arcade: {
          gravity: { x: 0, y: 0 },
          debug: false,
        },
      },
      scale: {
        mode: Phaser.Scale.FIT,
        autoCenter: Phaser.Scale.CENTER_BOTH,
      },
    };

    const game = new Phaser.Game(config);
    gameRef.current = game;

    const sceneData: GameSceneData = {
      levelConfig,
      activeTool,
      onScoreUpdate,
      onShowTutorial,
      onLevelFinished,
      onGoToLevel
    };

    game.scene.add('GameScene', GameScene, true, sceneData);
    
    const addedScene = game.scene.getScene('GameScene');
    if (addedScene) {
      addedScene.events.once('scene-ready', (scene: GameScene) => {
        sceneRef.current = scene;
        
        scene.events.on('play-hit-sfx', (combo: number) => {
          soundEngine.playCombo(combo);
        });
        scene.events.on('play-miss-sfx', () => {
          soundEngine.playMiss();
        });
        scene.events.on('play-danger-sfx', () => {
          soundEngine.playDangerHit();
        });
        scene.events.on('level-complete', () => {
          onLevelFinished(true);
        });
        scene.events.on('level-failed', () => {
          onLevelFinished(false);
        });
        scene.events.on('go-to-level', (levelId: number) => {
          onGoToLevel(levelId);
        });
      });
    }

    return () => {
      soundEngine.stopBGM();
      if (game) {
        game.destroy(true);
      }
      GameScene.instance = null;
      gameRef.current = null;
      sceneRef.current = null;
    };
  }, [levelConfig.id]);

  useEffect(() => {
    if (GameScene.instance) {
      GameScene.instance.updateActiveTool(activeTool);
    }
  }, [activeTool]);

  useEffect(() => {
    if (!GameScene.instance) return;
    if (isPaused) {
      GameScene.instance.pauseGame();
    } else {
      GameScene.instance.resumeGame();
    }
  }, [isPaused]);

  return (
    <div className="relative border-4 border-slate-800 rounded-3xl overflow-hidden shadow-2xl bg-slate-950 w-full max-w-[360px] h-[320px] mx-auto">
      <div ref={containerRef} className="w-full h-full" />
    </div>
  );
};
