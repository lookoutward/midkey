import React, { useState } from 'react';
import { CRYPTOGRAPHY_REGISTRY } from '../data/cryptographyData';
import { ThreatType } from '../types';
import { BookOpen, Shield, Milestone, RotateCcw, Database, Atom, LogOut, Clock, X } from 'lucide-react';

interface EncyclopediaProps {
  onClose: () => void;
}

export const Encyclopedia: React.FC<EncyclopediaProps> = ({ onClose }) => {
  const [selectedThreat, setSelectedThreat] = useState<Exclude<ThreatType, 'DANGER' | 'COMBINED'>>('EAVESDROPPING');

  const threatsList = Object.keys(CRYPTOGRAPHY_REGISTRY) as Exclude<ThreatType, 'DANGER' | 'COMBINED'>[];

  const getThreatIcon = (threat: typeof selectedThreat, size = 18) => {
    switch (threat) {
      case 'EAVESDROPPING': return <Shield size={size} />;
      case 'MITM': return <Milestone size={size} />;
      case 'REPLAY': return <RotateCcw size={size} />;
      case 'RAINBOW_TABLE': return <Database size={size} />;
      case 'QUANTUM': return <Atom size={size} />;
      case 'DB_LEAK': return <LogOut size={size} />;
      case 'SIDE_CHANNEL': return <Clock size={size} />;
    }
  };

  const selectedInfo = CRYPTOGRAPHY_REGISTRY[selectedThreat];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-cyber-dark/85 backdrop-blur-md">
      <div className="w-full max-w-4xl h-[85vh] border-2 border-cyber-blue/50 bg-cyber-panel rounded-2xl flex flex-col overflow-hidden shadow-[0_0_50px_rgba(0,163,255,0.2)]">
        
        {/* Header */}
        <div className="bg-cyber-dark px-6 py-4 border-b border-cyber-blue/20 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BookOpen className="text-cyber-blue w-5 h-5" />
            <h2 className="text-lg font-display font-bold text-slate-100 uppercase tracking-wider">
              密码学数字防务百科 (Cryptography Archives)
            </h2>
          </div>
          <button 
            onClick={onClose} 
            className="text-slate-400 hover:text-cyber-blue border border-cyber-blue/30 p-1.5 rounded-lg hover:bg-cyber-dark transition-all cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Multi-column grid */}
        <div className="flex-1 grid grid-cols-1 md:grid-cols-12 overflow-hidden">
          
          {/* Left Threat Selector Rail (4 cols) */}
          <div className="md:col-span-4 border-r border-cyber-blue/15 bg-cyber-dark/30 p-4 overflow-y-auto space-y-2">
            <p className="text-[10px] font-display text-slate-500 uppercase tracking-wider font-extrabold px-2 pb-2">
              SECURITY TREAT FILES // 威胁与对抗分类
            </p>
            {threatsList.map((threat) => {
              const isSelected = selectedThreat === threat;
              return (
                <button
                  key={threat}
                  onClick={() => setSelectedThreat(threat)}
                  className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl border text-left transition-all cursor-pointer ${
                    isSelected 
                      ? 'bg-cyber-blue/15 border-cyber-blue text-cyber-blue shadow-[0_0_12px_rgba(0,163,255,0.15)] font-bold' 
                      : 'bg-cyber-dark border border-cyber-blue/10 text-slate-400 hover:text-slate-300 hover:bg-cyber-panel'
                  }`}
                >
                  <span className={isSelected ? 'text-cyber-blue' : 'text-slate-500'}>
                    {getThreatIcon(threat, 18)}
                  </span>
                  <div className="flex-1 min-w-0">
                    <p className="text-[10px] font-mono opacity-60">
                      {threat}
                    </p>
                    <p className="text-xs truncate font-display text-slate-200">
                      {CRYPTOGRAPHY_REGISTRY[threat].name}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Right Information dossier panel (8 cols) */}
          <div className="md:col-span-8 p-6 overflow-y-auto space-y-6 bg-cyber-dark/10">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-cyber-blue/10 pb-4">
              <div>
                <span className="text-[10px] font-display text-cyber-blue uppercase tracking-widest font-extrabold bg-cyber-blue/10 px-2.5 py-1 rounded inline-block border border-cyber-blue/20">
                  COUNTERMEASURE ARSENAL // 防御枢纽
                </span>
                <h3 className="text-2xl font-display font-bold text-slate-100 mt-2">
                  {selectedInfo.toolName}
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed font-mono">
                  映射防御：{selectedInfo.threatName}
                </p>
              </div>
              <div className="w-16 h-16 bg-cyber-blue/10 border border-cyber-blue/20 rounded-2xl flex items-center justify-center text-cyber-blue shadow-[0_0_15px_rgba(0,163,255,0.1)]">
                {getThreatIcon(selectedThreat, 32)}
              </div>
            </div>

            {/* Block sections */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              
              {/* Threat side file */}
              <div className="bg-red-950/10 border border-red-500/10 p-4 rounded-xl space-y-1.5">
                <span className="text-[10px] font-display font-extrabold text-red-400">🚨 INPUT THREAT // 注入威胁</span>
                <p className="text-sm font-semibold text-red-200">{selectedInfo.threatName}</p>
                <p className="text-xs text-slate-400 font-mono">{selectedInfo.threatDesc}</p>
              </div>

              {/* Tool side file */}
              <div className="bg-cyber-green/5 border border-cyber-green/20 p-4 rounded-xl space-y-1.5">
                <span className="text-[10px] font-display font-extrabold text-cyber-green">🛡️ CORE DEFENDER // 部署核心</span>
                <p className="text-sm font-semibold text-emerald-300">{selectedInfo.toolName}</p>
                <p className="text-xs text-slate-400 font-mono">{selectedInfo.toolDesc}</p>
              </div>

            </div>

            {/* Metaphor representation */}
            <div className="bg-cyber-blue/5 border border-cyber-blue/20 p-4 rounded-xl space-y-2">
              <h4 className="text-xs font-display font-bold text-cyber-blue">
                💡 通俗物理比喻
              </h4>
              <p className="text-xs text-slate-300 leading-relaxed italic">
                “ {selectedInfo.easyExplain} ”
              </p>
            </div>

            {/* Cryptographical Proof representation */}
            <div className="bg-cyber-dark/65 p-5 rounded-xl border border-cyber-green/20 space-y-2">
              <h4 className="text-xs font-display font-bold text-cyber-green uppercase tracking-widest">
                🔬 密码学底层数理机理 (Mathematical Foundations)
              </h4>
              <p className="text-xs text-slate-400 leading-relaxed font-mono">
                {selectedInfo.expertExplain}
              </p>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
