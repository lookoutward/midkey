import Phaser from 'phaser';
import { ThreatType, ToolType, LevelConfig } from '../types';
import { getRequiredToolForThreat, THREAT_REGISTRY } from '../data/cryptographyData';
import { soundEngine } from '../utils/AudioEngine';

export interface GameSceneData {
  levelConfig: LevelConfig;
  activeTool: ToolType;
  onScoreUpdate: (score: number, combo: number, accuracy: number, health: number, hits: number, misses: number) => void;
  onShowTutorial: (threat: ThreatType) => void;
  onLevelFinished: (success: boolean) => void;
  onGoToLevel: (levelId: number) => void;
}

export class GameScene extends Phaser.Scene {
  public static instance: GameScene | null = null;
  private levelConfig!: LevelConfig;
  private activeTool: ToolType = 'NONE';
  private onScoreUpdateCallbacks!: (score: number, combo: number, accuracy: number, health: number, hits: number, misses: number) => void;
  private onShowTutorialCallback!: (threat: ThreatType) => void;
  private onLevelFinishedCallback!: (success: boolean) => void;
  private onGoToLevelCallback!: (levelId: number) => void;

  private score = 0;
  private combo = 0;
  private maxCombo = 0;
  private health = 5;
  private hits = 0;
  private misses = 0;
  private isFinished = false;

  private trackWidth = 340;
  private trackLeft!: number;
  private trackRight!: number;
  private trackTop = 0;
  private trackBottom!: number;

  private playerTurret!: Phaser.GameObjects.Container;
  private topEnemyText!: Phaser.GameObjects.Text;
  private isGameStarted = false;
  private audioContext!: AudioContext;
  
  private enemies!: Phaser.Physics.Arcade.Group;
  private bullets!: Phaser.Physics.Arcade.Group;

  private totalEnemiesInWave = 10;
  private spawnedCount = 0;
  private isCurrentWaveFailed = false;
  private currentWaveThreats: ThreatType[] = [];
  
  private lastSpawnTime = 0;
  private currentTopThreat!: ThreatType;
  private lastShootTime = 0;
  private shootInterval = 75;
  
  private challengePhase = 0;
  private maxChallengePhases = 10;
  private phaseDuration = 5000;
  private startTime = 0;
  private lastPhaseChangeTime = 0;
  private phaseThreats: ThreatType[] = [];
  
  private isGroupSpawning = false;
  private isGroupCleared = false;

  private static shownTutorialsThisSession = new Set<string>();

  constructor() {
    super('GameScene');
  }

  init(data: GameSceneData) {
    this.levelConfig = data.levelConfig;
    this.activeTool = data.activeTool;
    this.onScoreUpdateCallbacks = data.onScoreUpdate;
    this.onShowTutorialCallback = data.onShowTutorial;
    this.onLevelFinishedCallback = data.onLevelFinished;
    this.onGoToLevelCallback = data.onGoToLevel;

    if (this.activeTool === 'NONE') {
      this.activeTool = 'AES';
    }

    this.score = 0;
    this.combo = 0;
    this.maxCombo = 0;
    this.health = this.levelConfig.initialHealth || 5;
    this.hits = 0;
    this.misses = 0;
    this.isFinished = false;
    this.spawnedCount = 0;
    this.isCurrentWaveFailed = false;
    this.isGroupSpawning = false;
    this.isGroupCleared = false;

    // 所有关卡每组固定10个小方块
    this.totalEnemiesInWave = 10;
    this.currentWaveThreats = [...this.levelConfig.activeThreats];
    this.currentTopThreat = this.getRandomThreat();
  }

  preload() {
  }

  create() {
    const { width, height } = this.scale;

    this.trackLeft = (width - this.trackWidth) / 2;
    this.trackRight = this.trackLeft + this.trackWidth;
    this.trackBottom = height;

    this.createCyberBackground();
    this.createVerticalTrack();
    this.createPlayerTurret();
    this.createTopEnemy();

    this.enemies = this.add.group();
    this.bullets = this.add.group();

    this.input.on('pointermove', (pointer: Phaser.Input.Pointer) => {
      this.updateTurretPosition(pointer.x);
    });

    this.input.keyboard?.on('keydown-ONE', () => this.changePlayerWeapon('AES'));
    this.input.keyboard?.on('keydown-TWO', () => this.changePlayerWeapon('CERT_TLS'));
    this.input.keyboard?.on('keydown-THREE', () => this.changePlayerWeapon('HMAC_NONCE'));
    this.input.keyboard?.on('keydown-FOUR', () => this.changePlayerWeapon('SALT_BCRYPT'));
    this.input.keyboard?.on('keydown-FIVE', () => this.changePlayerWeapon('KYBER'));
    this.input.keyboard?.on('keydown-SIX', () => this.changePlayerWeapon('ENC_STORAGE'));
    this.input.keyboard?.on('keydown-SEVEN', () => this.changePlayerWeapon('CONST_TIME'));
    this.input.keyboard?.on('keydown-EIGHT', () => this.changePlayerWeapon('ASYM_KEY'));

    this.createStartButton();

    this.cameras.main.flash(300, 16, 185, 129, true);
    this.dispatchScoreUpdate();

    GameScene.instance = this;
    this.events.emit('scene-ready', this);
  }

  shutdown() {
    if (GameScene.instance === this) {
      GameScene.instance = null;
    }
  }

  update(time: number, delta: number) {
    if (this.isFinished || !this.isGameStarted) return;

    this.updateCyberGrid(time);
    
    const now = Date.now() - this.startTime;
    
    if (this.challengePhase < this.maxChallengePhases) {
      // 检查当前组是否发射完毕
      if (!this.isGroupSpawning && this.spawnedCount >= this.totalEnemiesInWave) {
        this.isGroupSpawning = true; // 标记为正在等待清空
      }
      
      // 检查当前组是否已清空（打完或全部落入底线）
      if (this.enemies.getLength() === 0 && this.isGroupSpawning) {
        this.isGroupCleared = true;
      }
      
      // 只有当前组清空后，才开始下一组
      if (this.isGroupCleared) {
        this.isGroupCleared = false;
        this.isGroupSpawning = false;
        this.spawnedCount = 0;
        
        this.challengePhase++;
        if (this.challengePhase < this.maxChallengePhases) {
          this.changeCurrentThreat();
        }
        this.lastPhaseChangeTime = now;
      }
      
      // 在发射时间内发射方块
      const timeDiff = now - this.lastPhaseChangeTime;
      const spawnInterval = this.phaseDuration / this.totalEnemiesInWave;
      if (this.spawnedCount < this.totalEnemiesInWave && now - this.lastSpawnTime > spawnInterval) {
        this.spawnEnemy();
        this.lastSpawnTime = now;
      }
    }
    
    if (this.activeTool !== 'NONE' && now - this.lastShootTime > this.shootInterval) {
      this.shootBullet();
      this.lastShootTime = now;
    }
    
    this.updateEnemies();
    this.updateBullets();
    this.checkCollisions();
    this.checkWaveCompletion();
  }

  changePlayerWeapon(tool: ToolType) {
    if (this.isFinished || tool === 'NONE') return;
    this.activeTool = tool;
    this.triggerWeaponChangeEffect();
  }

  updateActiveTool(tool: ToolType) {
    this.activeTool = tool;
  }

  shootBullet() {
    const turretX = this.playerTurret.x;
    const turretY = this.playerTurret.y - 30;

    const color = this.getWeaponColor(this.activeTool);

    const bullet = this.add.rectangle(turretX, turretY, 6, 15, color);
    bullet.setData('speed', -8);
    bullet.setData('weapon', this.activeTool);

    this.bullets.add(bullet);
  }

  private startWave() {
    this.startTime = Date.now();
    this.spawnedCount = 0;
    this.isCurrentWaveFailed = false;
    this.lastSpawnTime = 0;
    
    this.challengePhase = 0;
    this.lastPhaseChangeTime = 0;
    
    this.phaseThreats = this.getRandomThreats(this.maxChallengePhases);
    
    this.currentTopThreat = this.phaseThreats[0];
    this.updateTopEnemyText();
  }
  
  private getRandomThreats(count: number): ThreatType[] {
    const shuffled = [...this.currentWaveThreats].sort(() => Math.random() - 0.5);
    const result: ThreatType[] = [];
    for (let i = 0; i < count; i++) {
      result.push(shuffled[i % shuffled.length]);
    }
    return result;
  }
  
  private changeCurrentThreat() {
    this.currentTopThreat = this.phaseThreats[this.challengePhase];
    this.updateTopEnemyText();
    
    this.cameras.main.flash(200, 255, 255, 255, true);
  }

  private createStartButton() {
    const { width, height } = this.scale;
    
    const startButton = this.add.text(width / 2, height / 2, '🎯', {
      fontFamily: 'Arial',
      fontSize: 64,
      fontWeight: 'bold',
      color: '#ffffff'
    }).setOrigin(0.5).setInteractive({ useHandCursor: true });

    const startButtonCircle = this.add.graphics();
    startButtonCircle.fillStyle(0x1e293b, 0.9);
    startButtonCircle.lineStyle(3, 0x10b981, 1);
    startButtonCircle.beginPath();
    startButtonCircle.arc(width / 2, height / 2, 45, 0, Math.PI * 2);
    startButtonCircle.fillPath();
    startButtonCircle.strokePath();
    startButtonCircle.setDepth(9);

    startButton.setDepth(10);

    startButton.on('pointerdown', () => {
      startButton.destroy();
      startButtonCircle.destroy();
      this.isGameStarted = true;
      
      this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      
      this.startWave();
    });
  }

  private createTopEnemy() {
    const { width } = this.scale;
    const topEnemyX = width / 2;
    const topEnemyY = 40;

    this.topEnemyText = this.add.text(topEnemyX, topEnemyY, '', {
      fontFamily: 'Arial',
      fontSize: 48,
      fontWeight: 'bold',
      color: '#ffffff',
      shadow: {
        offsetX: 2,
        offsetY: 2,
        color: '#000000',
        blur: 4,
        fill: true
      }
    }).setOrigin(0.5);

    this.updateTopEnemyText();
  }

  private updateTopEnemyText() {
    const info = THREAT_REGISTRY[this.currentTopThreat];
    const phaseNum = this.challengePhase + 1;
    // 隐藏数字角标，只显示图标（数字保留用于调试）
    this.topEnemyText.text = `${info?.emoji || ''}`;
    this.topEnemyText.setColor(this.getThreatColor(this.currentTopThreat));
  }

  private playShootSound() {
    if (!this.audioContext || !soundEngine.isSoundEnabled()) return;
    
    const oscillator = this.audioContext.createOscillator();
    const gainNode = this.audioContext.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(this.audioContext.destination);
    
    oscillator.type = 'sine';
    oscillator.frequency.setValueAtTime(800, this.audioContext.currentTime);
    oscillator.frequency.exponentialRampToValueAtTime(300, this.audioContext.currentTime + 0.08);
    
    gainNode.gain.setValueAtTime(0.3, this.audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + 0.08);
    
    oscillator.start(this.audioContext.currentTime);
    oscillator.stop(this.audioContext.currentTime + 0.08);
  }

  private playCollisionSound() {
    if (!this.audioContext || !soundEngine.isSoundEnabled()) return;
    
    const oscillator = this.audioContext.createOscillator();
    const gainNode = this.audioContext.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(this.audioContext.destination);
    
    oscillator.type = 'sine';
    oscillator.frequency.setValueAtTime(1200, this.audioContext.currentTime);
    oscillator.frequency.exponentialRampToValueAtTime(2000, this.audioContext.currentTime + 0.02);
    oscillator.frequency.exponentialRampToValueAtTime(500, this.audioContext.currentTime + 0.06);
    
    gainNode.gain.setValueAtTime(0.25, this.audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + 0.06);
    
    oscillator.start(this.audioContext.currentTime);
    oscillator.stop(this.audioContext.currentTime + 0.06);
  }

  private playMissSound() {
    if (!this.audioContext || !soundEngine.isSoundEnabled()) return;
    
    const oscillator = this.audioContext.createOscillator();
    const gainNode = this.audioContext.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(this.audioContext.destination);
    
    oscillator.type = 'sawtooth';
    oscillator.frequency.setValueAtTime(200, this.audioContext.currentTime);
    oscillator.frequency.exponentialRampToValueAtTime(80, this.audioContext.currentTime + 0.15);
    
    gainNode.gain.setValueAtTime(0.2, this.audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + 0.15);
    
    oscillator.start(this.audioContext.currentTime);
    oscillator.stop(this.audioContext.currentTime + 0.15);
  }

  private spawnEnemy() {
    const { width } = this.scale;
    const topEnemyX = width / 2;
    
    const x = Phaser.Math.Between(this.trackLeft + 10, this.trackRight - 10);
    const y = 60;

    const threat = this.currentTopThreat;
    const color = this.getThreatColorHex(threat);

    const enemy = this.add.sprite(x, y, '');
    enemy.setData('speed', this.levelConfig.speed * 0.004);

    const glow = this.make.graphics({ x: 0, y: 0, add: false });
    glow.fillStyle(color, 0.8);
    glow.fillCircle(0, 0, 8);
    
    const core = this.make.graphics({ x: 0, y: 0, add: false });
    core.fillStyle(0xffffff, 1);
    core.fillCircle(0, 0, 4);

    const enemyContainer = this.add.container(x, y);
    enemyContainer.add([glow, core]);
    enemy.setData('container', enemyContainer);
    enemy.setData('threat', threat);

    this.enemies.add(enemy);
    this.spawnedCount++;
  }

  private updateEnemies() {
    const { height } = this.scale;
    
    this.enemies.getChildren().forEach((enemy) => {
      const sprite = enemy as Phaser.GameObjects.Sprite;
      const speed = sprite.getData('speed') || 3;
      sprite.y += speed;
      
      const container = sprite.getData('container') as Phaser.GameObjects.Container;
      if (container) {
        container.x = sprite.x;
        container.y = sprite.y;
      }

      if (sprite.y > height + 30) {
        this.health--;
        this.misses++;
        this.playMissSound();
        
        this.spawnFloatingStatusText(sprite.x, height - 50, '-1', '#ef4444');
        
        this.onEnemyDestroyed(sprite);
        this.dispatchScoreUpdate();
        
        if (this.health <= 0) {
          this.triggerLevelFailEffect();
        }
      }
    });
  }

  private updateBullets() {
    const { height } = this.scale;
    
    this.bullets.getChildren().forEach((bullet) => {
      const rect = bullet as Phaser.GameObjects.Rectangle;
      const speed = rect.getData('speed') || -8;
      rect.y += speed;

      if (rect.y < -30) {
        rect.destroy();
      }
    });
  }

  private checkCollisions() {
    const bullets = this.bullets.getChildren() as Phaser.GameObjects.Rectangle[];
    const enemies = this.enemies.getChildren() as Phaser.GameObjects.Sprite[];
    
    for (let i = bullets.length - 1; i >= 0; i--) {
      const bullet = bullets[i];
      if (!bullet.active) continue;
      
      for (let j = enemies.length - 1; j >= 0; j--) {
        const enemy = enemies[j];
        if (!enemy.active) continue;
        
        const dx = bullet.x - enemy.x;
        const dy = bullet.y - enemy.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        
        if (distance < 20) {
          this.handleBulletEnemyCollision(bullet, enemy);
          break;
        }
      }
    }
  }

  private handleBulletEnemyCollision(bullet: Phaser.GameObjects.Rectangle, enemy: Phaser.GameObjects.Sprite) {
    const bulletWeapon = bullet.getData('weapon') as ToolType;
    const enemyThreat = enemy.getData('threat') as ThreatType;
    const requiredTool = getRequiredToolForThreat(enemyThreat);

    if (bulletWeapon === requiredTool) {
      this.triggerHitEffect(enemy.x, enemy.y);
      this.playCollisionSound();
      this.combo++;
      this.hits++;
      if (this.combo > this.maxCombo) this.maxCombo = this.combo;
      
      bullet.destroy();
      this.onEnemyDestroyed(enemy);
    } else {
      this.triggerMissEffect(enemy.x, enemy.y);
      this.combo = 0;
      this.misses++;
      
      bullet.destroy();
    }

    this.dispatchScoreUpdate();
  }

  private onEnemyDestroyed(enemy: Phaser.GameObjects.Sprite) {
    const container = enemy.getData('container') as Phaser.GameObjects.Container;
    if (container) container.destroy();
    enemy.destroy();
  }

  private checkWaveCompletion() {
    if (this.challengePhase >= this.maxChallengePhases && this.enemies.getLength() === 0) {
      this.triggerLevelCompleteEffect();
      this.isFinished = true;
    }
  }
  
  private triggerLevelCompleteEffect() {
    this.cameras.main.flash(500, 16, 185, 129, true);
    
    const { width, height } = this.scale;
    const isFinalLevel = this.levelConfig.id === 10;
    const message = '😄';
    const levelCompleteText = this.add.text(width / 2, height / 2, message, {
      fontFamily: 'Arial',
      fontSize: 80,
      fontWeight: 'bold',
      color: '#10b981',
      align: 'center'
    }).setOrigin(0.5).setInteractive({ useHandCursor: true });
    
    levelCompleteText.on('pointerdown', () => {
      levelCompleteText.destroy();
      // 直接进入下一关（第10关后回到第1关）
      const nextLevelId = isFinalLevel ? 1 : this.levelConfig.id + 1;
      this.onGoToLevelCallback(nextLevelId);
    });
  }
  
  private triggerLevelFailEffect() {
    this.isFinished = true;
    this.cameras.main.flash(500, 239, 68, 68, true);
    
    const { width, height } = this.scale;
    const currentLevelId = this.levelConfig.id;
    const levelFailText = this.add.text(width / 2, height / 2, '😱', {
      fontFamily: 'Arial',
      fontSize: 80,
      fontWeight: 'bold',
      color: '#ef4444',
      align: 'center'
    }).setOrigin(0.5).setInteractive({ useHandCursor: true });
    
    levelFailText.on('pointerdown', () => {
      levelFailText.destroy();
      // 重新进入本关
      this.onGoToLevelCallback(currentLevelId);
    });
  }

  private getRandomThreat(): ThreatType {
    const idx = Phaser.Math.Between(0, this.currentWaveThreats.length - 1);
    return this.currentWaveThreats[idx];
  }

  private getThreatColorHex(threat: ThreatType): number {
    switch (threat) {
      case 'EAVESDROPPING': return 0x3b82f6;
      case 'MITM': return 0xa855f7;
      case 'REPLAY': return 0xeab308;
      case 'RAINBOW_TABLE': return 0xf97316;
      case 'QUANTUM': return 0x06b6d4;
      case 'DB_LEAK': return 0xec4899;
      case 'SIDE_CHANNEL': return 0x14b8a6;
      case 'KEY_LEAK': return 0xf59e0b;
      default: return 0xffffff;
    }
  }

  private getThreatColor(threat: ThreatType): string {
    switch (threat) {
      case 'EAVESDROPPING': return '#3b82f6';
      case 'MITM': return '#a855f7';
      case 'REPLAY': return '#eab308';
      case 'RAINBOW_TABLE': return '#f97316';
      case 'QUANTUM': return '#06b6d4';
      case 'DB_LEAK': return '#ec4899';
      case 'SIDE_CHANNEL': return '#14b8a6';
      case 'KEY_LEAK': return '#f59e0b';
      default: return '#ffffff';
    }
  }

  private getWeaponColor(tool: ToolType): number {
    switch (tool) {
      case 'AES': return 0x3b82f6;
      case 'CERT_TLS': return 0xa855f7;
      case 'HMAC_NONCE': return 0xeab308;
      case 'SALT_BCRYPT': return 0xf97316;
      case 'KYBER': return 0x06b6d4;
      case 'ENC_STORAGE': return 0xec4899;
      case 'CONST_TIME': return 0x14b8a6;
      case 'ASYM_KEY': return 0xf59e0b;
      default: return 0x10b981;
    }
  }

  private createCyberBackground() {
    const { width, height } = this.scale;
    const bg = this.add.graphics();
    bg.fillStyle(0x05070c, 1);
    bg.fillRect(0, 0, width, height);

    const binaryDigits = ['0', '1', 'AES', 'TLS', 'HMAC', 'SALT', 'KYBER', 'SHA256'];
    for (let i = 0; i < 40; i++) {
      const x = Phaser.Math.Between(0, width);
      const y = Phaser.Math.Between(0, height);
      const textVal = binaryDigits[Phaser.Math.Between(0, binaryDigits.length - 1)];
      const size = Phaser.Math.Between(10, 14);

      this.add.text(x, y, textVal, {
        fontFamily: 'monospace',
        fontSize: `${size}px`,
        color: '#10b981'
      }).setAlpha(Phaser.Math.FloatBetween(0.05, 0.2));
    }
  }

  private cyberGrid!: Phaser.GameObjects.Graphics;

  private createVerticalTrack() {
    const { width, height } = this.scale;
    this.cyberGrid = this.add.graphics();

    const trackGraphics = this.add.graphics();
    
    trackGraphics.fillStyle(0x0a0c16, 1);
    trackGraphics.fillRect(this.trackLeft - 2, 0, this.trackWidth + 4, height);

    trackGraphics.fillStyle(0x0d1117, 1);
    trackGraphics.fillRect(this.trackLeft, 0, this.trackWidth, height);

    for (let i = 0; i < height; i += 40) {
      trackGraphics.lineStyle(1, 0x1a1f2e, 0.5);
      trackGraphics.lineBetween(this.trackLeft, i, this.trackRight, i);
    }

    const borderGlow = this.add.graphics();
    this.time.addEvent({
      delay: 16,
      loop: true,
      callback: () => {
        const time = this.time.now;
        const intensity = Math.sin(time / 500) * 0.2 + 0.4;
        
        borderGlow.clear();
        borderGlow.lineStyle(3, 0x00d4ff, intensity);
        borderGlow.lineBetween(this.trackLeft, 0, this.trackLeft, height);
        borderGlow.lineBetween(this.trackRight, 0, this.trackRight, height);
      },
      callbackScope: this
    });
  }

  private updateCyberGrid(time: number) {
    this.cyberGrid.clear();
    const { width, height } = this.scale;
    const pulse = Math.sin(time / 800) * 0.1 + 0.2;

    this.cyberGrid.lineStyle(1, 0x10b981, pulse);
    for (let x = 0; x < width; x += 30) {
      this.cyberGrid.lineBetween(x, 0, x, height);
    }
    for (let y = 0; y < height; y += 30) {
      this.cyberGrid.lineBetween(0, y, width, y);
    }
  }

  private createPlayerTurret() {
    const { width, height } = this.scale;
    const turretY = height - 60;
    const turretX = width / 2;

    this.playerTurret = this.add.container(turretX, turretY);

    const trackLeft = this.add.rectangle(-30, 0, 12, 35, 0x334155, 1);
    const trackRight = this.add.rectangle(30, 0, 12, 35, 0x334155, 1);
    
    const trackLine1 = this.add.rectangle(-30, -10, 8, 2, 0x475569, 0.8);
    const trackLine2 = this.add.rectangle(-30, 0, 8, 2, 0x475569, 0.8);
    const trackLine3 = this.add.rectangle(-30, 10, 8, 2, 0x475569, 0.8);
    const trackLine4 = this.add.rectangle(30, -10, 8, 2, 0x475569, 0.8);
    const trackLine5 = this.add.rectangle(30, 0, 8, 2, 0x475569, 0.8);
    const trackLine6 = this.add.rectangle(30, 10, 8, 2, 0x475569, 0.8);

    const body = this.add.rectangle(0, -5, 48, 20, 0x1e293b, 1);
    body.setStrokeStyle(2, 0x475569, 0.6);

    const turret = this.add.circle(0, -15, 18, 0x475569, 1);
    turret.setStrokeStyle(2, 0x64748b, 0.8);

    const gunBarrel = this.add.rectangle(0, -32, 8, 22, 0x64748b, 1);

    const centerGlow = this.add.circle(0, -42, 6, 0x00d4ff, 0.6);

    const shield = this.add.circle(0, 0, 40, 0x000000, 0);
    shield.setStrokeStyle(2, 0x10b981, 0.8);

    this.playerTurret.add([trackLeft, trackRight, trackLine1, trackLine2, trackLine3, trackLine4, trackLine5, trackLine6, body, turret, gunBarrel, centerGlow, shield]);

    this.time.addEvent({
      delay: 100,
      loop: true,
      callback: () => {
        if (this.activeTool !== 'NONE') {
          centerGlow.fillColor = this.getWeaponColor(this.activeTool);
          centerGlow.fillAlpha = 0.6 + Math.sin(this.time.now / 200) * 0.2;
        }
      },
      callbackScope: this
    });
  }

  private updateTurretPosition(targetX: number) {
    const clampedX = Phaser.Math.Clamp(targetX, this.trackLeft + 20, this.trackRight - 20);
    
    this.tweens.add({
      targets: this.playerTurret,
      x: clampedX,
      duration: 50,
      ease: 'Linear'
    });
  }

  private triggerWeaponChangeEffect() {
    const { width, height } = this.scale;
    const effect = this.add.graphics();
    effect.fillStyle(this.getWeaponColor(this.activeTool), 0.3);
    effect.fillRect(0, 0, width, height);

    this.tweens.add({
      targets: effect,
      alpha: 0,
      duration: 300,
      ease: 'Linear',
      onComplete: () => effect.destroy()
    });
  }

  private triggerHitEffect(x: number, y: number) {
    const effect = this.add.graphics();
    effect.fillStyle(0x10b981, 0.8);
    effect.beginPath();
    effect.arc(x, y, 0, 0, Math.PI * 2);
    effect.fill();

    this.tweens.add({
      targets: effect,
      scale: { value: 3, duration: 300 },
      alpha: { value: 0, duration: 300 },
      ease: 'Linear',
      onComplete: () => effect.destroy()
    });
  }

  private triggerMissEffect(x: number, y: number) {
    const effect = this.add.graphics();
    effect.fillStyle(0xef4444, 0.8);
    effect.beginPath();
    effect.moveTo(x, y - 10);
    effect.lineTo(x + 10, y + 10);
    effect.lineTo(x - 10, y + 10);
    effect.closePath();
    effect.fill();

    this.tweens.add({
      targets: effect,
      scale: { value: 2, duration: 300 },
      alpha: { value: 0, duration: 300 },
      ease: 'Linear',
      onComplete: () => effect.destroy()
    });
  }

  private triggerWaveClearEffect() {
    const { width, height } = this.scale;
    const effect = this.add.graphics();
    effect.fillStyle(0x10b981, 0.2);
    effect.fillRect(0, 0, width, height);

    this.tweens.add({
      targets: effect,
      alpha: 0,
      duration: 500,
      ease: 'Linear',
      onComplete: () => effect.destroy()
    });

    this.cameras.main.flash(200, 16, 185, 129, true);
  }

  private triggerWaveFailEffect() {
    const { width, height } = this.scale;
    const effect = this.add.graphics();
    effect.fillStyle(0xef4444, 0.2);
    effect.fillRect(0, 0, width, height);

    this.tweens.add({
      targets: effect,
      alpha: 0,
      duration: 500,
      ease: 'Linear',
      onComplete: () => effect.destroy()
    });

    this.cameras.main.flash(200, 239, 68, 68, true);
  }

  private spawnFloatingStatusText(x: number, y: number, text: string, color: string) {
    const floatingText = this.add.text(x, y, text, {
      fontFamily: 'Arial',
      fontSize: 18,
      fontWeight: 'bold',
      color: color
    }).setOrigin(0.5);

    this.tweens.add({
      targets: floatingText,
      y: y - 30,
      alpha: 0,
      duration: 800,
      ease: 'Linear',
      onComplete: () => floatingText.destroy()
    });
  }

  private dispatchScoreUpdate() {
    const accuracy = (this.hits + this.misses) > 0 ? Math.round((this.hits / (this.hits + this.misses)) * 100) : 100;
    this.onScoreUpdateCallbacks(this.score, this.combo, accuracy, this.health, this.hits, this.misses);
  }

  pauseGame() {
    this.scene.pause();
  }

  resumeGame() {
    this.scene.resume();
  }
}