import React, { useState, useEffect } from 'react';
import { GameCanvas } from './components/GameCanvas';
import { 
  getGeneratedLevel, 
  CRYPTOGRAPHY_REGISTRY 
} from './data/cryptographyData';
import { LevelConfig, ToolType, ThreatType } from './types';
import soundEngine from './utils/AudioEngine';
import { 
  Shield, 
  Award, 
  RotateCcw, 
  Volume2, 
  VolumeX,
  ChevronRight,
  HelpCircle,
  X
} from 'lucide-react';

export default function App() {
  // General view states
  const [isPlaying, setIsPlaying] = useState(true);
  const [activeLevel, setActiveLevel] = useState<LevelConfig | null>(getGeneratedLevel(1));
  const [totalClearedLevels, setTotalClearedLevels] = useState(0);
  const [attempt, setAttempt] = useState(1);
  
  // Game session hud indicators
  const [score, setScore] = useState(0);
  const [combo, setCombo] = useState(0);
  const [accuracy, setAccuracy] = useState(100);
  const [health, setHealth] = useState(100);
  const [hits, setHits] = useState(0);
  const [misses, setMisses] = useState(0);

  // Active player selection
  const [activeTool, setActiveTool] = useState<ToolType>('NONE');
  const [lastTrigger, setLastTrigger] = useState<{ tool: ToolType; timestamp: number } | null>(null);
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Popups & overlays
  const [tutorialThreat, setTutorialThreat] = useState<ThreatType | null>(null);
  const [showEncyclopedia, setShowEncyclopedia] = useState(false);
  const [showHelp, setShowHelp] = useState(false);
  const [helpLang, setHelpLang] = useState<'zh' | 'en'>('zh');
  const [levelStatus, setLevelStatus] = useState<'IDLE' | 'PLAYING' | 'SUCCESS' | 'FAILED'>('PLAYING');

  const threatDefendList = [
    { threat: { zh: '流量窃听', en: 'Traffic Sniffing' }, defend: { zh: '对称加密', en: 'Symmetric Enc.' }, threatIcon: '📡', defendIcon: '🛠️' },
    { threat: { zh: '中间人劫持', en: 'MITM Attack' }, defend: { zh: '数字证书', en: 'CA Certificate' }, threatIcon: '👺', defendIcon: '🛡️' },
    { threat: { zh: '重放攻击', en: 'Replay Attack' }, defend: { zh: '一次随机', en: 'Nonce / Random' }, threatIcon: '🔄', defendIcon: '🎲' },
    { threat: { zh: '彩虹表爆破', en: 'Rainbow Table' }, defend: { zh: '密码加盐', en: 'Password Salting' }, threatIcon: '🌈', defendIcon: '🧂' },
    { threat: { zh: '量子毁灭', en: 'Quantum Threat' }, defend: { zh: '后量子', en: 'Post-Quantum' }, threatIcon: '💥', defendIcon: '⚛️' },
    { threat: { zh: '数据库拖库', en: 'Data Dumping' }, defend: { zh: '字段加密', en: 'Field Encryption' }, threatIcon: '🗄️', defendIcon: '📊' },
    { threat: { zh: '侧信道探测', en: 'Side-Channel' }, defend: { zh: '常量时间', en: 'Constant Time' }, threatIcon: '🕵️', defendIcon: '⏱️' },
    { threat: { zh: '密钥泄露', en: 'Key Leakage' }, defend: { zh: '公钥加密', en: 'Public Key Enc.' }, threatIcon: '🔓', defendIcon: '🔐' },
  ];

  // Find tools unlocked for specified level
  const getUnlockedToolsForLevel = (levelId: number): ToolType[] => {
    return ['AES', 'CERT_TLS', 'HMAC_NONCE', 'SALT_BCRYPT', 'KYBER', 'ENC_STORAGE', 'CONST_TIME', 'ASYM_KEY'];
  };

  // Keyboard controls listener to quickly change weapons using keys 1-8
  useEffect(() => {
    const handleKeydown = (e: KeyboardEvent) => {
      if (!isPlaying || levelStatus !== 'PLAYING') return;
      
      const unlocked = activeLevel ? getUnlockedToolsForLevel(activeLevel.id) : [];
      
      let selectedTool: ToolType | null = null;
      switch (e.key) {
        case '1':
          if (unlocked.includes('AES')) selectedTool = 'AES';
          break;
        case '2':
          if (unlocked.includes('CERT_TLS')) selectedTool = 'CERT_TLS';
          break;
        case '3':
          if (unlocked.includes('HMAC_NONCE')) selectedTool = 'HMAC_NONCE';
          break;
        case '4':
          if (unlocked.includes('SALT_BCRYPT')) selectedTool = 'SALT_BCRYPT';
          break;
        case '5':
          if (unlocked.includes('KYBER')) selectedTool = 'KYBER';
          break;
        case '6':
          if (unlocked.includes('ENC_STORAGE')) selectedTool = 'ENC_STORAGE';
          break;
        case '7':
          if (unlocked.includes('CONST_TIME')) selectedTool = 'CONST_TIME';
          break;
        case '8':
          if (unlocked.includes('ASYM_KEY')) selectedTool = 'ASYM_KEY';
          break;
      }

      if (selectedTool) {
        setActiveTool(selectedTool);
        setLastTrigger({ tool: selectedTool, timestamp: Date.now() });
      }
    };

    window.addEventListener('keydown', handleKeydown);
    return () => window.removeEventListener('keydown', handleKeydown);
  }, [isPlaying, activeLevel, levelStatus]);

  // Handle Level Selected & Deploy
  const startLevel = (config: LevelConfig) => {
    setAttempt(prev => prev + 1);
    setActiveLevel(config);
    setScore(0);
    setCombo(0);
    setAccuracy(100);
    setHealth(100);
    setHits(0);
    setMisses(0);
    
    setActiveTool('NONE');
    setLevelStatus('PLAYING');
    setIsPlaying(true);
    soundEngine.startBGM(config.bpm);
  };

  // Synchronize scoring from Phaser Game Engine
  const handleScoreUpdate = (
    newScore: number, 
    newCombo: number, 
    newAccuracy: number, 
    newHealth: number,
    newHits: number,
    newMisses: number
  ) => {
    setScore(newScore);
    setCombo(newCombo);
    setAccuracy(newAccuracy);
    setHealth(newHealth);
    setHits(newHits);
    setMisses(newMisses);
  };

  // Synchronize Level Finished from Phaser Game Engine
  const handleLevelFinished = (success: boolean) => {
    soundEngine.stopBGM();
    if (success) {
      soundEngine.playLevelComplete();
      setLevelStatus('SUCCESS');
      if (activeLevel && activeLevel.id > totalClearedLevels) {
        setTotalClearedLevels(activeLevel.id);
      }
    } else {
      soundEngine.playGameOver();
      if (activeLevel) {
        try {
          if (typeof navigator !== 'undefined' && navigator.vibrate) {
            navigator.vibrate(200);
          }
        } catch (e) {}
        startLevel(activeLevel);
      }
    }
  };

  // Handle clicking smiley to go to next level
  const handleGoToLevel = (levelId: number) => {
    startLevel(getGeneratedLevel(levelId));
  };

  const handleShowTutorial = (threat: ThreatType) => {
    setTutorialThreat(threat);
  };

  const toggleMute = () => {
    const nextVal = soundEngine.toggleSound();
    setSoundEnabled(nextVal);
  };

  const getToolDisplayName = (tool: ToolType) => {
    switch (tool) {
      case 'AES': return { label: '对称加密', key: '1', usage: '防御 流量窃听', emoji: '🛠️' };
      case 'CERT_TLS': return { label: '数字证书', key: '2', usage: '防御 中间人劫持', emoji: '🛡️' };
      case 'HMAC_NONCE': return { label: '一次随机', key: '3', usage: '防御 重放攻击', emoji: '🎲' };
      case 'SALT_BCRYPT': return { label: '密码加盐', key: '4', usage: '防御 彩虹表爆破', emoji: '🧂' };
      case 'KYBER': return { label: '后量子', key: '5', usage: '防御 量子毁灭', emoji: '⚛️' };
      case 'ENC_STORAGE': return { label: '字段加密', key: '6', usage: '防御 数据库拖库', emoji: '📊' };
      case 'CONST_TIME': return { label: '常量时间', key: '7', usage: '防御 侧信道探测', emoji: '⏱️' };
      case 'ASYM_KEY': return { label: '公钥加密', key: '8', usage: '防御 密钥泄露', emoji: '🔐' };
      default: return { label: 'NONE', key: '', usage: '', emoji: '' };
    }
  };

  return (
    <div className="min-h-screen bg-cyber-dark text-cyber-green flex flex-col font-mono relative antialiased selection:bg-cyber-green selection:text-cyber-dark select-none border-4 border-cyber-border">
      
      {/* Dynamic radial grid aesthetic background */}
      <div className="absolute inset-0 bg-[radial-gradient(#1a2b2f_1px,transparent_1px)] bg-[size:40px_40px] pointer-events-none" />

      {/* MAIN LAYOUT - Game Interface Only */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 flex flex-col items-center justify-center w-full">
        
        {levelStatus === 'PLAYING' && activeLevel && (
          <div className="space-y-6 w-full flex flex-col items-center">
            
            <div className="w-full max-w-[480px] flex justify-between items-center px-4">
              <div className="flex items-center gap-2">
                <div className="w-[80px] h-4 bg-slate-800 rounded-full overflow-hidden border border-slate-600">
                  <div 
                    className="h-full rounded-full transition-all duration-300"
                    style={{
                      width: `${(health / (activeLevel.initialHealth || 5)) * 100}%`,
                      backgroundColor: health / (activeLevel.initialHealth || 5) < 0.4 ? '#ef4444' : '#10b981'
                    }}
                  />
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[12px] font-display text-cyber-green font-bold tracking-wider">
                  
                </span>
                <span className="text-[12px] font-display text-cyan-400 font-bold tracking-wider">
                  {activeLevel.id}/10
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={toggleMute}
                  className="p-1.5 rounded-lg bg-cyber-dark/50 text-cyber-green hover:text-white border border-cyber-green/30 transition-all cursor-pointer"
                  title={soundEnabled ? "静音" : "恢复音效"}
                >
                  {soundEnabled ? <Volume2 size={14} /> : <VolumeX size={14} />}
                </button>
                <button
                  onClick={() => setShowHelp(true)}
                  className="p-1.5 rounded-lg bg-cyber-dark/50 text-cyber-green hover:text-white border border-cyber-green/30 transition-all cursor-pointer"
                  title="帮助"
                >
                  <HelpCircle size={14} />
                </button>
              </div>
            </div>

            {/* Canvas */}
            <GameCanvas
              key={attempt}
              levelConfig={activeLevel}
              activeTool={activeTool}
              lastTrigger={lastTrigger}
              isPaused={tutorialThreat !== null || showHelp}
              score={score}
              onScoreUpdate={handleScoreUpdate}
              onShowTutorial={handleShowTutorial}
              onLevelFinished={handleLevelFinished}
              onGoToLevel={handleGoToLevel}
            />

            {/* BOTTOM TOOL ARSENAL TOOLBAR */}
            <div className="bg-cyber-panel border-2 border-cyber-border rounded-2xl p-2 sm:p-3 w-full max-w-[480px] shadow-[0_0_20px_rgba(0,255,156,0.08)]">
              <div className="grid grid-cols-4 gap-1.5 sm:gap-2">
                {['AES', 'CERT_TLS', 'HMAC_NONCE', 'SALT_BCRYPT', 'KYBER', 'ENC_STORAGE', 'CONST_TIME', 'ASYM_KEY'].map((tool, index) => {
                  const t = tool as ToolType;
                  const spec = getToolDisplayName(t);
                  const isUnlocked = activeLevel && getUnlockedToolsForLevel(activeLevel.id).includes(t);
                  const isActive = activeTool === t;

                  return (
                    <button
                      key={tool}
                      disabled={!isUnlocked}
                      onClick={() => {
                        setActiveTool(t);
                        setLastTrigger({ tool: t, timestamp: Date.now() });
                        soundEngine.playHit();
                      }}
                      className={`relative px-2 py-2 sm:px-3 sm:py-3 rounded-lg sm:rounded-xl flex flex-col items-center justify-center text-center transition-all h-16 sm:h-20 cursor-pointer group overflow-hidden ${
                        !isUnlocked
                          ? 'bg-cyber-dark/30 opacity-20 cursor-not-allowed'
                          : isActive
                            ? 'text-cyber-green'
                            : 'text-[#00ff9c]/75 hover:text-cyber-green'
                      }`}
                      style={{
                        background: isActive 
                          ? 'linear-gradient(135deg, rgba(0,255,156,0.1) 0%, rgba(0,255,156,0.05) 100%), url("data:image/svg+xml,%3Csvg width=\'60\' height=\'60\' viewBox=\'0 0 60 60\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cpath d=\'M30 5l6.4 11.1L48 20l-11.6 6.9L30 35l-6.4-11.1L12 20l11.6-6.9L30 5zm0 10L24.4 24.9 18 30l6.4 5.1L30 40l5.6-5.1L42 30l-6.4-5.1L30 15z\' fill=\'rgba(0,255,156,0.08)\' fill-opacity=\'1\'/%3E%3C/svg%3E)'
                          : 'linear-gradient(135deg, rgba(0,30,20,0.8) 0%, rgba(0,20,15,0.9) 100%), url("data:image/svg+xml,%3Csvg width=\'60\' height=\'60\' viewBox=\'0 0 60 60\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cpath d=\'M30 5l6.4 11.1L48 20l-11.6 6.9L30 35l-6.4-11.1L12 20l11.6-6.9L30 5zm0 10L24.4 24.9 18 30l6.4 5.1L30 40l5.6-5.1L42 30l-6.4-5.1L30 15z\' fill=\'rgba(0,255,156,0.03)\' fill-opacity=\'1\'/%3E%3C/svg%3E)'
                      }}
                    >
                      {/* Tech corner borders */}
                      <div className={`absolute top-0 left-0 w-3 h-3 border-t-2 border-l-2 transition-all duration-300 ${
                        isActive ? 'border-cyber-green shadow-[0_0_8px_rgba(0,255,156,0.8)]' : 'border-cyber-green/30'
                      }`} />
                      <div className={`absolute top-0 right-0 w-3 h-3 border-t-2 border-r-2 transition-all duration-300 ${
                        isActive ? 'border-cyber-green shadow-[0_0_8px_rgba(0,255,156,0.8)]' : 'border-cyber-green/30'
                      }`} />
                      <div className={`absolute bottom-0 left-0 w-3 h-3 border-b-2 border-l-2 transition-all duration-300 ${
                        isActive ? 'border-cyber-green shadow-[0_0_8px_rgba(0,255,156,0.8)]' : 'border-cyber-green/30'
                      }`} />
                      <div className={`absolute bottom-0 right-0 w-3 h-3 border-b-2 border-r-2 transition-all duration-300 ${
                        isActive ? 'border-cyber-green shadow-[0_0_8px_rgba(0,255,156,0.8)]' : 'border-cyber-green/30'
                      }`} />
                      
                      {/* Glow overlay for active state */}
                      {isActive && (
                        <div className="absolute inset-0 bg-gradient-radial from-cyber-green/10 via-transparent to-transparent animate-pulse" />
                      )}
                      

{/* 外层格子：保持 aspect-square 确保正方形，去掉内边距让图标有最大伸展空间 */}
<div className="w-full aspect-square p-0 flex items-center justify-center relative">
  
  {/* 4个角的点阵边框装饰线保持原样 */}
  <div className="absolute inset-0 border-dashed border-emerald-500/30 pointer-events-none" />

  {/* 内部图标：去掉了原先的 border 和高宽限制，直接由字号撑满 */}
  <span className={`text-[36px] sm:text-[44px] leading-none relative z-10 inline-block ${
    isActive ? 'drop-shadow-[0_0_10px_rgba(0,255,156,0.8)]' : ''
  }`}>
    {spec.emoji}
  </span>
  
</div>

                    </button>
                  );
                })}
              </div>
            </div>

            {/* LEVEL SELECTOR BUTTONS */}
            <div className="flex justify-center gap-1.5 sm:gap-2 mt-4">
              {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((levelNum) => (
                <button
                  key={levelNum}
                  onClick={() => startLevel(getGeneratedLevel(levelNum))}
                  className={`w-7 h-7 sm:w-8 sm:h-8 rounded-lg sm:rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                    activeLevel?.id === levelNum
                      ? 'bg-cyber-green text-cyber-dark shadow-[0_0_10px_rgba(0,255,156,0.3)]'
                      : 'bg-cyber-dark border border-cyber-green/20 text-cyber-green/70 hover:border-cyber-green/50 hover:text-cyber-green'
                  }`}
                >
                  {levelNum}
                </button>
              ))}
            </div>

          </div>
        )}

        {/* SUCCESS OVERLAY - Show "挑战下一关" or "重新挑战" button */}
        {levelStatus === 'SUCCESS' && activeLevel && (
          <div className="w-full max-w-lg border-2 border-cyber-green bg-cyber-panel/95 rounded-2xl p-6 space-y-6 text-center select-none shadow-[0_0_50px_rgba(0,255,156,0.25)]">
            <div className="w-16 h-16 bg-cyber-green/10 border border-cyber-green/35 text-cyber-green rounded-2xl flex items-center justify-center mx-auto">
              <Award size={36} />
            </div>

            <div className="space-y-2">
              <h2 className="text-6xl font-display text-cyber-green font-extrabold">
                😄
              </h2>
            </div>

            <div className="flex justify-center gap-3 pt-2">
              {activeLevel.id < 10 ? (
                <button
                  onClick={() => startLevel(getGeneratedLevel(activeLevel.id + 1))}
                  className="px-6 py-2.5 bg-cyber-green hover:bg-cyber-green/85 text-cyber-dark font-display font-extrabold text-sm rounded-lg transition-all shadow-[0_0_15px_rgba(0,255,156,0.3)] hover:scale-[1.03] cursor-pointer"
                >
                  挑战第{activeLevel.id + 1}关 <ChevronRight size={14} className="inline-block ml-1" />
                </button>
              ) : (
                <button
                  onClick={() => startLevel(getGeneratedLevel(1))}
                  className="px-6 py-2.5 bg-cyber-green hover:bg-cyber-green/85 text-cyber-dark font-display font-extrabold text-sm rounded-lg transition-all shadow-[0_0_15px_rgba(0,255,156,0.3)] hover:scale-[1.03] cursor-pointer"
                >
                  重新挑战 <RotateCcw size={14} className="inline-block ml-1" />
                </button>
              )}
            </div>
          </div>
        )}

      </main>

      {/* HELP OVERLAY */}
      {showHelp && (
        <div 
          className="fixed inset-0 bg-slate-900/90 flex items-center justify-center z-50 p-4"
          onClick={() => setShowHelp(false)}
        >
          <div 
            className="bg-cyber-panel border-2 border-cyber-green rounded-2xl p-6 w-full max-w-[400px] shadow-[0_0_30px_rgba(0,255,156,0.2)] relative"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-display text-cyber-green font-bold">
                {helpLang === 'zh' ? '攻击防御列表' : 'Attack & Defense'}
              </h3>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setHelpLang(helpLang === 'zh' ? 'en' : 'zh')}
                  className="px-2 py-1 rounded-lg bg-cyber-dark/50 text-cyber-green hover:text-white border border-cyber-green/30 transition-all cursor-pointer text-xs font-bold"
                >
                  {helpLang === 'zh' ? 'EN' : '中'}
                </button>
                <button
                  onClick={() => setShowHelp(false)}
                  className="p-1 rounded-lg text-cyber-green hover:text-white transition-colors cursor-pointer"
                >
                  <X size={18} />
                </button>
              </div>
            </div>
            <div className="space-y-3">
              {threatDefendList.map((item, index) => (
                <div key={index}>
                  <div className="text-sm text-slate-300">
                    {item.threatIcon} {helpLang === 'en' ? item.threat.en : item.threat.zh}
                  </div>
                  <div className="text-sm text-cyber-green pl-4">
                    └─ {item.defendIcon} {helpLang === 'en' ? item.defend.en : item.defend.zh}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* FOOTER */}
      <footer className="border-t border-cyber-border py-6 mt-12 bg-cyber-dark/80 text-center relative z-10 text-slate-500 font-mono text-[12px] space-y-1">
        <p></p>
        <p className="opacity-80">MIDKEY | CYBER WAR</p>
      </footer>

    </div>
  );
}
