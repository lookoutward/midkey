export interface LevelConfig {
  id: number;
  name: string;
  latencyIncreaseRate: number; // ms per second
  sineSpeed: number;
  amplitude: number;
  pauseFactor: number; // 0 (no pause) to 1 (infinite pause)
  tolerance: number; // Precision pixel tolerance
  noiseFrequency?: number;
  noiseAmplitude?: number;
}

export type GameStatus = "INTRO" | "PLAYING" | "LEVEL_CLEAR" | "GAMEOVER" | "VICTORY";

export interface GameState {
  level: number;
  latency: number;
  successCount: number;
  status: GameStatus;
  highScore: number;
}

export const LEVELS: LevelConfig[] = [
  {
    id: 1,
    name: "渤海第一数据站 (Bohai Station 1)",
    latencyIncreaseRate: 5,
    sineSpeed: 0.0020,
    amplitude: 100,
    pauseFactor: 0.8,
    tolerance: 30.0,
  },
  {
    id: 2,
    name: "黄海防线 (Yellow Sea Defense)",
    latencyIncreaseRate: 7,
    sineSpeed: 0.0029,
    amplitude: 110,
    pauseFactor: 0.7,
    tolerance: 27.6,
  },
  {
    id: 3,
    name: "东海枢纽 (East China Sea Hub)",
    latencyIncreaseRate: 10,
    sineSpeed: 0.0038,
    amplitude: 120,
    pauseFactor: 0.6,
    tolerance: 25.2,
    noiseFrequency: 12,
    noiseAmplitude: 5,
  },
  {
    id: 4,
    name: "南海深海网关 (South China Sea Deep Gateway)",
    latencyIncreaseRate: 12,
    sineSpeed: 0.0047,
    amplitude: 130,
    pauseFactor: 0.5,
    tolerance: 22.8,
    noiseFrequency: 18,
    noiseAmplitude: 8,
  },
  {
    id: 5,
    name: "太平洋中继站 (Pacific Relay Station)",
    latencyIncreaseRate: 15,
    sineSpeed: 0.0056,
    amplitude: 140,
    pauseFactor: 0.4,
    tolerance: 20.4,
  },
];
