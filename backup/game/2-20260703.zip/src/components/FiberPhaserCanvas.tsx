import React, { useEffect, useRef } from "react";
import * as Phaser from "phaser";
import { GameStatus, LevelConfig, LEVELS } from "../types";

interface FiberPhaserCanvasProps {
  playerY: number; // 0 to 100
  onChangePlayerY: (y: number) => void;
  level: number;
  status: GameStatus;
  onSplicingAttempt: (success: boolean, errorPixels: number) => void;
  triggerSplicingRef: React.MutableRefObject<(() => void) | null>;
}

export const FiberPhaserCanvas: React.FC<FiberPhaserCanvasProps> = ({
  playerY,
  onChangePlayerY,
  level,
  status,
  onSplicingAttempt,
  triggerSplicingRef,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const gameRef = useRef<Phaser.Game | null>(null);
  const propsRef = useRef({ playerY, level, status, onChangePlayerY, onSplicingAttempt });

  // Keep props ref updated to avoid stale closures in Phaser event handlers
  useEffect(() => {
    propsRef.current = { playerY, level, status, onChangePlayerY, onSplicingAttempt };
  }, [playerY, level, status, onChangePlayerY, onSplicingAttempt]);

  useEffect(() => {
    if (!containerRef.current) return;

    // Dimensions
    const width = 800;
    const height = 400;
    const centerY = height / 2;

    class SplicingScene extends Phaser.Scene {
      // Game States
      private playerYCoord: number = centerY;
      private rightFiberY: number = centerY;
      private phase: number = 0;
      private noiseTime: number = 0;
      private levelConfig: LevelConfig = LEVELS[0];
      private gameStatus: GameStatus = "INTRO";

      // Graphics and visual buffers
      private gridGraphics!: Phaser.GameObjects.Graphics;
      private oscGraphics!: Phaser.GameObjects.Graphics;
      private fiberGraphics!: Phaser.GameObjects.Graphics;
      private greenEmitter!: Phaser.GameObjects.Particles.ParticleEmitter;
      private redEmitter!: Phaser.GameObjects.Particles.ParticleEmitter;
      private splicerHead!: Phaser.GameObjects.Sprite;
      private splicerCanvas!: HTMLCanvasElement;
      private sCtx!: CanvasRenderingContext2D | null;
      private lastRenderedTolerance: number = -1;

      // Oscilloscope trace history: {x, y, alpha}
      private oscHistory: Array<{ x: number; y: number; time: number }> = [];

      // Flowing data packet particles
      private leftPackets: Array<{ progress: number; speed: number }> = [];
      private rightPackets: Array<{ progress: number; speed: number }> = [];

      // Splicing effect state
      private spliceEffectActive: boolean = false;
      private spliceEffectType: "SUCCESS" | "FAILURE" | null = null;
      private spliceEffectTimer: number = 0;
      private spliceEffectY: number = 0;

      // Key controls
      private cursors!: Phaser.Types.Input.Keyboard.CursorKeys;
      private spaceKey!: Phaser.Input.Keyboard.Key;

      constructor() {
        super("SplicingScene");
      }

      init() {
        this.playerYCoord = centerY;
        this.rightFiberY = centerY;
        this.phase = 0;
        this.noiseTime = 0;
        this.levelConfig = LEVELS[level - 1] || LEVELS[0];
        this.gameStatus = status;

        // Initialize particles
        this.leftPackets = [
          { progress: 0.1, speed: 0.2 },
          { progress: 0.4, speed: 0.25 },
          { progress: 0.7, speed: 0.18 },
        ];
        this.rightPackets = [
          { progress: 0.15, speed: 0.22 },
          { progress: 0.5, speed: 0.15 },
          { progress: 0.8, speed: 0.28 },
        ];
      }

      preload() {
        // Create dynamic textures since we want 0 external file dependencies
        const sparkCanvas = document.createElement("canvas");
        sparkCanvas.width = 16;
        sparkCanvas.height = 16;
        const ctx = sparkCanvas.getContext("2d");
        if (ctx) {
          const gradient = ctx.createRadialGradient(8, 8, 0, 8, 8, 8);
          gradient.addColorStop(0, "rgba(255, 255, 255, 1)");
          gradient.addColorStop(0.3, "rgba(0, 255, 102, 0.8)");
          gradient.addColorStop(1, "rgba(0, 255, 102, 0)");
          ctx.fillStyle = gradient;
          ctx.fillRect(0, 0, 16, 16);
        }
        this.textures.addCanvas("spark", sparkCanvas);

        const redSparkCanvas = document.createElement("canvas");
        redSparkCanvas.width = 16;
        redSparkCanvas.height = 16;
        const redCtx = redSparkCanvas.getContext("2d");
        if (redCtx) {
          const gradient = redCtx.createRadialGradient(8, 8, 0, 8, 8, 8);
          gradient.addColorStop(0, "rgba(255, 255, 255, 1)");
          gradient.addColorStop(0.3, "rgba(255, 51, 51, 0.8)");
          gradient.addColorStop(1, "rgba(255, 51, 51, 0)");
          redCtx.fillStyle = gradient;
          redCtx.fillRect(0, 0, 16, 16);
        }
        this.textures.addCanvas("redspark", redSparkCanvas);

        // High-tech Fusion Splicer Head Texture
        this.splicerCanvas = document.createElement("canvas");
        this.splicerCanvas.width = 40;
        this.splicerCanvas.height = 360;
        this.sCtx = this.splicerCanvas.getContext("2d");
        this.textures.addCanvas("splicer_head", this.splicerCanvas);
        this.lastRenderedTolerance = -1; // Force initial render on update
      }

      create() {
        // Setup graphics layers
        this.gridGraphics = this.add.graphics();
        this.oscGraphics = this.add.graphics();
        this.fiberGraphics = this.add.graphics();

        // Instantiate splicerHead Sprite right at the vertical centerline centerY and horizontally centered
        this.splicerHead = this.add.sprite(400, centerY, "splicer_head");
        this.splicerHead.setDepth(10); // Elevated depth above background traces

        // Green Splicing Success Particles
        this.greenEmitter = this.add.particles(0, 0, "spark", {
          lifespan: { min: 400, max: 900 },
          speed: { min: 120, max: 280 },
          scale: { start: 1.3, end: 0 },
          blendMode: "ADD",
          emitting: false,
        });

        // Red Splicing Failure Particles
        this.redEmitter = this.add.particles(0, 0, "redspark", {
          lifespan: { min: 300, max: 700 },
          speed: { min: 90, max: 220 },
          scale: { start: 1.1, end: 0 },
          blendMode: "ADD",
          emitting: false,
        });

        // Setup Controls
        if (this.input && this.input.keyboard) {
          this.cursors = this.input.keyboard.createCursorKeys();
          this.spaceKey = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SPACE);
        }

        // Expose triggerSplicing to React ref
        triggerSplicingRef.current = () => {
          this.executeSplicing();
        };
      }

      update(time: number, delta: number) {
        // Update variables from props
        this.gameStatus = propsRef.current.status;
        this.levelConfig = LEVELS[propsRef.current.level - 1] || LEVELS[0];
        
        // Dynamically redraw splicer head electrodes if the tolerance has changed for the current level
        const currentTolerance = this.levelConfig.tolerance;
        if (this.lastRenderedTolerance !== currentTolerance) {
          this.lastRenderedTolerance = currentTolerance;
          this.redrawSplicerHead(currentTolerance);
        }

        // Left green fiber is always stationary at the vertical default/center position (centerY = 200)
        this.playerYCoord = centerY;

        const dt = delta / 1000; // time step in seconds

        // Keyboard Controls (Only active when playing)
        if (this.gameStatus === "PLAYING" && this.spaceKey) {
          // Space key listener to trigger splicing
          if (Phaser.Input.Keyboard.JustDown(this.spaceKey)) {
            this.executeSplicing();
          }
        }

        // Calculate Right Fiber Movement
        if (this.gameStatus === "PLAYING") {
          const speed = this.levelConfig.sineSpeed;
          const pauseFactor = this.levelConfig.pauseFactor;

          // Non-linear time mapping for peak & trough pause
          // Slows down the speed of phase increment when sin(phase) is near 1 or -1
          const slowdown = 1.0 - pauseFactor * Math.abs(Math.sin(this.phase));
          this.phase += speed * slowdown * delta;

          // Calculate core sine position
          let targetY = centerY + Math.sin(this.phase) * this.levelConfig.amplitude;

          // Add random high-frequency noise for Level 3
          if (this.levelConfig.noiseFrequency && this.levelConfig.noiseAmplitude) {
            this.noiseTime += dt;
            const noise = Math.sin(this.noiseTime * this.levelConfig.noiseFrequency) * this.levelConfig.noiseAmplitude;
            targetY += noise;
          }

          this.rightFiberY = Phaser.Math.Clamp(targetY, 50, 350);

          // Update Oscilloscope trace buffer
          this.oscHistory.push({
            x: 415,
            y: this.rightFiberY,
            time: time,
          });

          // Drift trace leftward over time
          this.oscHistory.forEach((pt) => {
            pt.x -= 250 * dt; // speed of oscilloscope scroll
          });

          // Trim old history entries
          this.oscHistory = this.oscHistory.filter((pt) => pt.x > 30);
        } else {
          // If not playing, keep red fiber resting gently in the center
          this.rightFiberY = centerY + Math.sin(time / 1000) * 20;
          this.oscHistory = [];
        }

        // Dynamic Splicer Head Visual States & Animations
        const error = Math.abs(this.rightFiberY - this.splicerHead.y);
        const isInTolerance = error <= currentTolerance;

        if (this.gameStatus === "PLAYING") {
          if (this.spliceEffectActive) {
            if (this.spliceEffectType === "SUCCESS") {
              // Flashing brilliant fluorescent fusion-green on success fusion burst
              this.splicerHead.setTint(0x00ff66);
              this.splicerHead.setScale(1.08);
            } else {
              // Distressed bright red tint & heavy horizontal vibration
              this.splicerHead.setTint(0xff3333);
              this.splicerHead.x = 400 + (Math.random() - 0.5) * 6;
            }
          } else {
            // Restore normal position
            this.splicerHead.x = 400;

            if (isInTolerance) {
              // High-frequency blinking fluorescent green warning (flashing rapidly)
              const isFlashOn = Math.floor(time / 45) % 2 === 0;
              if (isFlashOn) {
                this.splicerHead.setTint(0x39ff14); // neon/fluorescent green
              } else {
                this.splicerHead.setTint(0x00ffff); // electric cyan
              }
              this.splicerHead.setScale(1.06 + Math.sin(time / 20) * 0.05); // High-frequency scale pulses
            } else {
              // Default clean state
              this.splicerHead.clearTint();
              this.splicerHead.setScale(1.0);
            }
          }
        } else {
          this.splicerHead.x = 400;
          this.splicerHead.clearTint();
          this.splicerHead.setScale(1.0);
        }

        // Animate flowing data packets
        this.leftPackets.forEach((p) => {
          p.progress += p.speed * dt;
          if (p.progress > 1) p.progress = 0;
        });
        this.rightPackets.forEach((p) => {
          p.progress += p.speed * dt;
          if (p.progress > 1) p.progress = 0;
        });

        // Update splicing effect
        if (this.spliceEffectActive) {
          this.spliceEffectTimer -= delta;
          if (this.spliceEffectTimer <= 0) {
            this.spliceEffectActive = false;
          }
        }

        // Render Everything
        this.drawScene(time);
      }

      private executeSplicing() {
        if (this.gameStatus !== "PLAYING" || this.spliceEffectActive) return;

        // Perform precision splicing verification with dynamic level-specific pixel tolerance
        const errorPixels = Math.abs(this.playerYCoord - this.rightFiberY);
        const success = errorPixels <= this.levelConfig.tolerance;

        this.spliceEffectActive = true;
        this.spliceEffectTimer = 400; // millisecond duration
        this.spliceEffectType = success ? "SUCCESS" : "FAILURE";
        this.spliceEffectY = (this.playerYCoord + this.rightFiberY) / 2;

        if (success) {
          // Trigger magnificent radial flow of bright green particles from splicer head center
          this.greenEmitter.explode(40, 400, centerY);
        } else {
          // Spray outward from both electrodes and center point
          this.redEmitter.explode(15, 400, centerY - 15);
          this.redEmitter.explode(15, 400, centerY + 15);
          this.redEmitter.explode(15, 400, this.rightFiberY);

          // Intense camera shake for tactile alarm feedback
          this.cameras.main.shake(150, 0.012);
        }

        // Notify React layer
        propsRef.current.onSplicingAttempt(success, errorPixels);
      }

      private redrawSplicerHead(tolerance: number) {
        if (!this.sCtx) return;
        const sCtx = this.sCtx;
        sCtx.clearRect(0, 0, 40, 360);

        // Center of splicer canvas is 180 (360 / 2)
        // Top and bottom yellow dots should be at distance of tolerance on each side
        const topTipY = 180 - tolerance;
        const bottomTipY = 180 + tolerance;

        // Top Metal Electrode body pointing down
        const gradTop = sCtx.createLinearGradient(0, 0, 40, 0);
        gradTop.addColorStop(0, "#0c1524");
        gradTop.addColorStop(0.3, "#334155");
        gradTop.addColorStop(0.5, "#475569");
        gradTop.addColorStop(0.7, "#334155");
        gradTop.addColorStop(1, "#0c1524");
        sCtx.fillStyle = gradTop;

        sCtx.beginPath();
        sCtx.moveTo(4, 0);
        sCtx.lineTo(36, 0);
        // Taper down to the topTipY
        sCtx.lineTo(28, Math.max(0, topTipY - 37));
        sCtx.lineTo(20, topTipY);
        sCtx.lineTo(12, Math.max(0, topTipY - 37));
        sCtx.closePath();
        sCtx.fill();

        // Highlight metallic borders
        sCtx.strokeStyle = "rgba(0, 242, 255, 0.4)";
        sCtx.lineWidth = 1;
        sCtx.stroke();

        // Gold electrical tip (yellow dot)
        sCtx.fillStyle = "#fbbf24";
        sCtx.beginPath();
        sCtx.arc(20, topTipY, 4.5, 0, Math.PI * 2); // Slightly larger radius for excellent high-DPI visibility
        sCtx.fill();

        // Bottom Metal Electrode body pointing up
        const gradBot = sCtx.createLinearGradient(0, 0, 40, 0);
        gradBot.addColorStop(0, "#0c1524");
        gradBot.addColorStop(0.3, "#334155");
        gradBot.addColorStop(0.5, "#475569");
        gradBot.addColorStop(0.7, "#334155");
        gradBot.addColorStop(1, "#0c1524");
        sCtx.fillStyle = gradBot;

        sCtx.beginPath();
        sCtx.moveTo(4, 360);
        sCtx.lineTo(36, 360);
        // Taper up to bottomTipY
        sCtx.lineTo(28, Math.min(360, bottomTipY + 37));
        sCtx.lineTo(20, bottomTipY);
        sCtx.lineTo(12, Math.min(360, bottomTipY + 37));
        sCtx.closePath();
        sCtx.fill();
        sCtx.stroke();

        // Gold electrical tip (yellow dot)
        sCtx.fillStyle = "#fbbf24";
        sCtx.beginPath();
        sCtx.arc(20, bottomTipY, 4.5, 0, Math.PI * 2);
        sCtx.fill();

        // Refresh Phaser texture from modified canvas
        const tex = this.textures.get("splicer_head") as Phaser.Textures.CanvasTexture;
        if (tex && typeof tex.update === "function") {
          tex.update();
        }
      }

      private drawScene(time: number) {
        // Clear layers
        this.gridGraphics.clear();
        this.oscGraphics.clear();
        this.fiberGraphics.clear();

        // 1. Draw Tech Grid Background
        this.drawGrid(time);

        // 2. Draw Oscilloscope historic trace (Red fiber trail)
        this.drawOscilloscopeTrace();

        // 3. Draw Splicing Area crosshairs & guidelines
        this.drawGuidelines();

        // 4. Draw Fibers (Left green, Right red)
        this.drawFibers();

        // 5. Draw splicing active explosion lines/visuals
        this.drawSplicingEffects();
      }

      private drawGrid(time: number) {
        const gridColor = 0x111c33; // Deep space cyan/blue lines
        const crosshairColor = 0x223a66;
        
        this.gridGraphics.lineStyle(1, gridColor, 1);

        // Vertical lines
        const cols = 20;
        const colWidth = width / cols;
        for (let i = 0; i <= cols; i++) {
          const x = i * colWidth;
          this.gridGraphics.lineBetween(x, 0, x, height);
        }

        // Horizontal lines
        const rows = 10;
        const rowHeight = height / rows;
        for (let j = 0; j <= rows; j++) {
          const y = j * rowHeight;
          this.gridGraphics.lineBetween(0, y, width, y);
        }

        // Center crosshair guidelines (coordinate radar look)
        this.gridGraphics.lineStyle(1.5, crosshairColor, 0.6);
        this.gridGraphics.lineBetween(width / 2, 20, width / 2, height - 20);
        this.gridGraphics.lineBetween(30, centerY, width - 30, centerY);

        // Calibration marks in the margins
        this.gridGraphics.fillStyle(0x00d2ff, 0.4);
        for (let y = 50; y <= 350; y += 50) {
          // left and right small gauge ticks
          this.gridGraphics.fillRect(25, y - 1, 6, 2);
          this.gridGraphics.fillRect(width - 31, y - 1, 6, 2);
        }
      }

      private drawOscilloscopeTrace() {
        if (this.oscHistory.length < 2) return;

        // Draw fading red neon tail indicating frequency pattern
        this.oscGraphics.lineStyle(1.5, 0xff0000, 0.25);
        this.oscGraphics.beginPath();
        this.oscGraphics.moveTo(this.oscHistory[0].x, this.oscHistory[0].y);

        for (let i = 1; i < this.oscHistory.length; i++) {
          const pt = this.oscHistory[i];
          // Gradient fade as x decreases (moving leftwards away from center)
          const alpha = Phaser.Math.Percent(pt.x, 30, 415) * 0.4;
          
          this.oscGraphics.lineStyle(2, 0xff3333, alpha);
          this.oscGraphics.lineTo(pt.x, pt.y);
        }
        this.oscGraphics.strokePath();
      }

      private drawGuidelines() {
        // Draw the dynamic tolerance zone based on levelConfig.tolerance around the stationary centerY = 200
        const tol = this.levelConfig.tolerance;
        // Draw a light translucent green band in the center splicing gap
        this.fiberGraphics.fillStyle(0x00ff66, 0.08);
        this.fiberGraphics.fillRect(340, centerY - tol, 120, tol * 2);

        // Draw dotted/dashed neon-green line bounds for the tolerance zone
        this.fiberGraphics.lineStyle(1, 0x00ff66, 0.45);
        this.fiberGraphics.lineBetween(340, centerY - tol, 460, centerY - tol);
        this.fiberGraphics.lineBetween(340, centerY + tol, 460, centerY + tol);

        // Draw brackets around the stationary left alignment tip to mark the home target
        const bracketSize = 8;
        this.fiberGraphics.lineStyle(1.5, 0x00ff66, 0.85);
        // Top-left corner
        this.fiberGraphics.lineBetween(375, centerY - 10, 375, centerY - 10 + bracketSize);
        this.fiberGraphics.lineBetween(375, centerY - 10, 375 + bracketSize, centerY - 10);
        // Bottom-left corner
        this.fiberGraphics.lineBetween(375, centerY + 10, 375, centerY + 10 - bracketSize);
        this.fiberGraphics.lineBetween(375, centerY + 10, 375 + bracketSize, centerY + 10);

        // Draw active target brackets following the right fiber as it moves
        const frameColor = 0xff3333; // red, matches the moving fiber
        this.fiberGraphics.lineStyle(1, frameColor, 0.5);
        const targetY = this.rightFiberY;
        // Top-right bracket
        this.fiberGraphics.lineBetween(425, targetY - 10, 425, targetY - 10 + bracketSize);
        this.fiberGraphics.lineBetween(425, targetY - 10, 425 - bracketSize, targetY - 10);
        // Bottom-right bracket
        this.fiberGraphics.lineBetween(425, targetY + 10, 425, targetY + 10 - bracketSize);
        this.fiberGraphics.lineBetween(425, targetY + 10, 425 - bracketSize, targetY + 10);
      }

      private drawFibers() {
        // LEFT FIBER: GREEN (PLAYER)
        const greenGlow = 0x00ff66;
        const greenCore = 0xffffff;

        // Glowing outer core (thick line with low alpha)
        this.fiberGraphics.lineStyle(7, greenGlow, 0.3);
        this.fiberGraphics.lineBetween(30, this.playerYCoord, 385, this.playerYCoord);

        // Sharp central fiber core (thin line, full alpha)
        this.fiberGraphics.lineStyle(2, greenGlow, 1.0);
        this.fiberGraphics.lineBetween(30, this.playerYCoord, 385, this.playerYCoord);

        // Nozzle Connector Head (Left)
        this.fiberGraphics.fillStyle(0x1a332d, 1.0);
        this.fiberGraphics.lineStyle(2, greenGlow, 1.0);
        this.fiberGraphics.fillRect(370, this.playerYCoord - 6, 15, 12);
        this.fiberGraphics.strokeRect(370, this.playerYCoord - 6, 15, 12);

        // Glass cladding ring
        this.fiberGraphics.fillStyle(greenGlow, 1.0);
        this.fiberGraphics.fillCircle(385, this.playerYCoord, 4);

        // White hot tip (core of transmission)
        this.fiberGraphics.fillStyle(greenCore, 1.0);
        this.fiberGraphics.fillCircle(385, this.playerYCoord, 2);

        // Animate packets flowing on Left Fiber
        this.leftPackets.forEach((p) => {
          const packetX = 30 + p.progress * (370 - 30);
          this.fiberGraphics.fillStyle(0xffffff, 0.85);
          this.fiberGraphics.fillCircle(packetX, this.playerYCoord, 3);
          
          // Outer halo
          this.fiberGraphics.fillStyle(greenGlow, 0.4);
          this.fiberGraphics.fillCircle(packetX, this.playerYCoord, 6);
        });


        // RIGHT FIBER: RED (INTERFERENCE SYSTEM)
        const redGlow = 0xff3333;
        const redCore = 0xffffff;

        // Glowing outer core
        this.fiberGraphics.lineStyle(7, redGlow, 0.3);
        this.fiberGraphics.lineBetween(770, this.rightFiberY, 415, this.rightFiberY);

        // Sharp core
        this.fiberGraphics.lineStyle(2, redGlow, 1.0);
        this.fiberGraphics.lineBetween(770, this.rightFiberY, 415, this.rightFiberY);

        // Nozzle Connector Head (Right)
        this.fiberGraphics.fillStyle(0x331a1a, 1.0);
        this.fiberGraphics.lineStyle(2, redGlow, 1.0);
        this.fiberGraphics.fillRect(415, this.rightFiberY - 6, 15, 12);
        this.fiberGraphics.strokeRect(415, this.rightFiberY - 6, 15, 12);

        // Cladding tip
        this.fiberGraphics.fillStyle(redGlow, 1.0);
        this.fiberGraphics.fillCircle(415, this.rightFiberY, 4);

        // White hot core tip
        this.fiberGraphics.fillStyle(redCore, 1.0);
        this.fiberGraphics.fillCircle(415, this.rightFiberY, 2);

        // Animate packets flowing on Right Fiber (system feedback, moving leftwards)
        this.rightPackets.forEach((p) => {
          const packetX = 770 - p.progress * (770 - 430);
          this.fiberGraphics.fillStyle(0xffffff, 0.85);
          this.fiberGraphics.fillCircle(packetX, this.rightFiberY, 3);
          
          // Outer halo
          this.fiberGraphics.fillStyle(redGlow, 0.4);
          this.fiberGraphics.fillCircle(packetX, this.rightFiberY, 6);
        });
      }

      private drawSplicingEffects() {
        // Real-time micro discharge blue arc when within tolerance
        const error = Math.abs(this.rightFiberY - this.splicerHead.y);
        const isInTolerance = error <= this.levelConfig.tolerance;

        if (this.gameStatus === "PLAYING" && isInTolerance && !this.spliceEffectActive) {
          const time = this.time.now;
          // Flickering electric arc between electrode tips (Y = centerY - 15 to Y = centerY + 15)
          this.fiberGraphics.lineStyle(1.5, 0x00d2ff, 0.4 + Math.sin(time / 30) * 0.2);
          this.fiberGraphics.beginPath();
          this.fiberGraphics.moveTo(400, centerY - 15);
          
          const segments = 4;
          const stepY = 30 / segments;
          for (let i = 1; i < segments; i++) {
            const tempY = (centerY - 15) + i * stepY;
            // random jagged horizontal deviation
            const devX = (Math.random() - 0.5) * 5;
            this.fiberGraphics.lineTo(400 + devX, tempY);
          }
          this.fiberGraphics.lineTo(400, centerY + 15);
          this.fiberGraphics.strokePath();

          // Weak halo glow in the gap
          this.fiberGraphics.fillStyle(0x00d2ff, 0.08 + Math.sin(time / 50) * 0.04);
          this.fiberGraphics.fillCircle(400, centerY, 8);
        }

        if (!this.spliceEffectActive) return;

        const durationRatio = this.spliceEffectTimer / 400; // 1 down to 0
        const alpha = durationRatio;

        if (this.spliceEffectType === "SUCCESS") {
          // SUCCESS: Draw solid fluorescent laser beam bridging the gap!
          this.fiberGraphics.lineStyle(6, 0x00ff66, alpha * 0.8);
          this.fiberGraphics.lineBetween(385, this.playerYCoord, 415, this.rightFiberY);

          this.fiberGraphics.lineStyle(2, 0xffffff, alpha);
          this.fiberGraphics.lineBetween(385, this.playerYCoord, 415, this.rightFiberY);

          // Draw expanding fusion shockwave circle
          this.fiberGraphics.lineStyle(2, 0x00ff66, alpha);
          this.fiberGraphics.strokeCircle(400, this.spliceEffectY, (1 - durationRatio) * 60);

          this.fiberGraphics.fillStyle(0xffffff, alpha);
          this.fiberGraphics.fillCircle(400, this.spliceEffectY, 5);
        } else {
          // FAILURE: Draw jagged red electric discharge sparks across the misalignment gap!
          this.fiberGraphics.lineStyle(1.5, 0xff3333, alpha);
          this.fiberGraphics.beginPath();
          this.fiberGraphics.moveTo(385, this.playerYCoord);

          // Generate randomized jagged segments
          const segments = 4;
          const stepX = (415 - 385) / segments;
          const startY = this.playerYCoord;
          const endY = this.rightFiberY;

          for (let i = 1; i < segments; i++) {
            const tempX = 385 + i * stepX;
            // Linear interpolate Y and add random deviation
            const progress = i / segments;
            const interpY = startY + progress * (endY - startY);
            const deviation = (Math.random() - 0.5) * 25;
            this.fiberGraphics.lineTo(tempX, interpY + deviation);
          }
          this.fiberGraphics.lineTo(415, this.rightFiberY);
          this.fiberGraphics.strokePath();

          // Draw lightning shockwave (jagged, low alpha)
          this.fiberGraphics.lineStyle(1, 0xff3333, alpha * 0.4);
          this.fiberGraphics.strokeCircle(400, this.spliceEffectY, (1 - durationRatio) * 40);
        }
      }
    }

    const config: Phaser.Types.Core.GameConfig = {
      type: Phaser.AUTO,
      width,
      height,
      parent: containerRef.current,
      backgroundColor: "#05070a", // Matches console deep black/navy background
      scale: {
        mode: Phaser.Scale.FIT,
        autoCenter: Phaser.Scale.CENTER_BOTH
      },
      physics: {
        default: "arcade",
      },
      scene: [SplicingScene],
    };

    const game = new Phaser.Game(config);
    gameRef.current = game;

    return () => {
      game.destroy(true);
      gameRef.current = null;
    };
  }, [triggerSplicingRef]);

  return (
    <div className="relative border border-[#00f2ff]/20 rounded-xl p-1 bg-[#010204] shadow-[0_0_20px_rgba(0,242,255,0.04)] select-none overflow-hidden">
      <div ref={containerRef} id="phaser-game-container" className="w-full flex justify-center items-center" />
      {/* Scope Calibration Label overlaid inside game canvas (Only blinking green indicator, no text) */}
      <div className="absolute top-3 left-4 text-[10px] font-mono text-[#00f2ff]/60 uppercase tracking-widest flex items-center gap-1.5 pointer-events-none">
        <span className="inline-block w-2.5 h-2.5 rounded-full bg-[#00f2ff] animate-ping"></span>
        <span className="inline-block w-1.5 h-1.5 rounded-full bg-[#00f2ff] absolute left-[17px]"></span>
      </div>
    </div>
  );
};
