import React, { useState, useEffect, useRef } from "react";
import { FiberPhaserCanvas } from "./FiberPhaserCanvas";
import { GameStatus, LEVELS } from "../types";
import { synth } from "./SoundSynth";
import { 
  HelpCircle, 
  Volume2, 
  VolumeX, 
  Check,
  ChevronRight,
  Zap,
  Play,
  X
} from "lucide-react";

export const CyberConsole: React.FC = () => {
  // Game States
  const [level, setLevel] = useState<number>(1);
  const [successCount, setSuccessCount] = useState<number>(0);
  const [status, setStatus] = useState<GameStatus>("INTRO");
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [showHelp, setShowHelp] = useState<boolean>(false);
  const [isEnglish, setIsEnglish] = useState<boolean>(false); // Language switch for Help Menu
  const [justSpliced, setJustSpliced] = useState<"SUCCESS" | "FAILURE" | null>(null);
  const [latency, setLatency] = useState<number>(45);
  const [completedLevels, setCompletedLevels] = useState<number[]>([]);

  // Fluctuating latency simulation (for subtle real-time fluctuations)
  useEffect(() => {
    if (status !== "PLAYING") return;
    const interval = setInterval(() => {
      setLatency(prev => {
        if (prev <= 10) return prev; // Keep optimal latency stable
        const offset = Math.floor(Math.random() * 5) - 2; // ±2 fluctuation
        const newVal = prev + offset;
        return newVal > 15 ? newVal : prev;
      });
    }, 1500);
    return () => clearInterval(interval);
  }, [status]);

  // Real-time difficulty-specific latency penalty increase (+5ms up to +50ms per second)
  useEffect(() => {
    if (status !== "PLAYING") return;
    const currentLevelConfig = LEVELS[level - 1] || LEVELS[0];
    const interval = setInterval(() => {
      setLatency(prev => {
        return prev + currentLevelConfig.latencyIncreaseRate;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [status, level]);

  // A ref to trigger the Phaser scene execute function
  const triggerSplicingRef = useRef<(() => void) | null>(null);

  // Sound control wrappers
  const toggleMute = () => {
    const muted = synth.toggleMute();
    setIsMuted(muted);
  };

  // Start the Game
  const handleStartGame = () => {
    synth.playClick();
    setSuccessCount(0);
    setLatency(45);
    setStatus("PLAYING");
  };

  // Handle Level Transition or Replay
  const handleNextLevel = () => {
    synth.playClick();
    const nextLvl = level < LEVELS.length ? level + 1 : 1;
    setLevel(nextLvl);
    setSuccessCount(0);
    setLatency(45);
    setStatus("PLAYING");
  };

  // Handle a splicing check feedback
  const handleSplicingAttempt = (success: boolean, errorPixels: number) => {
    if (status !== "PLAYING") return;

    if (success) {
      synth.playSuccess();
      setJustSpliced("SUCCESS");
      setLatency(2); // Network latency plummets on success
      setTimeout(() => setJustSpliced(null), 800);

      // Increment Level Success
      setSuccessCount((prevCount) => {
        const nextCount = prevCount + 1;
        
        // Check level clear condition (3 successes)
        if (nextCount === 3) {
          synth.playLevelUp();
          setStatus("LEVEL_CLEAR");
          setCompletedLevels((prev) => prev.includes(level) ? prev : [...prev, level]);
        }
        return nextCount;
      });
    } else {
      synth.playError();
      setJustSpliced("FAILURE");
      setLatency(380); // Network latency spikes on failure
      setTimeout(() => setJustSpliced(null), 800);
    }
  };

  // Trigger Splicing manually via React Button Click
  const handleExecuteSplicing = () => {
    if (triggerSplicingRef.current) {
      synth.playClick();
      triggerSplicingRef.current();
    }
  };

  return (
    <div id="cyber-console-root" className="min-h-screen w-full bg-[#05070a] text-slate-100 flex flex-col font-mono relative overflow-hidden select-none pb-8">
      
      {/* Absolute background matrix scanner lines */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(0,242,255,0.03)_1px,transparent_1px)] bg-[size:100%_4px] pointer-events-none z-0"></div>
      
      {/* TACTICAL GAME OVERLAYS */}
      {justSpliced === "SUCCESS" && (
        <div className="absolute inset-0 bg-emerald-500/5 pointer-events-none z-20 animate-pulse"></div>
      )}

      {/* HEADER SECTION - Adapted to "数据防线" Layout (No Words, Only Icons & Buttons) */}
      <header className="max-w-2xl w-full mx-auto px-4 pt-4 flex items-center justify-between z-10 gap-4">
        
        {/* Left Side: Success progress Capsule/Battery Bar (熔接率) */}
        <div className="flex items-center gap-3">
          <div className="bg-[#0a1a2f]/80 border border-[#00f2ff]/20 px-3 py-1.5 rounded-full flex items-center gap-2 shadow-[0_0_15px_rgba(0,242,255,0.05)]">
            {/* Success Capsule segments */}
            <div className="flex gap-1 bg-black/40 px-1 py-0.5 rounded-full border border-[#00f2ff]/10">
              {[1, 2, 3].map((idx) => {
                const isFilled = successCount >= idx;
                return (
                  <div
                    key={idx}
                    className={`w-6 h-2 rounded-full transition-all duration-300 ${
                      isFilled
                        ? "bg-[#00f2ff] shadow-[0_0_8px_#00f2ff]"
                        : "bg-slate-800"
                    }`}
                  />
                );
              })}
            </div>
          </div>
        </div>

        {/* Center: Stage/Level Indicator in high-contrast digital format */}
        <div className="text-center">
          <div className="text-sm font-bold text-[#00f2ff] tracking-[0.2em] font-mono bg-[#0a1a2f]/60 px-5 py-1.5 rounded-full border border-[#00f2ff]/15 shadow-[0_0_15px_rgba(0,242,255,0.08)]">
            {level}/{LEVELS.length}
          </div>
        </div>

        {/* Right Side: Mute / Sound Toggle & Help buttons */}
        <div className="flex items-center gap-2">
          {/* Sound Toggle */}
          <button
            onClick={toggleMute}
            className={`w-9 h-9 rounded-full border flex items-center justify-center transition-all cursor-pointer ${
              isMuted 
                ? "border-red-500/30 bg-red-950/20 text-red-400 hover:bg-red-950/40" 
                : "border-[#00f2ff]/30 bg-[#0a1a2f]/60 text-[#00f2ff] hover:bg-[#00f2ff]/10"
            }`}
          >
            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>

          {/* Help Manual */}
          <button
            onClick={() => { synth.playClick(); setShowHelp(true); }}
            className="w-9 h-9 rounded-full border border-[#00f2ff]/30 bg-[#0a1a2f]/60 text-[#00f2ff] hover:bg-[#00f2ff]/10 flex items-center justify-center cursor-pointer"
          >
            <HelpCircle className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* MAIN GAME CONTAINER */}
      <main className="flex-1 max-w-2xl w-full mx-auto px-4 mt-6 flex flex-col gap-6 z-10 justify-center">
        
        {/* PLAY VIEWPORT WRAPPER */}
        <div className="relative bg-[#010204] rounded-2xl overflow-hidden border border-[#0a1a2f] shadow-[0_0_30px_rgba(0,242,255,0.05)]">
          
          {/* INTRO SCREEN WITH CONCENTRIC BULLSEYE TARGET (点击开始, No Text) */}
          {status === "INTRO" && (
            <div className="absolute inset-0 bg-[#05070a]/90 z-30 flex flex-col items-center justify-center p-6 text-center backdrop-blur-sm">
              <div className="max-w-sm flex flex-col items-center">
                
                {/* Stunning bullseye target start button */}
                <button
                  onClick={handleStartGame}
                  className="group relative w-36 h-36 rounded-full flex items-center justify-center cursor-pointer transition-transform duration-300 hover:scale-105 active:scale-95 focus:outline-none"
                >
                  {/* Outer glowing ring */}
                  <div className="absolute inset-0 rounded-full border-4 border-[#00f2ff]/40 animate-ping opacity-25"></div>
                  <div className="absolute inset-0 rounded-full border-4 border-red-500/30 shadow-[0_0_25px_rgba(239,68,68,0.2)]"></div>
                  
                  {/* Middle ring */}
                  <div className="w-28 h-28 rounded-full border-4 border-slate-100 bg-[#0a1a2f] flex items-center justify-center shadow-[0_0_15px_rgba(255,255,255,0.1)]">
                    {/* Inner core */}
                    <div className="w-16 h-16 rounded-full bg-red-500 flex items-center justify-center shadow-[0_0_25px_#ef4444] group-hover:bg-red-400 transition-colors">
                      {/* Play Arrow */}
                      <Play className="w-6 h-6 text-white fill-white ml-0.5" />
                    </div>
                  </div>
                </button>
              </div>
            </div>
          )}

          {/* LEVEL CLEAR SCREEN OVERLAY WITH SUCCESS CHECKMARK ICON & NEXT BUTTON (No text) */}
          {status === "LEVEL_CLEAR" && (
            <div className="absolute inset-0 bg-[#05070a]/95 z-30 flex flex-col items-center justify-center p-6 text-center backdrop-blur-sm">
              <div className="max-w-md p-6 rounded-2xl bg-[#0a1a2f]/20 border border-emerald-500/20 flex flex-col items-center">
                
                {/* Glowing Success Checkmark badge */}
                <div className="w-20 h-20 rounded-full bg-emerald-950 border border-emerald-500/40 flex items-center justify-center mb-6 shadow-[0_0_25px_rgba(16,185,129,0.3)]">
                  <Check className="w-10 h-10 text-emerald-400 animate-pulse stroke-[3]" />
                </div>

                {/* Big Next Step Action (Icon-only, no words) */}
                <button
                  onClick={handleNextLevel}
                  className="w-14 h-14 rounded-full bg-emerald-400 hover:bg-emerald-300 active:scale-95 flex items-center justify-center transition-all shadow-[0_0_20px_rgba(16,185,129,0.5)] cursor-pointer"
                >
                  <ChevronRight className="w-8 h-8 text-black stroke-[3]" />
                </button>
              </div>
            </div>
          )}

          {/* PHASER CANVAS COMPONENT - playerY always 50 (fixed center line) */}
          <FiberPhaserCanvas
            playerY={50}
            onChangePlayerY={() => {}} // static
            level={level}
            status={status}
            onSplicingAttempt={handleSplicingAttempt}
            triggerSplicingRef={triggerSplicingRef}
          />
        </div>

        {/* EXECUTE INTERFACE (FUSE BUTTON ONLY, NO SLIDER, NO TEXT) */}
        <div className="flex justify-center items-center py-2">
          <button
            onClick={handleExecuteSplicing}
            disabled={status !== "PLAYING"}
            className={`w-20 h-20 rounded-full group relative flex items-center justify-center transition-all duration-150 border-2 ${
              status !== "PLAYING" 
                ? "bg-slate-800/10 text-slate-600 border-slate-800/20 cursor-not-allowed" 
                : "bg-gradient-to-r from-[#00f2ff] to-cyan-500 hover:from-[#33f5ff] hover:to-cyan-400 active:scale-95 text-black border-[#00f2ff]/40 cursor-pointer shadow-[0_0_25px_rgba(0,242,255,0.35)]"
            }`}
          >
            <Zap className="w-8 h-8 fill-black text-black stroke-[2.5]" />
          </button>
        </div>

        {/* BOTTOM SECTION: CIRCULAR STAGE SELECTOR (数据防线 circular tabs layout) */}
        <div className="flex items-center justify-center gap-2 mt-2 bg-[#0a1a2f]/20 border border-[#00f2ff]/10 max-w-lg mx-auto py-2.5 px-4 rounded-full shadow-[0_0_15px_rgba(0,242,255,0.02)] overflow-x-auto">
          {Array.from({ length: LEVELS.length }, (_, i) => i + 1).map((lvlId) => {
            const isActive = level === lvlId;
            const isCompleted = completedLevels.includes(lvlId);
            return (
              <button
                key={lvlId}
                type="button"
                onClick={() => {
                  synth.playClick();
                  setLevel(lvlId);
                  setSuccessCount(0);
                  setStatus("PLAYING");
                }}
                className={`w-8 h-8 rounded-full font-bold text-xs flex items-center justify-center transition-all duration-200 cursor-pointer border shrink-0 ${
                  isActive
                    ? "bg-[#00f2ff] text-black border-[#00f2ff] shadow-[0_0_15px_rgba(0,242,255,0.5)] scale-110 font-black"
                    : isCompleted
                    ? "bg-[#0a2f1d]/60 text-emerald-400 border-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.3)] hover:bg-[#0a2f1d]/80"
                    : "bg-[#05070a]/60 text-slate-400 border-slate-800 hover:border-[#00f2ff]/50 hover:text-slate-200"
                }`}
              >
                {lvlId}
              </button>
            );
          })}
        </div>
      </main>

      {/* FOOTER GAME BRANDING */}
      <footer className="w-full text-center mt-auto pt-8 pb-4 text-[10px] text-[#00f2ff]/30 font-mono tracking-[0.3em] z-10">
        CABLE SPLICE
      </footer>

      {/* OPERATIONS HELP MANUAL MODAL (CABLE SPLICE MANUAL WITH EN/CN SWITCHER) */}
      {showHelp && (
        <div className="fixed inset-0 bg-black/85 z-50 flex items-center justify-center p-4 backdrop-blur-sm animate-fade-in">
          <div className="bg-[#05070a] border border-[#00f2ff]/20 p-5 rounded-2xl shadow-[0_0_50px_rgba(0,242,255,0.15)] max-w-sm w-full relative font-mono text-xs">
            
            {/* Header with Title and language switcher */}
            <div className="flex items-center justify-between pb-3.5 mb-4 border-b border-[#00f2ff]/10">
              <h2 className="text-base font-bold tracking-wider text-[#00ffcc]">
                {isEnglish ? "CABLE SPLICE GUIDE" : "光缆熔接指南"}
              </h2>
              
              <div className="flex items-center gap-3">
                {/* Language Switcher Badge */}
                <button
                  onClick={() => { synth.playClick(); setIsEnglish(!isEnglish); }}
                  className="px-2 py-0.5 rounded border border-[#00f2ff]/40 text-[#00f2ff] text-[10px] font-bold hover:bg-[#00f2ff]/10 transition-colors uppercase tracking-widest cursor-pointer"
                >
                  {isEnglish ? "中" : "EN"}
                </button>
                
                {/* Close Button */}
                <button
                  onClick={() => { synth.playClick(); setShowHelp(false); }}
                  className="text-slate-400 hover:text-white transition-colors cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Simple dual-language game description */}
            <div className="space-y-4 mb-2 max-h-[360px] overflow-y-auto pr-1 text-left">
              
              <div>
                <span className="text-[#00ffcc] font-bold block mb-1">
                  {isEnglish ? "🛰️ Mission" : "🛰️ 任务目标"}
                </span>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  {isEnglish 
                    ? "Align the oscillating optical laser core precisely with the stationary center receiver." 
                    : "精确对接跳动的光学纤芯与固定的中央接收器，确保数据线路稳定传输。"}
                </p>
              </div>

              <div>
                <span className="text-[#00ffcc] font-bold block mb-1">
                  {isEnglish ? "🔴 Oscillating Fiber" : "🔴 振动光纤"}
                </span>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  {isEnglish 
                    ? "The red fiber core on the right automatically oscillates up and down mimicking frequency cycles." 
                    : "右侧红色的光纤纤芯会以正弦波振荡频率自动在上下区间往返漂移。"}
                </p>
              </div>

              <div>
                <span className="text-[#00ffcc] font-bold block mb-1">
                  {isEnglish ? "🟢 Dynamic Splicing Zone" : "🟢 动态熔接容错"}
                </span>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  {isEnglish 
                    ? "The center highlighted green zone represents the precision tolerance threshold. This area shrinks as the stage level increases, demanding extreme precision." 
                    : "中间半透明的绿色光带即为极精细容错区间。随着关卡升高，该区域将显著缩小，带来极限预判挑战。"}
                </p>
              </div>

              <div>
                <span className="text-[#00ffcc] font-bold block mb-1">
                  {isEnglish ? "⚡ Fuse / Zap" : "⚡ 触发熔接"}
                </span>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  {isEnglish 
                    ? "Tap the big central Zap button when the moving red fiber enters the green splicing zone." 
                    : "当右侧跳动的红色光纤正好进入绿色半透明光圈带内时，按下中央「⚡」按钮进行熔接。"}
                </p>
              </div>

              <div>
                <span className="text-[#00ffcc] font-bold block mb-1">
                  {isEnglish ? "🏆 Clearance" : "🏆 关卡进度"}
                </span>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  {isEnglish 
                    ? "Successfully complete 3 continuous alignments to secure the sector and unlock the next stage!" 
                    : "累计成功熔接准星 3 次，代表该海域网络防御线架设完成，即可进入下一关！"}
                </p>
              </div>

            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CyberConsole;
