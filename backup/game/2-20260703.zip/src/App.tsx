/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import CyberConsole from "./components/CyberConsole";

export default function App() {
  return (
    <div className="w-full min-h-screen bg-[#040812]">
      <CyberConsole />
    </div>
  );
}
