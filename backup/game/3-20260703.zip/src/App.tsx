/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ShieldAlert, 
  HelpCircle, 
  Sparkles, 
  Clock, 
  RotateCcw, 
  Play, 
  Pause, 
  Award, 
  ArrowRight,
  RefreshCw,
  TrendingUp,
  Cpu,
  MonitorCheck,
  CornerDownRight,
  Info,
  Volume2,
  VolumeX,
  X
} from 'lucide-react';

import { Mission, GameStats, Difficulty } from './types';
import VigenerePhaserCanvas from './components/VigenerePhaserCanvas';
import { 
  playTickSound, 
  playSelectSound, 
  playSuccessSound, 
  playFailureSound, 
  playFanfareSound 
} from './utils/audio';

/// Educational Missions containing Vigenere tasks
const LEVEL_PROVERBS: Record<number, string[]> = {
  1: [
    "No pains no gains.",
    "Time is money.",
    "Seeing is believing."
  ],
  2: [
    "Easy come easy go.",
    "Look before you leap.",
    "Love me love my dog."
  ],
  3: [
    "Practice makes perfect.",
    "Walls have ears.",
    "Never too old to learn."
  ],
  4: [
    "A friend in need is a friend indeed.",
    "Birds of a feather flock together.",
    "Failure is the mother of success."
  ],
  5: [
    "Actions speak louder than words.",
    "Where there is a will there is a way.",
    "A miss is as good as a mile."
  ],
  6: [
    "Rome was not built in a day.",
    "Every cloud has a silver lining.",
    "Don't judge a book by its cover."
  ],
  7: [
    "The early bird catches the worm.",
    "God helps those who help themselves.",
    "All work and no play makes Jack a dull boy."
  ],
  8: [
    "When in Rome do as the Romans do.",
    "Don't count your chickens before they hatch.",
    "Blood is thicker than water."
  ]
};

const LEVEL_KEYWORDS: Record<number, string[]> = {
  1: ["F", "E", "T", "B", "H", "K", "M", "P", "R", "W"],
  2: ["GO", "IT", "UP", "BY", "ON", "HE", "WE", "DO", "AM", "SO"],
  3: ["KEY", "NET", "WEB", "FLY", "RUN", "SKY", "SEA", "SUN", "MAP", "CPU"],
  4: ["ZEAL", "CYAN", "WAVE", "WIND", "GOLD", "BLUE", "FIRE", "ROCK", "MIND", "CODE"],
  5: ["LEMON", "GHOST", "LASER", "LIGHT", "STORM", "CLOUD", "EARTH", "SPACE", "PLANET", "CLOCK"],
  6: ["SHADOW", "MATRIX", "PHASER", "VECTOR", "SIGNAL", "TARGET", "PORTAL", "SOCKET", "ENGINE", "SHIELD"],
  7: ["HACKERS", "PHANTOM", "PROTECT", "DEFENSE", "RESTORE", "MONITOR", "ROUTERS", "CRYPTOS", "CONSOLE", "BARRIER"],
  8: ["SECURITY", "FIREWALL", "TERMINAL", "DECRYPTS", "DATABASE", "OVERLOAD", "WARPCORE", "PROTOCOL", "QUANTUMS", "RESONANT"]
};

const ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';

// Encrypt Vigenere function
const encryptVigenere = (plain: string, keyWord: string): string => {
  if (keyWord.length === 0) return plain;
  const upperPlain = plain.toUpperCase();
  let cipher = '';
  let keyIndexCounter = 0;
  for (let i = 0; i < upperPlain.length; i++) {
    const char = upperPlain[i];
    const charIndex = ALPHABET.indexOf(char);
    if (charIndex === -1) {
      cipher += char;
      continue;
    }
    const keyChar = keyWord[keyIndexCounter % keyWord.length];
    const keyIndex = ALPHABET.indexOf(keyChar.toUpperCase());
    const encryptedIndex = (charIndex + keyIndex) % 26;
    cipher += ALPHABET[encryptedIndex];
    keyIndexCounter++;
  }
  return cipher;
};

// Generate randomized level mission data
const generateLevelData = (levelNum: number): Mission => {
  const proverbs = LEVEL_PROVERBS[levelNum] || ["No pains no gains."];
  const keywords = LEVEL_KEYWORDS[levelNum] || ["F"];
  
  const plaintext = proverbs[Math.floor(Math.random() * proverbs.length)];
  const correctKeyword = keywords[Math.floor(Math.random() * keywords.length)];
  const defaultKeyword = 'A'.repeat(levelNum);
  const ciphertext = encryptVigenere(plaintext, correctKeyword);
  
  const difficulty = levelNum <= 3 ? 'Easy' : levelNum <= 6 ? 'Normal' : 'Hard';
  const id = `EP02-0${levelNum}`;
  
  const names = [
    '第一关：单字移位',
    '第二关：双相代换',
    '第三关：三阶矩阵',
    '第四关：四重代换',
    '第五关：五阶相位',
    '第六关：六维对流',
    '第七关：七星共振',
    '第八关：终极密门'
  ];
  const name = names[levelNum - 1] || `第${levelNum}关`;
  
  const clues = [
    `密钥周期长度锁定为 ${levelNum} 字符组。`,
    `当我们切换到 ${levelNum} 周期时，IC 指数极速向 0.066 理论高点靠拢。`,
    `安全钥灵提示：首位字符在 '${correctKeyword[0]}' 频率相位上。`,
    `成功逆转还原：${plaintext.toUpperCase()}！`
  ];

  return {
    id,
    name,
    difficulty,
    ciphertext,
    plaintext: plaintext.toUpperCase(),
    correctKeyword,
    defaultKeyword,
    recommendedLength: levelNum,
    description: `系统检测到一段 ${levelNum} 位长的移位信息。请利用密码盘找出明文英文谚语。`,
    clues,
    kasiskiHint: `周期长度为 ${levelNum}，进行交替多表对齐映射。`,
    icDescription: `IC: 0.06${5 + (levelNum % 3)}`,
    expectedIC: 0.065 + (levelNum % 3) * 0.001
  };
};

export default function App() {
  // Initialize 8 levels of randomized missions
  const [missions, setMissions] = useState<Mission[]>(() => 
    [1, 2, 3, 4, 5, 6, 7, 8].map(levelNum => generateLevelData(levelNum))
  );

  const [currentMissionIndex, setCurrentMissionIndex] = useState(0);
  const activeMission = missions[currentMissionIndex];

  const [keyword, setKeyword] = useState(activeMission.defaultKeyword);
  const [activeKeyIndex, setActiveKeyIndex] = useState(0); // Which character index we are active (0 - kwLength-1)
  const [unlockedClues, setUnlockedClues] = useState<boolean[]>([false, false, false, false]);
  
  // Game Stats
  const [score, setScore] = useState(2500);
  const [isMuted, setIsMuted] = useState(false);
  const [showEduPopup, setShowEduPopup] = useState(false);
  const [eduLang, setEduLang] = useState<'zh' | 'en'>('zh');
  
  // Interface animation effects
  const [glitchActive, setGlitchActive] = useState(false);
  const [warpTriggered, setWarpTriggered] = useState(false);

  const [liveTimestamp, setLiveTimestamp] = useState('2026-06-17 07:26:02');

  // Sync state when mission changes
  useEffect(() => {
    setKeyword(activeMission.defaultKeyword);
    setActiveKeyIndex(0);
    setUnlockedClues([false, false, false, false]);
  }, [currentMissionIndex]);

  // Clock Timestamp Updater
  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date();
      const formatStr = now.toISOString().replace('T', ' ').slice(0, 19);
      setLiveTimestamp(formatStr);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Calculate matching accuracy for wave spectrum
  let correctLettersCount = 0;
  const wordLen = Math.min(keyword.length, activeMission.correctKeyword.length);
  for (let i = 0; i < wordLen; i++) {
    if (keyword[i]?.toUpperCase() === activeMission.correctKeyword[i]?.toUpperCase()) {
      correctLettersCount++;
    }
  }
  const keywordAccuracy = wordLen > 0 ? (correctLettersCount / wordLen) : 0;

  // Decryption core formula
  const decryptVigenere = (cipher: string, keyWord: string): string => {
    if (keyWord.length === 0) return cipher;
    let plain = '';
    let keyIndexCounter = 0;
    for (let i = 0; i < cipher.length; i++) {
      const char = cipher[i];
      const charIndex = ALPHABET.indexOf(char);
      if (charIndex === -1) {
        plain += char;
        continue;
      }
      const keyChar = keyWord[keyIndexCounter % keyWord.length];
      const keyIndex = ALPHABET.indexOf(keyChar?.toUpperCase() || 'A');
      // Plain = (Cipher - Key + 26) % 26
      const decryptedIndex = (charIndex - keyIndex + 26) % 26;
      plain += ALPHABET[decryptedIndex];
      keyIndexCounter++;
    }
    return plain;
  };

  const userPlaintext = decryptVigenere(activeMission.ciphertext, keyword);

  // Precompute key index mapping for the current ciphertext to avoid advancing key index on punctuation/spaces
  const keyIndexMapping = React.useMemo(() => {
    if (keyword.length === 0) return Array(activeMission.ciphertext.length).fill(-1);
    const mapping: number[] = [];
    let keyIndexCounter = 0;
    for (let i = 0; i < activeMission.ciphertext.length; i++) {
      const char = activeMission.ciphertext[i];
      const charIndex = ALPHABET.indexOf(char);
      if (charIndex === -1) {
        mapping.push(-1);
      } else {
        mapping.push(keyIndexCounter % keyword.length);
        keyIndexCounter++;
      }
    }
    return mapping;
  }, [activeMission.ciphertext, keyword.length]);

  // Validate unlocked clues in Realtime
  useEffect(() => {
    const newUnlocked = [...unlockedClues];
    const lenCorrect = keyword.length === activeMission.correctKeyword.length;

    // Clue 1: Correct Length
    if (lenCorrect) {
      newUnlocked[0] = true;
    }

    // Clue 2: Length is correct and they have made changes to the default 'A' state of key
    if (lenCorrect && keyword !== activeMission.defaultKeyword) {
      newUnlocked[1] = true;
    }

    // Clue 3: At least 3 letters correspond with corrected key
    let matchingLetters = 0;
    const minLen = Math.min(keyword.length, activeMission.correctKeyword.length);
    for (let i = 0; i < minLen; i++) {
      if (keyword[i]?.toUpperCase() === activeMission.correctKeyword[i]?.toUpperCase()) {
        matchingLetters++;
      }
    }
    if (lenCorrect && matchingLetters >= 3) {
      newUnlocked[2] = true;
    }

    // Clue 4: Keyword is completely correct!
    if (keyword.toUpperCase() === activeMission.correctKeyword.toUpperCase()) {
      newUnlocked[3] = true;
    }

    // Compare with previous state to trigger sound or notifications
    let changed = false;
    for (let idx = 0; idx < 4; idx++) {
      if (newUnlocked[idx] !== unlockedClues[idx]) {
        changed = true;
      }
    }

    if (changed) {
      setUnlockedClues(newUnlocked);
      if (newUnlocked.filter(x => x).length > unlockedClues.filter(x => x).length) {
        playSuccessSound(isMuted);
        // Deduct military resistance score
        setScore(prev => prev + 150);
      }
    }
  }, [keyword, activeMission, unlockedClues, isMuted]);

  // Keyboard word length selection (1 - 8)
  const handleLengthChange = (newLen: number) => {
    if (newLen < 1 || newLen > 8) return;
    playSelectSound(isMuted);
    let newKw = '';
    for (let i = 0; i < newLen; i++) {
      // Retain existing characters if possible, else pad with 'A'
      newKw += keyword[i] || 'A';
    }
    setKeyword(newKw);
    setActiveKeyIndex(0);
  };

  // Increment or Decrement shift values based on keyboard click adjustments on active letter
  const shiftActiveKeyChar = (direction: number) => {
    if (keyword.length === 0) return;
    playTickSound(isMuted);
    const activeChar = keyword[activeKeyIndex];
    if (!activeChar) return;

    let charIdx = ALPHABET.indexOf(activeChar.toUpperCase());
    if (charIdx === -1) charIdx = 0;

    const nextIdx = (charIdx + direction + 26) % 26;
    const kwArray = keyword.split('');
    kwArray[activeKeyIndex] = ALPHABET[nextIdx];
    
    setKeyword(kwArray.join(''));
  };

  // Auto-alignment Cheat
  const triggerAutoAlign = () => {
    playSuccessSound(isMuted);
    setKeyword(activeMission.correctKeyword);
  };

  return (
    <div className="min-h-screen bg-[#070913] text-slate-100 flex flex-col font-sans relative overflow-hidden select-none">
      
      {/* Glitch & Holographic screen line overlay */}
      <div className="absolute inset-0 pointer-events-none bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] bg-[length:100%_4px,3px_100%] z-50 opacity-20" />
      
      {/* Temporal Warp visual ripple splash */}
      {warpTriggered && (
        <div className="absolute inset-0 bg-purple-500/10 pointer-events-none z-40 animate-pulse border-4 border-purple-500" />
      )}

      {/* Screen Glitch on failure submission */}
      {glitchActive && (
        <div className="absolute inset-0 bg-red-400/10 pointer-events-none z-40 animate-ping border-4 border-rose-500" />
      )}

      {/* 1. TOP STATUS BAR (Hacker HUD Top Bar) */}
      <header className="w-full h-14 bg-slate-950 border-b border-purple-500/20 px-4 flex items-center justify-between z-10 font-mono text-xs">
        {/* Left: 3 control buttons */}
        <div className="w-1/3 flex items-center space-x-2.5">
          <button
            onClick={triggerAutoAlign}
            className="h-9 w-9 bg-slate-950/60 hover:bg-slate-900 border border-cyan-500/40 hover:border-cyan-400 text-cyan-400 hover:text-cyan-300 rounded-xl transition-all cursor-pointer flex items-center justify-center shadow-[0_0_8px_rgba(6,182,212,0.15)] hover:shadow-[0_0_12px_rgba(6,182,212,0.3)]"
          >
            <span className="text-base font-bold text-cyan-400">⦾</span>
          </button>

          <button
            onClick={() => {
              playSelectSound(isMuted);
              setKeyword(activeMission.defaultKeyword);
              setActiveKeyIndex(0);
            }}
            className="h-9 w-9 bg-slate-950/60 hover:bg-slate-900 border border-emerald-500/40 hover:border-emerald-400 text-emerald-400 hover:text-emerald-300 rounded-xl transition-all cursor-pointer flex items-center justify-center shadow-[0_0_8px_rgba(16,185,129,0.15)] hover:shadow-[0_0_12px_rgba(16,185,129,0.3)]"
          >
            <RotateCcw className="h-4.5 w-4.5" />
          </button>

          <button
            onClick={() => {
              playSelectSound(isMuted);
              setMissions(prevMissions => {
                const nextMissions = [...prevMissions];
                nextMissions[currentMissionIndex] = generateLevelData(currentMissionIndex + 1);
                return nextMissions;
              });
            }}
            className="h-9 w-9 bg-slate-950/60 hover:bg-slate-900 border border-emerald-500/40 hover:border-emerald-400 text-emerald-400 hover:text-emerald-300 rounded-xl transition-all cursor-pointer flex items-center justify-center shadow-[0_0_8px_rgba(16,185,129,0.15)] hover:shadow-[0_0_12px_rgba(16,185,129,0.3)]"
          >
            <RefreshCw className="h-4 w-4 text-emerald-400" />
          </button>
        </div>

        {/* Center: Stage Level Indicator (e.g. 1/8) */}
        <div className="w-1/3 flex items-center justify-center">
          <div className="font-mono text-cyan-400 font-extrabold text-base sm:text-lg tracking-[0.15em] bg-cyan-950/25 border border-cyan-500/35 px-4 py-1.5 rounded-lg shadow-[0_0_12px_rgba(6,182,212,0.2)]">
            {currentMissionIndex + 1}/8
          </div>
        </div>

        {/* Right Info Details & Control Buttons */}
        <div className="w-1/3 flex items-center justify-end space-x-2.5">
          {/* Sound Control Button */}
          <button
            onClick={() => {
              playSelectSound(isMuted);
              setIsMuted(!isMuted);
            }}
            className="h-9 w-9 bg-slate-950/60 hover:bg-slate-900 border border-emerald-500/40 hover:border-emerald-400 text-emerald-400 hover:text-emerald-300 rounded-xl transition-all cursor-pointer flex items-center justify-center shadow-[0_0_8px_rgba(16,185,129,0.15)] hover:shadow-[0_0_12px_rgba(16,185,129,0.3)]"
          >
            {isMuted ? (
              <VolumeX className="h-4.5 w-4.5 text-rose-400 animate-pulse" />
            ) : (
              <Volume2 className="h-4.5 w-4.5" />
            )}
          </button>

          {/* Help/Guide Button */}
          <button
            onClick={() => {
              playSelectSound(isMuted);
              setShowEduPopup(true);
            }}
            className="h-9 w-9 bg-slate-950/60 hover:bg-slate-900 border border-emerald-500/40 hover:border-emerald-400 text-emerald-400 hover:text-emerald-300 rounded-xl transition-all cursor-pointer flex items-center justify-center shadow-[0_0_8px_rgba(16,185,129,0.15)] hover:shadow-[0_0_12px_rgba(16,185,129,0.3)]"
          >
            <HelpCircle className="h-4.5 w-4.5" />
          </button>
        </div>
      </header>

      {/* 2. TWO-COLUMN ADAPTIVE HUD CONTAINER */}
      <main className="flex-1 pt-1 px-3.5 pb-8 max-w-2xl md:max-w-5xl lg:max-w-6xl mx-auto w-full flex flex-col md:flex-row gap-4 overflow-y-auto overflow-x-hidden items-start">
        
        {/* LEFT COLUMN: INTERACTIVE VIGENERE WHEEL */}
        <div className="w-full md:w-[420px] md:sticky md:top-1 flex flex-col gap-3 shrink-0">
          <div className="bg-slate-950/40 rounded-xl border border-purple-500/15 p-1 sm:p-2 flex flex-col items-center justify-center">
            <VigenerePhaserCanvas
              keyword={keyword}
              activeKeyIndex={activeKeyIndex}
              ciphertext={activeMission.ciphertext}
              plaintext={activeMission.plaintext}
              correctKeyword={activeMission.correctKeyword}
              onKeywordChange={(newKw) => setKeyword(newKw)}
              onActiveKeyIndexChange={(idx) => setActiveKeyIndex(idx)}
              isMuted={isMuted}
            />
          </div>
        </div>

        {/* RIGHT COLUMN: FEEDBACK & CONTROLS */}
        <div className="w-full flex-1 flex flex-col gap-3.5">
          {/* A. DECRYPTION FEEDBACK CONSOLE (密文与解密明文反馈区) */}
          <div className="bg-slate-950/40 rounded-xl border border-cyan-500/15 p-3.5 flex flex-col gap-3">
            
            {/* Cipher Box */}
            <div className="relative p-3 rounded-lg bg-cyan-950/15 border border-cyan-500/25 shadow-[inset_0_0_15px_rgba(6,182,212,0.05)] overflow-hidden">
              <div className="pt-2 text-center font-mono text-sm sm:text-base tracking-[0.2em] font-extrabold text-cyan-400 drop-shadow-[0_0_6px_rgba(6,182,212,0.7)]">
                {activeMission.ciphertext.split('').map((char, idx) => {
                  const isCurrentlyActiveIdx = keyIndexMapping[idx] === activeKeyIndex;
                  return (
                    <span
                      key={idx}
                      className={`inline-block transition-all ${
                        isCurrentlyActiveIdx
                          ? 'text-pink-400 scale-110 drop-shadow-[0_0_8px_rgba(236,72,153,1)]'
                          : ''
                      }`}
                    >
                      {char}
                    </span>
                  );
                })}
              </div>
            </div>

            {/* Decrypted Plain Box */}
            <div className="relative p-3 rounded-lg bg-pink-950/15 border border-pink-500/25 shadow-[inset_0_0_15px_rgba(236,72,153,0.05)] overflow-hidden">
              <div className="pt-2 text-center font-mono text-sm sm:text-base tracking-[0.2em] font-extrabold text-pink-400 drop-shadow-[0_0_6px_rgba(236,72,153,0.7)] flex justify-center flex-wrap">
                {userPlaintext.split('').map((char, idx) => {
                  const matchesCorrect = char === activeMission.plaintext[idx];
                  const isCurrentlyActiveIdx = keyIndexMapping[idx] === activeKeyIndex;

                  return (
                    <span
                      key={idx}
                      className={`inline-block transition-all ${
                        matchesCorrect 
                          ? 'text-emerald-400 drop-shadow-[0_0_6px_rgba(16,185,129,0.8)]' 
                          : 'text-rose-400 drop-shadow-[0_0_6px_rgba(244,63,94,0.8)]'
                      } ${isCurrentlyActiveIdx ? 'underline decoration-cyan-400 decoration-2 underline-offset-4' : ''}`}
                    >
                      {char === ' ' ? '\u00A0' : char}
                    </span>
                  );
                })}
              </div>
            </div>

          </div>

          {/* C. MANUAL CONTROLLERS (输入、步进和变频设定) */}
          <div className="bg-slate-950/40 rounded-xl border border-pink-500/15 p-3.5 flex flex-col gap-3">
            
            {/* Active Character Stepper Index Navigation */}
            <div className="flex flex-col gap-1.5">
              <div className="flex items-center space-x-1.5 justify-center">
                {/* Left Shifter Button */}
                <button
                  onClick={() => shiftActiveKeyChar(-1)}
                  className="py-1.5 px-2.5 bg-slate-900 border border-slate-700 hover:border-pink-500/40 rounded text-xs font-mono font-bold flex items-center justify-center gap-1 transition-all cursor-pointer text-slate-300"
                >
                  <span>-1</span>
                </button>

                {keyword.split('').map((char, index) => {
                  const isActive = index === activeKeyIndex;
                  const isCharMatch = char === activeMission.correctKeyword[index];
                  return (
                    <button
                      key={index}
                      onClick={() => {
                        playTickSound(isMuted);
                        setActiveKeyIndex(index);
                      }}
                      className={`h-8 w-8 rounded font-mono font-bold text-xs flex items-center justify-center border transition-all ${
                        isActive
                          ? 'bg-pink-500 border-pink-400 text-white shadow-[0_0_8px_#ec4899]'
                          : isCharMatch
                          ? 'bg-emerald-950/30 border-emerald-500/30 text-emerald-400'
                          : 'bg-slate-900 border-slate-700 text-slate-400 hover:border-purple-500/40'
                      }`}
                    >
                      {char}
                    </button>
                  );
                })}

                {/* Right Shifter Button */}
                <button
                  onClick={() => shiftActiveKeyChar(1)}
                  className="py-1.5 px-2.5 bg-slate-900 border border-slate-700 hover:border-pink-500/40 rounded text-xs font-mono font-bold flex items-center justify-center gap-1 transition-all cursor-pointer text-slate-300"
                >
                  <span>+1</span>
                </button>
              </div>
            </div>



          </div>

          {/* D. LEVEL SELECTOR (2行4个一组) */}
          <div className="bg-slate-950/40 rounded-xl border border-purple-500/15 p-3.5 flex flex-col gap-2">
            <div className="grid grid-cols-4 gap-2">
              {[1, 2, 3, 4, 5, 6, 7, 8].map((levelNum) => {
                const isCurrentLevel = (currentMissionIndex + 1) === levelNum;
                return (
                  <button
                    key={levelNum}
                    onClick={() => {
                      playSelectSound(isMuted);
                      setCurrentMissionIndex(levelNum - 1);
                    }}
                    className={`py-2 rounded flex flex-col items-center justify-center transition-all cursor-pointer ${
                      isCurrentLevel
                        ? 'bg-pink-500/10 border-2 border-pink-500 text-pink-400 shadow-[0_0_8px_rgba(236,72,153,0.2)]'
                        : 'bg-slate-900 border border-slate-800 text-slate-400 hover:bg-slate-900/60 hover:border-slate-700'
                    }`}
                  >
                    <span className="text-xs font-mono font-extrabold">{levelNum}</span>
                    {/* Active Level LED Dot indicator */}
                    <span
                      className={`h-1.5 w-1.5 rounded-full mt-1 ${
                        isCurrentLevel
                          ? 'bg-pink-400 shadow-[0_0_6px_#ec4899]'
                          : 'bg-slate-700'
                      }`}
                    />
                  </button>
                );
              })}
            </div>
          </div>

        </div>

      </main>

      {/* 3. CONSOLE FOOTER */}
      <footer className="w-full h-8 bg-slate-950 border-t border-purple-500/10 px-4 flex items-center justify-between z-10 font-mono text-[10px] text-slate-500">
        <div>
          MIDKEY | Vigenère Cipher
        </div>
        <div />
      </footer>

      {/* 4. EDUCATIONAL INSTRUCTIONAL POPUP */}
      <AnimatePresence>
        {showEduPopup && (
          <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-[#0b0f1d] border border-cyan-500/30 rounded-xl p-5 max-w-lg w-full shadow-[0_0_30px_rgba(6,182,212,0.15)] relative overflow-hidden"
            >
              {/* Corner tech overlays */}
              <div className="absolute top-0 left-0 w-8 h-[1px] bg-cyan-400" />
              <div className="absolute top-0 left-0 w-[1px] h-8 bg-cyan-400" />

              <div className="flex items-center justify-between pb-3.5 border-b border-cyan-500/10 mb-4">
                <span className="text-base font-display font-bold text-cyan-400 tracking-wider flex items-center gap-2">
                  {eduLang === 'zh' ? '维吉尼亚密码破译指南' : 'VIGENÈRE DECRYPTOR GUIDE'}
                </span>
                <div className="flex items-center space-x-3">
                  <button
                    onClick={() => {
                      playTickSound(isMuted);
                      setEduLang(eduLang === 'zh' ? 'en' : 'zh');
                    }}
                    className="px-2.5 py-1 rounded border border-cyan-500/40 text-cyan-400 hover:text-cyan-300 hover:border-cyan-300 bg-cyan-950/20 text-xs font-mono font-bold transition-all cursor-pointer shadow-[0_0_6px_rgba(6,182,212,0.15)]"
                  >
                    {eduLang === 'zh' ? 'EN' : '中'}
                  </button>
                  <button
                    onClick={() => {
                      playTickSound(isMuted);
                      setShowEduPopup(false);
                    }}
                    className="text-slate-400 hover:text-white transition-colors cursor-pointer p-0.5"
                  >
                    <X className="h-5 w-5" />
                  </button>
                </div>
              </div>

              <div className="text-xs font-sans text-slate-300 space-y-4 leading-relaxed max-h-[350px] overflow-y-auto pr-2">
                {eduLang === 'zh' ? (
                  <>
                    <div>
                      <h4 className="text-cyan-400 font-bold font-display uppercase tracking-wide mb-1">
                        1. 什么是维吉尼亚密码？
                      </h4>
                      <p>
                        维吉尼亚密码是一种经典的<strong>多表替换密码</strong>。它会循环使用一个“密钥”中的不同偏移值，在不同位置的明文字母上进行凯撒平移加密！
                      </p>
                    </div>

                    <div>
                      <h4 className="text-pink-400 font-bold font-display uppercase tracking-wide mb-1">
                        2. 密码盘对齐法则
                      </h4>
                      <ul className="list-disc list-inside space-y-1.5 pl-1">
                        <li>
                          <strong className="text-cyan-400">最外圈（青蓝色） = 明文：</strong>
                          它是标准的 A-Z 字母表，12 点钟方向永远固定是 A，保持静止不动。
                        </li>
                        <li>
                          <strong className="text-pink-400">内圈（粉紫色） = 密文：</strong>
                          它是可旋转的。当选中位的密钥是 <strong className="text-yellow-400 font-mono">B</strong>（即偏移量为 1）时，内圈整体会<strong>逆时针旋转一格</strong>，使内圈的 <strong className="text-pink-400 font-mono">B</strong> 完美对准外圈的 <strong className="text-cyan-400 font-mono">A</strong>（12 点钟方向）。
                        </li>
                        <li>
                          因此对齐之后，12点钟方向对应的字母即：明文 A 对应 密文 B，明文 = (密文 - 密钥偏移 + 26) % 26。
                        </li>
                      </ul>
                    </div>

                    <div>
                      <h4 className="text-cyan-400 font-bold font-display uppercase tracking-wide mb-1">
                        3. 界面按钮代表含义
                      </h4>
                      <div className="grid grid-cols-1 gap-2 bg-slate-950/40 border border-slate-800 p-2.5 rounded text-[11px] leading-snug">
                        <div>
                          <strong className="text-cyan-300 font-mono">⦾ (自动配准)</strong>：一键自动破解，瞬间解开并配准当前关卡的所有密钥。
                        </div>
                        <div>
                          <strong className="text-emerald-400 font-mono">↺ (重置破译)</strong>：将当前关卡的密钥字符全部恢复为初始状态（全 A）。
                        </div>
                        <div>
                          <strong className="text-purple-400 font-mono">⇄ (随机换词)</strong>：在当前长度下，重新生成一个全新的保密词汇进行破译挑战。
                        </div>
                        <div>
                          <strong className="text-slate-300 font-mono">← -1 / +1 →</strong>：对当前选中的单个密钥槽位进行往前或往后一格的微调。
                        </div>
                        <div>
                          <strong className="text-pink-400 font-mono">顶部字母卡片 (A, B...)</strong>：密钥位，点击可以切换正在拨动调整的密钥字符位置（卡片会产生发光外框）。
                        </div>
                        <div>
                          <strong className="text-purple-300 font-mono">1 - 8 关卡选择器</strong>：自由在 2x4 格子中选择挑战不同代换模长（密钥长度从 1 位到 8 位）的破译关卡。
                        </div>
                      </div>
                    </div>
                  </>
                ) : (
                  <>
                    <div>
                      <h4 className="text-cyan-400 font-bold font-display uppercase tracking-wide mb-1">
                        1. What is the Vigenère Cipher?
                      </h4>
                      <p>
                        The Vigenère Cipher is a classic <strong>polyalphabetic substitution cipher</strong>. It encrypts plaintext by applying Caesar shift offsets derived from a repeating keyword cyclically.
                      </p>
                    </div>

                    <div>
                      <h4 className="text-pink-400 font-bold font-display uppercase tracking-wide mb-1">
                        2. Decryption Wheel Realignment Rule
                      </h4>
                      <ul className="list-disc list-inside space-y-1.5 pl-1">
                        <li>
                          <strong className="text-cyan-400">Outer Ring (Cyan-Blue) = Plaintext:</strong>
                          Standard A-Z alphabet. The 12 o'clock position is always locked at **A** and stays completely static.
                        </li>
                        <li>
                          <strong className="text-pink-400">Inner Ring (Pink-Purple) = Ciphertext:</strong>
                          Rotating dial representing the shifted alphabet. When the key character is <strong className="text-yellow-400 font-mono">B</strong> (shift offset = 1), the inner ring rotates <strong>counter-clockwise by 1 slot</strong>, aligning the inner letter <strong className="text-pink-400 font-mono">B</strong> perfectly with the outer letter <strong className="text-cyan-400 font-mono">A</strong> at the 12 o'clock position.
                        </li>
                        <li>
                          Formula: Plaintext = (Ciphertext - Key Shift + 26) % 26.
                        </li>
                      </ul>
                    </div>

                    <div>
                      <h4 className="text-cyan-400 font-bold font-display uppercase tracking-wide mb-1">
                        3. Interactive Controls & Buttons
                      </h4>
                      <div className="grid grid-cols-1 gap-2 bg-slate-950/40 border border-slate-800 p-2.5 rounded text-[11px] leading-snug">
                        <div>
                          <strong className="text-cyan-300 font-mono">⦾ (Auto-Align)</strong>: Auto solve. Decrypts and perfectly tunes all key slots for the active mission instantly.
                        </div>
                        <div>
                          <strong className="text-emerald-400 font-mono">↺ (Reset)</strong>: Resets all active key characters of the current stage back to initial state (all A's).
                        </div>
                        <div>
                          <strong className="text-purple-400 font-mono">⇄ (Randomize)</strong>: Generates a completely fresh target word and ciphertext for the current level.
                        </div>
                        <div>
                          <strong className="text-slate-300 font-mono">← -1 / +1 →</strong>: Shifts the currently active key character backward or forward by 1 step.
                        </div>
                        <div>
                          <strong className="text-pink-400 font-mono">Top Letter Cards (A, B...)</strong>: Displays the current keyword. Click on any letter card to change which index you are tuning (active card receives glowing border).
                        </div>
                        <div>
                          <strong className="text-purple-300 font-mono">1 - 8 Level Grid</strong>: Instantly jump between levels of varying lengths (from 1-letter up to 8-letter keywords).
                        </div>
                      </div>
                    </div>
                  </>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>



    </div>
  );
}
