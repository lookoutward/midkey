/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Volume2, VolumeX, ShieldAlert, BookOpen, ChevronRight, ChevronLeft, HelpCircle } from 'lucide-react';
import { ChatMessage, Difficulty } from '../types';

interface KeySpiritProps {
  unlockedClues: boolean[]; // size 4
  difficulty: Difficulty;
  keyword: string;
  correctKeyword: string;
  isCompleted: boolean;
  onCheat: () => void;
  onSubmit: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
}

export default function KeySpirit({
  unlockedClues,
  difficulty,
  keyword,
  correctKeyword,
  isCompleted,
  onCheat,
  onSubmit,
  isMuted,
  onToggleMute,
}: KeySpiritProps) {
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [activeDialogIndex, setActiveDialogIndex] = useState(0);

  // Scripted dialog lines based on current unlock progress & general instructions
  const dialogScript = [
    {
      text: "你好，守望者！我是时空解密核心——钥灵。检测到敌方的多频段量子加密信号，经过声呐波纹扫描，可以确认这是‘维吉尼亚密码’！",
    },
    {
      text: "维吉尼亚密文相比之前的单表凯撒更为棘手。它使用重复关键词进行多表交替替换。也就是说，每个位置对应的移位密码不尽相同！我们需要找到那个循环着的‘密钥（Keyword）’！",
    },
    {
      text: "要破译它，首要突破口是‘密钥长度’。观察左侧密文分析，你会发现重复序列 VEF 多次出现。Kasiski 测试暗示它们的公约间隔是 5 —— 极有可能密钥是一个 5 位的暗号！",
    },
    {
      text: "当你选择长度为 5 时，左侧的重合指数 (Coincidence Index) 将随着你调整偏移动作发生抖动。如果你的某个位置字符调对了，那个信道的数据会与常态英文正比，解密词板将亮起粉红霓虹光环！",
    },
    {
      text: "提示：针对当前的拦截段，试试使用密钥字母 'L'、'E'、'M'、'O'、'N'。通过下方拨盘按键逐位转动齿轮，让所有拦截信号彻底解除物理反转锁屏吧！战术连接已全域开启，等待你的提交！"
    }
  ];

  const handleNextDialog = () => {
    if (activeDialogIndex < dialogScript.length - 1) {
      setActiveDialogIndex(prev => prev + 1);
    } else {
      setActiveDialogIndex(0); // Loop back
    }
  };

  const handlePrevDialog = () => {
    if (activeDialogIndex > 0) {
      setActiveDialogIndex(prev => prev - 1);
    }
  };

  // Build educational progress database
  const clueItems = [
    {
      id: 0,
      title: "Kasiski 探测",
      desc: "检测到周期重复暗标 'VEF'，算得公约长为 5。",
      unlocked: unlockedClues[0]
    },
    {
      id: 1,
      title: "多频 IC 指数",
      desc: "密钥长度 5 下重合指数回归 0.067 强标。",
      unlocked: unlockedClues[1]
    },
    {
      id: 2,
      title: "自适应相位校准",
      desc: "第 1, 2, 3 位解密相位锁定，字符流频率配准。",
      unlocked: unlockedClues[2]
    },
    {
      id: 3,
      title: "全集密钥归位",
      desc: "与标准的敌后军事情报明文完全吻合。",
      unlocked: unlockedClues[3]
    }
  ];

  const unlockedCount = clueItems.filter(c => c.unlocked).length;

  return (
    <div className="flex flex-col h-full bg-slate-950/60 rounded-xl border border-purple-500/20 shadow-[0_0_20px_rgba(168,85,247,0.05)] p-4 overflow-y-auto">
      {/* Header toolbar */}
      <div className="flex items-center justify-between mb-4 pb-2 border-b border-purple-500/10">
        <div className="flex items-center space-x-2">
          <BookOpen className="h-4. w-4 text-purple-400" />
          <span className="text-xs font-display font-semibold text-purple-300 tracking-wider">
            钥灵 战术对话链路 (CHAT)
          </span>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={onToggleMute}
            className="p-1 rounded bg-purple-950/20 border border-purple-500/20 text-purple-400 hover:text-purple-300 hover:bg-purple-950/40 transition-colors"
            title={isMuted ? "开启声音" : "静音"}
          >
            {isMuted ? <VolumeX className="h-3 w-3" /> : <Volume2 className="h-3 w-3" />}
          </button>
          <span className="text-[9px] font-mono bg-purple-500/10 text-purple-400 px-1.5 py-0.5 rounded border border-purple-500/20">
            STABLE_LINK
          </span>
        </div>
      </div>

      {/* Pulsating Hologram AI Companion */}
      <div className="flex flex-col items-center justify-center my-1 py-4 relative">
        <div className="relative w-32 h-32 flex items-center justify-center">
          {/* Outer revolving holographic circles */}
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
            className="absolute inset-0 rounded-full border-2 border-dashed border-cyan-500/30 w-full h-full"
          />
          <motion.div
            animate={{ rotate: -360 }}
            transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
            className="absolute inset-[8px] rounded-full border border-purple-500/20 border-t-purple-500 w-[112px] h-[112px]"
          />
          <motion.div
            animate={{ rotate: 180 }}
            transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
            className="absolute inset-[16px] rounded-full border border-dashed border-pink-500/30 w-[96px] h-[96px]"
          />

          {/* Deep Core */}
          <div className="absolute inset-[24px] rounded-full bg-slate-900 flex items-center justify-center shadow-[0_0_15px_rgba(34,211,238,0.2)] w-[80px] h-[80px] border border-cyan-500/30">
            {/* Spinning geometric crystalline node inside */}
            <svg viewBox="0 0 100 100" className="w-12 h-12 text-cyan-400">
              <polygon
                points="50,15 80,35 80,65 50,85 20,65 20,35"
                fill="none"
                stroke="currentColor"
                strokeWidth="2.5"
                className="animate-pulse"
              />
              <circle cx="50" cy="50" r="10" fill="currentColor" className="opacity-80 animate-ping" />
              <circle cx="50" cy="50" r="5" fill="#ffffff" />
            </svg>
          </div>

          {/* Floating light points */}
          <div className="absolute top-2 right-4 w-1.5 h-1.5 bg-cyan-400 rounded-full animate-ping" />
          <div className="absolute bottom-1.5 left-5 w-1 h-1 bg-pink-400 rounded-full animate-ping delay-300" />
        </div>

        <div className="text-center mt-2.5">
          <span className="text-[11px] font-mono text-cyan-400 font-bold flex items-center justify-center gap-1.5 shadow-sm">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
            KEY_SPIRIT // READY
          </span>
          <p className="text-[9px] font-mono text-slate-500 mt-0.5 uppercase">QUANTUM INTELLIGENCE CORE</p>
        </div>
      </div>

      {/* Speech Chat Box styled exactly like Caesar screen */}
      <div className="relative mt-2 p-3.5 rounded-lg bg-purple-950/15 border border-purple-500/20">
        <div className="absolute -top-2 left-3 bg-slate-950 px-1 text-[9px] font-mono text-pink-500 tracking-wider">
          CHAT_DIALOGUE
        </div>
        
        <div className="min-h-[90px] text-xs font-sans text-slate-200 leading-relaxed">
          {dialogScript[activeDialogIndex].text}
        </div>

        <div className="flex items-center justify-between mt-3 pt-2.5 border-t border-purple-500/10">
          <span className="text-[10px] font-mono text-slate-500">
            SEQUENCE {activeDialogIndex + 1} / {dialogScript.length}
          </span>
          <div className="flex items-center space-x-1.5">
            <button
              onClick={handlePrevDialog}
              disabled={activeDialogIndex === 0}
              className="p-1 rounded bg-purple-500/10 hover:bg-purple-500/20 text-purple-400 disabled:opacity-30 disabled:pointer-events-none transition-colors"
            >
              <ChevronLeft className="h-3 w-3" />
            </button>
            <button
              onClick={handleNextDialog}
              className="flex items-center space-x-1 py-1 px-2.5 text-[10px] font-mono rounded bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/20 text-cyan-400 transition-all outline-none"
            >
              <span>下一句</span>
              <ChevronRight className="h-3 w-3" />
            </button>
          </div>
        </div>
      </div>

      {/* Clues database progress (战棋破译线索库) */}
      <div className="mt-4 flex-1">
        <div className="flex items-center justify-between mb-2">
          <span className="text-[10px] font-mono text-slate-400 tracking-wide">
            战棋破译线索库 ({unlockedCount}/4)
          </span>
          <button
            onClick={onCheat}
            className="text-[9px] font-mono text-slate-500 hover:text-cyan-400 transition-colors"
          >
            [开启自适应解码]
          </button>
        </div>

        <div className="space-y-1.5">
          {clueItems.map((clue) => (
            <div
              key={clue.id}
              className={`p-2 rounded border text-left transition-all ${
                clue.unlocked
                  ? 'bg-emerald-950/10 border-emerald-500/30'
                  : 'bg-slate-900/30 border-slate-500/10 opacity-60'
              }`}
            >
              <div className="flex items-center justify-between">
                <span
                  className={`text-[10px] font-display font-medium ${
                    clue.unlocked ? 'text-emerald-400' : 'text-slate-400'
                  }`}
                >
                  {clue.title}
                </span>
                <span
                  className={`text-[8px] font-mono px-1 py-0.2 rounded border ${
                    clue.unlocked
                      ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400'
                      : 'bg-slate-500/5 border-slate-500/10 text-slate-500'
                  }`}
                >
                  {clue.unlocked ? 'ACTIVE' : 'LOCKED'}
                </span>
              </div>
              <p className="text-[9px] font-mono text-slate-400 mt-1">{clue.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Submit Button */}
      <div className="mt-4 pt-2">
        <button
          onClick={onSubmit}
          className="w-full relative flex items-center justify-center p-3 rounded-lg overflow-hidden font-display text-sm tracking-widest font-semibold cursor-pointer select-none bg-gradient-to-r from-cyan-600 to-purple-600 border border-cyan-400/30 shadow-[0_0_12px_rgba(6,182,212,0.4)] text-white hover:brightness-110 active:brightness-95 transition-all"
        >
          <span className="relative z-10 flex items-center space-x-1.5 uppercase font-bold text-shadow-sm">
            <span>提交破译结果</span>
            <ChevronRight className="h-4. w-4." />
          </span>
          <div className="absolute inset-0 bg-[linear-gradient(45deg,transparent_25%,rgba(255,255,255,0.15)_50%,transparent_75%)] bg-[length:250px_250px] animate-[shimmer_3s_infinite_linear]" />
        </button>
      </div>
    </div>
  );
}
