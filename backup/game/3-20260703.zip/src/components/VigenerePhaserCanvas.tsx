/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef } from 'react';
import Phaser from 'phaser';

interface VigenerePhaserCanvasProps {
  keyword: string;
  activeKeyIndex: number;
  ciphertext: string;
  plaintext: string;
  correctKeyword: string;
  onKeywordChange: (newKey: string) => void;
  onActiveKeyIndexChange: (index: number) => void;
  isMuted: boolean;
}

export default function VigenerePhaserCanvas({
  keyword,
  activeKeyIndex,
  ciphertext,
  plaintext,
  correctKeyword,
  onKeywordChange,
  onActiveKeyIndexChange,
  isMuted,
}: VigenerePhaserCanvasProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const gameRef = useRef<Phaser.Game | null>(null);

  // Use refs to make the latest values readable inside the Phaser loops without restarting
  const stateRef = useRef({
    keyword,
    activeKeyIndex,
    ciphertext,
    plaintext,
    correctKeyword,
    isMuted,
    onKeywordChange,
    onActiveKeyIndexChange,
  });

  useEffect(() => {
    stateRef.current = {
      keyword,
      activeKeyIndex,
      ciphertext,
      plaintext,
      correctKeyword,
      isMuted,
      onKeywordChange,
      onActiveKeyIndexChange,
    };
  }, [keyword, activeKeyIndex, ciphertext, plaintext, correctKeyword, isMuted, onKeywordChange, onActiveKeyIndexChange]);

  useEffect(() => {
    if (!containerRef.current) return;

    // Phaser Config
    const config: Phaser.Types.Core.GameConfig = {
      type: Phaser.AUTO,
      width: 416,
      height: 416,
      parent: containerRef.current,
      backgroundColor: '#0a0d1a', // Theme deep dark navy
      transparent: true,
      scale: {
        mode: Phaser.Scale.FIT,
        autoCenter: Phaser.Scale.CENTER_BOTH,
      },
      physics: {
        default: 'arcade',
      },
      audio: {
        noAudio: true,
      },
      scene: {
        create: function (this: Phaser.Scene) {
          createScene(this);
        },
        update: function (this: Phaser.Scene) {
          updateScene(this);
        },
      },
    };

    const game = new Phaser.Game(config);
    gameRef.current = game;

    // Phaser elements cached
    let outerRing: Phaser.GameObjects.Graphics;
    let middleRing: Phaser.GameObjects.Graphics;
    let innerRing: Phaser.GameObjects.Graphics;
    let scannerBeam: Phaser.GameObjects.Graphics;
    let particles: Phaser.GameObjects.Arc[] = [];
    
    let outerTexts: Phaser.GameObjects.Text[] = [];
    let innerTexts: Phaser.GameObjects.Text[] = [];
    let shiftDisplayVal: Phaser.GameObjects.Text;
    let crosshairLines: Phaser.GameObjects.Graphics;

    let targetOuterRot = 0;
    let currentOuterRot = 0;
    let targetInnerRot = 0;
    let currentInnerRot = 0;

    const ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';

    function createScene(scene: Phaser.Scene) {
      const centerX = 208;
      const centerY = 208;

      // Draw Grid Background
      const grid = scene.add.graphics();
      grid.lineStyle(1, 0x11162d, 0.4);
      for (let i = 0; i <= 416; i += 16) {
        grid.lineBetween(i, 0, i, 416);
        grid.lineBetween(0, i, 416, i);
      }
      // Accent cyan circle guidelines
      grid.lineStyle(1, 0x0ea5e9, 0.08);
      grid.strokeCircle(centerX, centerY, 205);
      grid.strokeCircle(centerX, centerY, 155);
      grid.strokeCircle(centerX, centerY, 115);

      // Create Rings
      outerRing = scene.add.graphics();
      middleRing = scene.add.graphics();
      innerRing = scene.add.graphics();
      scannerBeam = scene.add.graphics();
      crosshairLines = scene.add.graphics();

      // Create Particle effects inside
      for (let i = 0; i < 20; i++) {
        const p = scene.add.circle(
          centerX + Phaser.Math.Between(-100, 100),
          centerY + Phaser.Math.Between(-100, 100),
          Phaser.Math.Between(1, 3),
          0x0ea5e9,
          Phaser.Math.Between(3, 8) / 10
        );
        scene.tweens.add({
          targets: p,
          alpha: 0.1,
          scale: 0.5,
          duration: Phaser.Math.Between(1000, 2500),
          yoyo: true,
          repeat: -1,
        });
        particles.push(p);
      }

      // Outer letters (Ciphertext static indices or shift indicators)
      for (let i = 0; i < 26; i++) {
        const angle = (i * 360) / 26 - 90; // Top is first
        const rad = Phaser.Math.DegToRad(angle);
        const x = centerX + Math.cos(rad) * 185;
        const y = centerY + Math.sin(rad) * 185;

        const textObj = scene.add.text(x, y, ALPHABET[i], {
          fontFamily: '"JetBrains Mono", Courier, monospace',
          fontSize: '15px',
          color: '#06b6d4',
        });
        textObj.setOrigin(0.5);
        textObj.setShadow(0, 0, '#06b6d4', 4, true, true);
        outerTexts.push(textObj);
      }

      // Inner alphabet letters (Shifted dynamically based on current key shift)
      for (let i = 0; i < 26; i++) {
        const angle = (i * 360) / 26 - 90;
        const rad = Phaser.Math.DegToRad(angle);
        const x = centerX + Math.cos(rad) * 135;
        const y = centerY + Math.sin(rad) * 135;

        const textObj = scene.add.text(x, y, ALPHABET[i], {
          fontFamily: '"JetBrains Mono", Courier, monospace',
          fontSize: '13px',
          color: '#ec4899', // Pink
        });
        textObj.setOrigin(0.5);
        textObj.setShadow(0, 0, '#ec4899', 3, true, true);
        innerTexts.push(textObj);
      }

      // Central visual dial container
      const centerBack = scene.add.circle(centerX, centerY, 80, 0x0f172a, 0.8);
      centerBack.setStrokeStyle(2, 0xa855f7); // Purple border

      // Center labels (Only show shiftDisplayVal centered)
      shiftDisplayVal = scene.add.text(centerX, centerY, 'A [0]', {
        fontFamily: '"JetBrains Mono", monospace',
        fontSize: '24px',
        fontStyle: 'bold',
        color: '#f43f5e',
      }).setOrigin(0.5);
      shiftDisplayVal.setShadow(0, 0, '#f43f5e', 8, true, true);

      // Top aligned pointer removed to save space

      // Interactive controls on Phaser canvas
      // Register keyboard / clicks to shift active key letter
      scene.input.on('pointerdown', (pointerObj: Phaser.Input.Pointer) => {
        const dx = pointerObj.x - centerX;
        const dy = pointerObj.y - centerY;
        const dist = Math.sqrt(dx * dx + dy * dy);

        // Play feedback node sound/blink
        if (dist > 95 && dist < 210) {
          // Calculate angle clicked
          let angleDeg = Phaser.Math.RadToDeg(Math.atan2(dy, dx)) + 90;
          if (angleDeg < 0) angleDeg += 360;
          const letterIdx = Math.round((angleDeg * 26) / 360) % 26;
          
          // Set keyword active position shift to clicked letter!
          const activeIndex = stateRef.current.activeKeyIndex;
          const kw = stateRef.current.keyword;
          if (kw.length > 0 && activeIndex >= 0 && activeIndex < kw.length) {
            const letter = ALPHABET[letterIdx];
            const kwArray = kw.split('');
            kwArray[activeIndex] = letter;
            const newKw = kwArray.join('');
            
            // Trigger feedback sound representation (Phaser visual flash)
            triggerClickEffect(scene, pointerObj.x, pointerObj.y, 0x0ea5e9);
            stateRef.current.onKeywordChange(newKw);
          }
        } else if (dist <= 80) {
          // Click center to cycle active key index
          const activeIndex = stateRef.current.activeKeyIndex;
          const kw = stateRef.current.keyword;
          if (kw.length > 0) {
            const nextIdx = (activeIndex + 1) % kw.length;
            triggerClickEffect(scene, pointerObj.x, pointerObj.y, 0xa855f7);
            stateRef.current.onActiveKeyIndexChange(nextIdx);
          }
        }
      });
    }

    function triggerClickEffect(scene: Phaser.Scene, x: number, y: number, color: number) {
      const ring = scene.add.circle(x, y, 4, color, 0.8);
      scene.tweens.add({
        targets: ring,
        radius: 35,
        alpha: 0,
        duration: 400,
        onComplete: () => ring.destroy(),
      });
    }

    let frameCount = 0;

    function updateScene(scene: Phaser.Scene) {
      frameCount++;
      const centerX = 208;
      const centerY = 208;

      // Extract details from reactive state ref
      const { keyword, activeKeyIndex, ciphertext, plaintext, correctKeyword } = stateRef.current;

      // Determine shift of CURRENT active key index
      let shiftVal = 0;
      let activeChar = 'A';
      if (keyword.length > 0) {
        const idx = activeKeyIndex % keyword.length;
        activeChar = keyword[idx]?.toUpperCase() || 'A';
        shiftVal = ALPHABET.indexOf(activeChar);
        if (shiftVal < 0) shiftVal = 0;
      }

      // Update center HUD texts
      shiftDisplayVal.setText(`${activeChar} [${shiftVal}]`);

      // Outer ring is absolutely static as requested, so currentOuterRot remains 0.
      currentOuterRot = 0;

      // Target rotation of inner wheel is shifted based on active shiftVal
      targetInnerRot = (shiftVal * (360 / 26)); // In degrees
      // Convert degree rotation smoothly
      const targetRad = Phaser.Math.DegToRad(targetInnerRot);
      currentInnerRot += (targetRad - currentInnerRot) * 0.15;

      // Draw Rings
      outerRing.clear();
      // Neon Outer border cyan glowing dashes
      outerRing.lineStyle(2, 0x06b6d4, 0.4);
      outerRing.strokeCircle(centerX, centerY, 205);
      
      // Draw concentric ticker teeth
      outerRing.lineStyle(1.5, 0x0ea5e9, 0.7);
      for (let i = 0; i < 52; i++) {
        const rad = Phaser.Math.DegToRad((i * 360) / 52) + currentOuterRot;
        const innerRad = 195;
        const outerRad = i % 2 === 0 ? 203 : 199;
        outerRing.lineBetween(
          centerX + Math.cos(rad) * innerRad,
          centerY + Math.sin(rad) * innerRad,
          centerX + Math.cos(rad) * outerRad,
          centerY + Math.sin(rad) * outerRad
        );
      }

      // Middle Ring: keyword letter indicators
      middleRing.clear();
      middleRing.lineStyle(1.5, 0xa855f7, 0.5);
      middleRing.strokeCircle(centerX, centerY, 155);
      middleRing.lineStyle(2, 0xd8b4fe, 0.9);
      
      // Draw ticks matching repeating keyword indexes
      if (keyword.length > 0) {
        for (let j = 0; j < keyword.length; j++) {
          const char = keyword[j];
          const charVal = ALPHABET.indexOf(char);
          const rad = Phaser.Math.DegToRad((charVal * 360) / 26 - 90);
          const drawRad = 155;
          // Highlight active index tick with thicker caret
          if (j === activeKeyIndex) {
            middleRing.lineStyle(4, 0xf43f5e, 1);
            middleRing.lineBetween(
              centerX + Math.cos(rad) * (drawRad - 8),
              centerY + Math.sin(rad) * (drawRad - 8),
              centerX + Math.cos(rad) * (drawRad + 8),
              centerY + Math.sin(rad) * (drawRad + 8)
            );
          } else {
            middleRing.lineStyle(2, 0xa855f7, 0.7);
            middleRing.lineBetween(
              centerX + Math.cos(rad) * (drawRad - 4),
              centerY + Math.sin(rad) * (drawRad - 4),
              centerX + Math.cos(rad) * (drawRad + 4),
              centerY + Math.sin(rad) * (drawRad + 4)
            );
          }
        }
      }

      // Inner Ring (representing ciphertext-to-plaintext shift)
      innerRing.clear();
      innerRing.lineStyle(2, 0xec4899, 0.4);
      innerRing.strokeCircle(centerX, centerY, 115);

      // Rotate alignment of texts in Phaser scene
      // Update letter positions according to rotational state
      for (let i = 0; i < 26; i++) {
        // Outer texts rotate slightly for cosmic ambient flow
        const oAngle = (i * 360) / 26 - 90 + Phaser.Math.RadToDeg(currentOuterRot);
        const oRad = Phaser.Math.DegToRad(oAngle);
        outerTexts[i].setPosition(centerX + Math.cos(oRad) * 185, centerY + Math.sin(oRad) * 185);

        // Inner shifted alphabet represents (INDEX - shiftVal)
        const iAngle = (i * 360) / 26 - 90 - Phaser.Math.RadToDeg(currentInnerRot);
        const iRad = Phaser.Math.DegToRad(iAngle);
        innerTexts[i].setPosition(centerX + Math.cos(iRad) * 135, centerY + Math.sin(iRad) * 135);

        // If the inner text letter is matched at the 12 o'clock positions (closest to pointer)
        // Highlight it dynamically to grab user focus!
        const relativeShiftedIndex = (i - shiftVal + 26) % 26;
        if (relativeShiftedIndex === 0) {
          innerTexts[i].setColor('#ffffff').setFontSize('16px');
        } else {
          innerTexts[i].setColor('#ec4899').setFontSize('13px');
        }
      }

      // Render Scanning Beam Sweeper
      scannerBeam.clear();
      const beamY = centerY + Math.sin(frameCount * 0.04) * 205;
      const gradientAlpha = 0.15;
      scannerBeam.fillStyle(0x0ea5e9, gradientAlpha);
      scannerBeam.fillRect(centerX - 205, beamY - 4, 410, 8);
      scannerBeam.lineStyle(1.5, 0x38bdf8, 0.6);
      scannerBeam.lineBetween(centerX - 205, beamY, centerX + 205, beamY);

      // Render dynamic crosshair lines targeting the current alignment
      crosshairLines.clear();
      crosshairLines.lineStyle(1, 0xf43f5e, 0.35);
      crosshairLines.lineBetween(centerX, centerY - 205, centerX, centerY - 75);
      crosshairLines.strokeCircle(centerX, centerY - 185, 12);
    }

    return () => {
      if (gameRef.current) {
        gameRef.current.destroy(true);
        gameRef.current = null;
      }
    };
  }, []);

  return (
    <div
      ref={containerRef}
      id="phaser-vigenere-container"
      className="w-full max-w-full aspect-square overflow-hidden flex items-center justify-center cursor-pointer"
    />
  );
}
