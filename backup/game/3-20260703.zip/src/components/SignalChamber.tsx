/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef } from 'react';
import { Shield } from 'lucide-react';
import { Difficulty } from '../types';

interface SignalChamberProps {
  ciphertext: string;
  plaintext: string;
  keyword: string;
  activeKeyIndex: number;
  userPlaintext: string;
  isMuted: boolean;
  score: number;
  difficulty: Difficulty;
  correctKeyword: string;
}

export default function SignalChamber({
  ciphertext,
  plaintext,
  keyword,
  activeKeyIndex,
  userPlaintext,
  isMuted,
  score,
  difficulty,
  correctKeyword,
}: SignalChamberProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Calculate matching accuracy to drive the wave state and other stats
  let correctLetters = 0;
  const len = Math.min(keyword.length, correctKeyword.length);
  for (let i = 0; i < len; i++) {
    if (keyword[i]?.toUpperCase() === correctKeyword[i]?.toUpperCase()) {
      correctLetters++;
    }
  }
  const keywordAccuracy = len > 0 ? (correctLetters / len) : 0;

  // Render moving wave analyzer on Canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let offset = 0;

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Draw subtle guidelines
      ctx.strokeStyle = 'rgba(14, 165, 233, 0.05)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(0, canvas.height / 2);
      ctx.lineTo(canvas.width, canvas.height / 2);
      ctx.stroke();

      // Wave state depends on decryption accuracy
      // Higher accuracy means less noise and clean harmonic frequency
      const isCorrect = keywordAccuracy === 1;
      const waveCount = 2;
      const amplitude = isCorrect ? 16 : 8 + (1 - keywordAccuracy) * 12;
      const frequency = isCorrect ? 0.02 : 0.01 + (1 - keywordAccuracy) * 0.03;
      const speed = isCorrect ? 0.06 : 0.03 + (1 - keywordAccuracy) * 0.05;

      offset += speed;

      // Draw Wave 1 (Base signal - Cyan)
      ctx.strokeStyle = isCorrect ? 'rgba(6, 182, 212, 0.85)' : 'rgba(34, 211, 238, 0.55)';
      ctx.lineWidth = isCorrect ? 2.5 : 1.5;
      ctx.shadowBlur = isCorrect ? 10 : 3;
      ctx.shadowColor = '#06b6d4';
      ctx.beginPath();

      for (let x = 0; x < canvas.width; x++) {
        // Compose standard sine and an optional noise factor
        let noise = 0;
        if (!isCorrect) {
          noise = Math.sin(x * 0.1 + offset * 2) * (1 - keywordAccuracy) * 8;
        }
        const y = canvas.height / 2 + Math.sin(x * frequency - offset) * amplitude + noise;
        if (x === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();

      // Draw Wave 2 (Echo signal - Pink/Purple)
      ctx.strokeStyle = isCorrect ? 'rgba(236, 72, 153, 0.55)' : 'rgba(236, 72, 153, 0.25)';
      ctx.lineWidth = 1;
      ctx.shadowBlur = 0;
      ctx.beginPath();

      for (let x = 0; x < canvas.width; x++) {
        let noise2 = 0;
        if (!isCorrect) {
          noise2 = Math.cos(x * 0.08 - offset * 1.5) * (1 - keywordAccuracy) * 6;
        }
        const y = canvas.height / 2 + Math.cos(x * (frequency * 1.2) + offset * 0.8) * (amplitude * 0.7) + noise2;
        if (x === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();

      animId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animId);
    };
  }, [keywordAccuracy]);

  // Decryption resistance calculation (100% to 0%)
  // Starts high, decreases as they enter correct key characters
  const resistancePercent = Math.max(0, Math.round((1 - keywordAccuracy) * 100));

  // A-Z mappings for the CURRENT active position
  const ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const activeKeywordChar = keyword[activeKeyIndex % keyword.length]?.toUpperCase() || 'A';
  const activeShift = ALPHABET.indexOf(activeKeywordChar);

  // Generate some pairs of (Cipher -> Plain) mappings depending on active shift index
  const selectMappingIndices = [0, 4, 7, 10, 19, 25]; // index mappings corresponding to letters A,E,H,K,T,Z

  return (
    <div className="flex flex-col h-full bg-slate-950/60 rounded-xl border border-cyan-500/20 shadow-[0_0_20px_rgba(6,182,212,0.05)] p-4 overflow-y-auto">
      {/* Title */}
      <div className="flex items-center space-x-2 mb-4 pb-2 border-b border-cyan-500/10">
        <Shield className="h-4. w-4. text-cyan-400" />
        <span className="text-xs font-display font-semibold text-cyan-300 tracking-wider">
          密文信号解析室 (SIGNAL_CHAMBER)
        </span>
      </div>

      {/* Main CipherText Box: "拦截敌方原始加密报 (CIPHER)" */}
      <div className="mb-4">
        <div className="flex items-center justify-between mb-1">
          <span className="text-[10px] font-mono text-slate-400">拦截敌方原始加密报 (CIPHER):</span>
          <span className="text-[8px] font-mono bg-cyan-500/10 text-cyan-400 px-1 py-0.2 rounded border border-cyan-500/20">
            REC-WAVE
          </span>
        </div>
        <div className="relative p-3.5 rounded-lg bg-cyan-950/10 border border-cyan-500/30 shadow-[inset_0_0_15px_rgba(6,182,212,0.05)] overflow-hidden">
          {/* Cyan glow lines */}
          <div className="text-center font-mono text-xl tracking-[0.25em] font-extrabold text-cyan-400 drop-shadow-[0_0_6px_rgba(6,182,212,0.8)]">
            {ciphertext.split('').map((char, idx) => {
              // Highlight the letters that correspond to the active key position
              const isCurrentlyActiveIdx = keyword.length > 0 && (idx % keyword.length === activeKeyIndex);
              return (
                <span
                  key={idx}
                  className={`inline-block transition-all ${
                    isCurrentlyActiveIdx
                      ? 'text-pink-400 scale-110 drop-shadow-[0_0_8px_rgba(236,72,153,1)]'
                      : ''
                  }`}
                >
                  {char}
                </span>
              );
            })}
          </div>
          <div className="absolute top-0 right-0 h-1.5 w-1.5 bg-cyan-400 rounded-bl-sm" />
          <div className="absolute bottom-0 left-0 h-1.5 w-1.5 bg-cyan-400 rounded-tr-sm" />
        </div>
      </div>

      {/* Decrypted PlainText Box: "自适应多表解密 (PLAIN)" */}
      <div className="mb-4">
        <div className="flex items-center justify-between mb-1">
          <span className="text-[10px] font-mono text-slate-400">自适应多表解密 (PLAIN):</span>
          <span className="text-[8px] font-mono bg-pink-500/10 text-pink-400 px-1 py-0.2 rounded border border-pink-500/20">
            AUTO_MATRIX
          </span>
        </div>
        <div className="relative p-3.5 rounded-lg bg-pink-950/10 border border-pink-500/30 shadow-[inset_0_0_15px_rgba(236,72,153,0.05)]">
          <div className="text-center font-mono text-xl tracking-[0.25em] font-extrabold text-pink-400 drop-shadow-[0_0_6px_rgba(236,72,153,0.8)] flex justify-center flex-wrap">
            {userPlaintext.split('').map((char, idx) => {
              const matchesCorrect = char === plaintext[idx];
              const isCurrentlyActiveIdx = keyword.length > 0 && (idx % keyword.length === activeKeyIndex);

              return (
                <span
                  key={idx}
                  className={`inline-block transition-all ${
                    matchesCorrect 
                      ? 'text-emerald-400 drop-shadow-[0_0_6px_rgba(16,185,129,0.8)]' 
                      : 'text-rose-400 drop-shadow-[0_0_6px_rgba(244,63,94,0.8)]'
                  } ${isCurrentlyActiveIdx ? 'underline decoration-cyan-400 decoration-2 underline-offset-4' : ''}`}
                >
                  {char === ' ' ? '\u00A0' : char}
                </span>
              );
            })}
          </div>
          <div className="absolute top-0 left-0 h-1.5 w-1.5 bg-pink-400 rounded-br-sm" />
          <div className="absolute bottom-0 right-0 h-1.5 w-1.5 bg-pink-400 rounded-tl-sm" />
        </div>
      </div>

      {/* WAVE ANALYZE: CH_13 */}
      <div className="mb-4 flex-1 min-h-[100px] flex flex-col justify-end">
        <div className="flex items-center justify-between mb-1">
          <span className="text-[9px] font-mono text-slate-500">
            WAVE_ANALYZE: CH_VIGENERE_Q24
          </span>
          <span className="text-[9px] font-mono text-cyan-400">
            ACCURACY: {Math.round(keywordAccuracy * 100)}%
          </span>
        </div>
        <div className="relative h-24 bg-slate-950/80 border border-cyan-500/10 rounded-lg overflow-hidden flex items-center justify-center">
          <canvas
            ref={canvasRef}
            width={320}
            height={96}
            className="w-full h-full object-cover"
          />
          {/* Subtle grid HUD guidelines */}
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_40%,rgba(10,13,26,0.3))]" />
          <div className="absolute top-1 left-2 text-[8px] font-mono text-slate-400">AMPLITUDE MOD_S</div>
        </div>
      </div>

      {/* Tabula Recta A-Z Shift Mapping Grid */}
      <div className="mb-4">
        <div className="flex items-center justify-between mb-1">
          <span className="text-[9px] font-mono text-slate-400">
            对齐映射仪 (ACTIVE KEY: <span className="text-cyan-400 font-bold font-mono">{activeKeywordChar}</span> // SHIFT = {activeShift})
          </span>
        </div>
        <div className="grid grid-cols-6 gap-1 bg-slate-900/30 p-2 rounded-lg border border-slate-800">
          {selectMappingIndices.map((idxVal) => {
            const letter = ALPHABET[idxVal];
            // Shifted letter under activeShift: (idxVal + activeShift) % 26
            const shiftedIndex = (idxVal + activeShift) % 26;
            const shiftedLetter = ALPHABET[shiftedIndex];

            return (
              <div
                key={idxVal}
                className="flex flex-col items-center justify-center py-1.5 rounded bg-slate-950/50 border border-slate-500/5 hover:border-cyan-500/20 transition-all font-mono"
              >
                <span className="text-[9px] text-slate-500 leading-none">C_CHAR</span>
                <span className="text-[12px] text-cyan-400 font-bold leading-none mt-1">{letter}</span>
                <span className="text-[9px] text-slate-600 my-0.5">↓</span>
                <span className="text-[12px] text-pink-400 font-bold leading-none">{shiftedLetter}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Resistance and Stats on Left Bottom */}
      <div className="pt-2 border-t border-cyan-500/10">
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-[10px] font-mono text-slate-400 flex items-center gap-1">
            敌军电磁锁闭阻力:
          </span>
          <span className={`text-[10px] font-mono font-bold ${resistancePercent > 0 ? 'text-orange-400' : 'text-emerald-400 animate-pulse'}`}>
            {resistancePercent}% {resistancePercent > 0 ? '(强力拦截中)' : '(拦截彻底消除!)'}
          </span>
        </div>
        <div className="w-full bg-slate-900 h-2.5 rounded-full overflow-hidden border border-slate-800">
          <div
            className={`h-full transition-all duration-500 ${
              resistancePercent > 50
                ? 'bg-rose-500 shadow-[0_0_8px_#f43f5e]'
                : resistancePercent > 0
                ? 'bg-amber-500 shadow-[0_0_8px_#f59e0b]'
                : 'bg-emerald-500 shadow-[0_0_12px_#10b981]'
            }`}
            style={{ width: `${resistancePercent}%` }}
          />
        </div>
      </div>
    </div>
  );
}
