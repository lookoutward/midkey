/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type Difficulty = 'Easy' | 'Normal' | 'Hard';

export interface Mission {
  id: string;
  name: string;
  difficulty: Difficulty;
  ciphertext: string;
  plaintext: string;
  defaultKeyword: string; // The placeholder or starting keyword
  correctKeyword: string;
  recommendedLength: number;
  description: string;
  clues: string[];
  kasiskiHint: string;
  icDescription: string;
  expectedIC: number;
}

export interface ChatMessage {
  id: string;
  sender: 'KEY_SPIRIT' | 'SYSTEM' | 'PLAYER';
  text: string;
  timestamp: string;
}

export interface GameStats {
  score: number;
  resistance: number; // Percentage showing how locked the code is (e.g., starts high, decreases to 0% when completed)
  unlockedCluesCount: number; // Count of unlocked clues (0/4)
  totalClues: number;
  timeRemainingSec: number;
  isCompleted: boolean;
  isTimeOut: boolean;
  isMuted: boolean;
}
