export interface AESDataBlock {
  row: number;
  col: number;
  originalChar: string;
  originalHex: string;
  
  // SubBytes state
  subBytesTargetHex: string;
  subBytesCurrentHex: string;
  isSubstituted: boolean;

  // ShiftRows state
  shiftRowsTargetCol: number; // Correct column after shift
  shiftRowsCurrentCol: number; // Current column coordinate
  
  // MixColumns state
  mixColorTarget: string; // Target CSS hex color
  mixColorCurrent: string; // Current mixed color
  isMixed: boolean;
  
  // AddRoundKey state
  roundKeyTargetXor: string; // Target Round Key byte
  roundKeyCurrentXor: string; // Dragged XOR byte
  isLocked: boolean;
}

export interface AESLevel {
  id: number;
  episode: string;
  title: string;
  difficulty: "Easy" | "Medium" | "Hard" | "Expert";
  plaintext: string; // Exactly 16 chars
  sboxTable: Record<string, string>; // SubBytes S-Box mapping simulation
  shiftOffsets: number[]; // e.g. [0, 1, 2, 3] representing how many shifts are needed for rows 0, 1, 2, 3
  mixColumnsColors: {
    targetColors: string[]; // 4 columns target colors
    initColors: string[]; // 4 columns starting colors
  };
  roundKeys: string[]; // 4 subkeys for col 0-3 (or standard 16 bytes format)
  lore: string; // Cyberpunk plot hook
  timeLimit: number; // in seconds
}

export type AESPhase = "SUB_BYTES" | "SHIFT_ROWS" | "MIX_COLUMNS" | "ADD_ROUND_KEY" | "COMPLETE";
