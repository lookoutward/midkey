import { AESLevel } from "./types";

// Standard S-Box simplified representation for Hex characters (0-f)
export const SIMPLIFIED_SBOX: Record<string, string> = {
  "0": "C", "1": "F", "2": "3", "3": "0", "4": "B", "5": "6",
  "6": "9", "7": "A", "8": "1", "9": "D", "a": "5", "b": "E",
  "c": "8", "d": "4", "e": "7", "f": "2",
  // Standard ASCII mapping helpers for ease of play
  "M": "59", "I": "49", "D": "44", "K": "4B", "E": "45", "Y": "59",
  "S": "53", "C": "43", "U": "55", "R": "52", "A": "41", "O": "4F",
  "P": "50", "W": "57", "F": "46", "L": "4C", "H": "48", "T": "54"
};

export const AES_LEVELS: AESLevel[] = [
  {
    id: 1,
    episode: "EP17-01",
    title: "Breach the Perimeter",
    difficulty: "Easy",
    plaintext: "MIDKEY_CYBER_101",
    sboxTable: {
      "M": "9A", "I": "F2", "D": "3C", "K": "E5",
      "E": "7B", "Y": "A0", "_": "D4", "C": "41",
      "B": "6E", "R": "8F", "1": "11", "0": "00"
    },
    shiftOffsets: [0, 1, 2, 3], // Shift 1st raw by 0, 2nd by 1, 3rd by 2, 4th by 3
    mixColumnsColors: {
      targetColors: ["#00f0ff", "#bf5aff", "#00ff66", "#ff007f"], // Neon Cyan, Neon Purple, Neon Green, Neon Pink
      initColors: ["#005577", "#5500aa", "#007722", "#aa0055"] // Duller mixed sources
    },
    roundKeys: ["KEY_ALPHA_01", "KEY_ALPHA_02", "KEY_ALPHA_03", "KEY_ALPHA_04"],
    lore: "Welcome recruit. The Netwatch Gatekeepers are using a 128-bit AES block cipher. We need to modularize our pipeline blocks to disrupt their gate controls. Perform SubBytes, ShiftRows, MixColumns and AddRoundKey to generate a compliant cipher block.",
    timeLimit: 180
  },
  {
    id: 2,
    episode: "EP17-02",
    title: "S-Box Subversion",
    difficulty: "Medium",
    plaintext: "AES_CONFUSION_99",
    sboxTable: {
      "A": "CA", "E": "4E", "S": "5F", "_": "88",
      "C": "6C", "O": "DF", "N": "1B", "F": "33",
      "U": "BD", "I": "A2", "G": "80", "9": "99"
    },
    shiftOffsets: [0, 2, 1, 3], // different row scrambles
    mixColumnsColors: {
      targetColors: ["#bf5aff", "#ff3b30", "#34c759", "#007aff"],
      initColors: ["#4a154b", "#6e0b00", "#123d14", "#0a2540"]
    },
    roundKeys: ["KEY_SIGMA_A", "KEY_SIGMA_B", "KEY_SIGMA_C", "KEY_SIGMA_D"],
    lore: "The target security nodes have started dynamically changing the substitution tables (S-Boxes). Your S-box bypass module is loaded, but must be synchronized. Re-align the bytes to establish full system confusion.",
    timeLimit: 160
  },
  {
    id: 3,
    episode: "EP17-03",
    title: "Diffusion Protocol",
    difficulty: "Medium",
    plaintext: "MIX_COLUMNS_FLOW",
    sboxTable: {
      "M": "5E", "I": "8D", "X": "F7", "_": "EE",
      "C": "0C", "O": "BB", "L": "44", "U": "12",
      "N": "AA", "S": "3A", "F": "6D", "W": "FF"
    },
    shiftOffsets: [0, 3, 2, 1],
    mixColumnsColors: {
      targetColors: ["#ff007f", "#00ff66", "#bf5aff", "#00f0ff"],
      initColors: ["#7f003f", "#008033", "#5f2c7f", "#00787f"]
    },
    roundKeys: ["KEY_DIFFUSE_1", "KEY_DIFFUSE_2", "KEY_DIFFUSE_3", "KEY_DIFFUSE_4"],
    lore: "In AES, MixColumns handles 'diffusion' — spreading the influence of a single bit across the column. Match the neon frequency spectrums to trigger complete bit diffusion.",
    timeLimit: 150
  },
  {
    id: 4,
    episode: "EP17-04",
    title: "Round Key Overdrive",
    difficulty: "Hard",
    plaintext: "KEY_XOR_DECRYPT*",
    sboxTable: {
      "K": "FF", "E": "B8", "Y": "C4", "_": "A3",
      "X": "55", "O": "22", "R": "DD", "D": "0D",
      "C": "39", "P": "AA", "T": "01", "*": "88"
    },
    shiftOffsets: [0, 1, 3, 2],
    mixColumnsColors: {
      targetColors: ["#ffcc00", "#bf5aff", "#00ff66", "#ff3366"],
      initColors: ["#7f6600", "#5f2c7f", "#008033", "#7f1933"]
    },
    roundKeys: ["KEY_XOR_W0", "KEY_XOR_W1", "KEY_XOR_W2", "KEY_XOR_W3"],
    lore: "We're nearing the center core. The Key Schedule is generating Round Keys. Your Key Spirits must carry the correct byte keys directly into the cryptographic locks to execute final bitwise XOR.",
    timeLimit: 140
  },
  {
    id: 5,
    episode: "EP17-05",
    title: "Origin Catalyst",
    difficulty: "Expert",
    plaintext: "MIDKEY_WAR_EP17",
    sboxTable: {
      "M": "17", "I": "43", "D": "5C", "K": "CE",
      "E": "BD", "Y": "A9", "_": "66", "W": "F1",
      "A": "AA", "R": "72", "P": "2D", "1": "22",
      "7": "77"
    },
    shiftOffsets: [0, 2, 3, 1],
    mixColumnsColors: {
      targetColors: ["#00f0ff", "#ff007f", "#00ff66", "#ffcc00"],
      initColors: ["#004455", "#550022", "#005522", "#554400"]
    },
    roundKeys: ["KEY_CORE_S0", "KEY_CORE_S1", "KEY_CORE_S2", "KEY_CORE_S3"],
    lore: "This is it. The core gate lock. S-Box substitutions are multi-threaded, columns are highly diffused, and subkeys have quantum state. Secure the AES state engine before Netwatch overrides our terminal connection!",
    timeLimit:120
  }
];
