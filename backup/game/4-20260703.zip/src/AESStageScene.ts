import Phaser from "phaser";
import { AESLevel, AESPhase } from "./types";

export interface GameCallback {
  onPhaseChanged: (phase: AESPhase) => void;
  onLogAdded: (msg: string, type: "info" | "success" | "warn") => void;
  onBlockUpdated: (stats: { substitutedCount: number, shiftRowsComplete: boolean, mixColsComplete: boolean, keysBound: number }) => void;
  onLevelComplete: () => void;
  onTimeTick: (timeLeft: number) => void;
  onPlaySound?: (soundType: "click" | "success" | "fail") => void;
}

export class AESStageScene extends Phaser.Scene {
  private levelData!: AESLevel;
  private callbacks!: GameCallback;
  
  // Game states
  private currentPhase: AESPhase = "SUB_BYTES";
  private timeLeft = 180;
  private timerEvent?: Phaser.Time.TimerEvent;

  // Visual state arrays for 4x4 data blocks
  private blocks: Array<{
    container: Phaser.GameObjects.Container;
    bg: Phaser.GameObjects.Rectangle;
    charText: Phaser.GameObjects.Text;
    hexText: Phaser.GameObjects.Text;
    row: number;
    col: number;
    initialIndex: number;
    char: string;
    subHex: string;
    isSubstituted: boolean;
  }> = [];

  // Shift Row drag offsets and targets
  private rowGroups: Phaser.GameObjects.Container[] = [];
  private rowAligned: boolean[] = [false, false, false, false];
  private rowOffsets: number[] = [0, 0, 0, 0]; // Current offsets in columns [0,1,2,3]

  // Mix Columns States
  private columnBlends: number[] = [0, 0, 0, 0]; // 0 to 4 steps of color mixing
  private columnIndicators: Phaser.GameObjects.Rectangle[] = [];
  private mixButtons: Phaser.GameObjects.Container[] = [];
  private scanLines: Phaser.GameObjects.Rectangle[] = [];

  // Add Round Key drag targets
  private keySpirits: Phaser.GameObjects.Container[] = [];
  private lockSlots: Phaser.GameObjects.Container[] = [];
  private lockedColumns: boolean[] = [false, false, false, false];

  private particles?: Phaser.GameObjects.Graphics;

  constructor() {
    super("AESStageScene");
  }

  init(data: { level: AESLevel; callbacks: GameCallback }) {
    this.levelData = data.level;
    this.callbacks = data.callbacks;
    this.currentPhase = "SUB_BYTES";
    this.timeLeft = data.level.timeLimit;
    this.blocks = [];
    this.rowGroups = [];
    this.rowAligned = [false, false, false, false];
    this.rowOffsets = [0, 0, 0, 0];
    this.columnBlends = [0, 0, 0, 0];
    this.columnIndicators = [];
    this.mixButtons = [];
    this.scanLines = [];
    this.keySpirits = [];
    this.lockSlots = [];
    this.lockedColumns = [false, false, false, false];
  }

  create() {
    // 1. Create a beautiful cyberpunk background pattern
    const width = this.scale.width;
    const height = this.scale.height;

    // Grid lines on back
    const bgGraphics = this.add.graphics();
    bgGraphics.lineStyle(1, 0x112240, 0.8);
    for (let x = 0; x < width; x += 40) {
      bgGraphics.lineBetween(x, 0, x, height);
    }
    for (let y = 0; y < height; y += 40) {
      bgGraphics.lineBetween(0, y, width, y);
    }

    // Interactive Particles helper
    this.particles = this.add.graphics();

    // 2. Initialize timer
    if (this.timerEvent) this.timerEvent.destroy();
    this.timerEvent = this.time.addEvent({
      delay: 1000,
      callback: this.onSecondPassed,
      callbackScope: this,
      loop: true
    });

    // 3. Setup the 4x4 data block matrix
    this.setupDataMatrix();

    // 4. Build Phase controllers
    this.switchPhase("SUB_BYTES");
    
    // Log init status
    this.callbacks.onLogAdded(`[SYS_INIT] Level: ${this.levelData.title} initialized. Block cipher matrix loaded (128-bit state).`, "info");
    this.callbacks.onLogAdded(`[OP_PENDING] Decrypt phase 1: SubBytes S-Box mapping.`, "info");
  }

  update() {
    // Cyberpunk ambient floating graphics
    if (this.particles) {
      this.particles.clear();
      this.particles.fillStyle(0x64ffda, 0.3);
      
      // Draw small floating binary numbers or dots
      if (Phaser.Math.Between(1, 100) > 95) {
        this.addBinaryBubble();
      }
    }
  }

  private addBinaryBubble() {
    const x = Phaser.Math.Between(20, this.scale.width - 20);
    const textStr = Phaser.Math.Between(0, 1).toString();
    const bitText = this.add.text(x, this.scale.height - 10, textStr, {
      fontFamily: "monospace",
      fontSize: "12px",
      color: "#64ffda"
    });
    bitText.setAlpha(0.6);

    this.tweens.add({
      targets: bitText,
      y: Phaser.Math.Between(20, 200),
      alpha: 0,
      duration: Phaser.Math.Between(2000, 4000),
      onComplete: () => bitText.destroy()
    });
  }

  private onSecondPassed() {
    this.timeLeft--;
    this.callbacks.onTimeTick(this.timeLeft);
    if (this.timeLeft <= 0) {
      this.timerEvent?.destroy();
      this.callbacks.onLogAdded(`[SYS_ALERT] Gateway timeout! Operation overrides aborted.`, "warn");
      this.callbacks.onLogAdded(`[FATAL] Terminal session terminated. Retry standard AES validation.`, "warn");
    }
  }

  // --- 4x4 Data Matrix setup ---
  private setupDataMatrix() {
    const startX = 90;
    const startY = 100;
    const spacing = 70;

    const plaintext = this.levelData.plaintext.padEnd(16, " ");

    for (let r = 0; r < 4; r++) {
      for (let c = 0; c < 4; c++) {
        const idx = r * 4 + c;
        const char = plaintext[idx];
        const hexRepr = char.charCodeAt(0).toString(16).toUpperCase();
        
        // Find S-Box target
        const sboxValue = this.levelData.sboxTable[char] || "F0";

        // Create Phaser container for cell
        const cellX = startX + c * spacing;
        const cellY = startY + r * spacing;

        const container = this.add.container(cellX, cellY);

        // Core Block Card Background
        const bg = this.add.rectangle(0, 0, 64, 64, 0x0a192f);
        bg.setStrokeStyle(2, 0x00f0ff);
        
        // Glow accent panel on the left edge
        const accent = this.add.rectangle(-28, 0, 4, 50, 0x00f0ff);

        // Typography settings
        const charText = this.add.text(0, -12, char, {
          fontFamily: "Inter, sans-serif",
          fontSize: "18px",
          color: "#ffffff",
          fontStyle: "bold"
        }).setOrigin(0.5);

        const hexText = this.add.text(0, 12, `0x${hexRepr}`, {
          fontFamily: "Courier, monospace",
          fontSize: "11px",
          color: "#8892b0"
        }).setOrigin(0.5);

        container.add([bg, accent, charText, hexText]);

        // Keep local records
        this.blocks.push({
          container,
          bg,
          charText,
          hexText,
          row: r,
          col: c,
          initialIndex: idx,
          char,
          subHex: sboxValue,
          isSubstituted: false
        });

        // Add small scale-in entrance tween
        container.setScale(0);
        this.tweens.add({
          targets: container,
          scale: 1,
          duration: 300,
          delay: idx * 25,
          ease: "Back.easeOut"
        });
      }
    }

    // Force update initial UI bindings to parent
    this.updateStats();
  }

  private updateStats() {
    const substitutedCount = this.blocks.filter(b => b.isSubstituted).length;
    const shiftRowsComplete = this.rowAligned.every(val => val);
    const mixColsComplete = this.columnBlends.every(blend => blend === 3);
    const keysBound = this.lockedColumns.filter(l => l).length;

    this.callbacks.onBlockUpdated({
      substitutedCount,
      shiftRowsComplete,
      mixColsComplete,
      keysBound
    });
  }

  // --- Phase shifting machine ---
  private switchPhase(newPhase: AESPhase) {
    this.currentPhase = newPhase;
    this.callbacks.onPhaseChanged(newPhase);

    // Clean up interface gadgets
    this.destroyDragArrows();
    this.destroyMixControls();
    this.destroyKeySpirits();

    switch (newPhase) {
      case "SUB_BYTES":
        this.initSubBytesPhase();
        break;
      case "SHIFT_ROWS":
        this.initShiftRowsPhase();
        break;
      case "MIX_COLUMNS":
        this.initMixColumnsPhase();
        break;
      case "ADD_ROUND_KEY":
        this.initAddRoundKeyPhase();
        break;
      case "COMPLETE":
        this.onLevelCleared();
        break;
    }
  }

  // --- PHASE 1: SUBBYTES INTERACTION ---
  private initSubBytesPhase() {
    // Each block makes clickable for byte substitution
    this.blocks.forEach((block) => {
      block.bg.setInteractive({ useHandCursor: true });
      block.bg.on("pointerover", () => {
        if (!block.isSubstituted) {
          block.bg.setStrokeStyle(3, 0xbf5aff); // Violet highlighter
        }
      });
      block.bg.on("pointerout", () => {
        if (!block.isSubstituted) {
          block.bg.setStrokeStyle(2, 0x00f0ff);
        } else {
          block.bg.setStrokeStyle(2, 0x34c759); // bright success green
        }
      });

      block.bg.on("pointerdown", () => {
        if (!block.isSubstituted) {
          this.executeSubstitution(block);
        }
      });
    });
  }

  private executeSubstitution(block: any) {
    this.callbacks.onPlaySound?.("click");
    block.isSubstituted = true;
    block.bg.setStrokeStyle(3, 0x34c759);
    block.bg.setFillStyle(0x0e243a);

    // Animate character transform
    this.tweens.add({
      targets: block.container,
      scaleX: 0,
      duration: 150,
      yoyo: true,
      onYoyo: () => {
        block.charText.setText(block.subHex);
        block.charText.setColor("#64ffda");
        block.hexText.setText("S-Box'd");
        block.hexText.setColor("#34c759");
      },
      onComplete: () => {
        this.showFloatingText(block.container.x, block.container.y, `S-Box -> ${block.subHex}`, "#64ffda");
        this.callbacks.onLogAdded(`[SUB_BYTES] Cell [${block.row},${block.col}] Substituted: '${block.char}' ➔ 0x${block.subHex}`, "success");
        this.updateStats();
        
        // Check if all cells substituted
        const isAllSubstituted = this.blocks.every((b) => b.isSubstituted);
        if (isAllSubstituted) {
          this.time.delayedCall(800, () => {
            this.callbacks.onLogAdded(`[SYSTEM] SubBytes phase complete. Initiating row permutations (ShiftRows).`, "success");
            this.switchPhase("SHIFT_ROWS");
          });
        }
      }
    });
  }

  // --- PHASE 2: SHIFT ROWS INTERACTION ---
  private initShiftRowsPhase() {
    // 16 Blocks need to display their substitution values, they must be organized by row
    this.callbacks.onLogAdded(`[OP_PENDING] ShiftRows instructions: Row 0 offset 0, Row 1 shift 1, Row 2 shift 2, Row 3 shift 3. Drag rows horizontally or click adjustment arrows.`, "info");
    
    const startX = 90;
    const startY = 100;
    const spacing = 70;

    // Reset interaction on block bgs
    this.blocks.forEach(b => {
      b.bg.removeAllListeners();
      b.bg.disableInteractive();
    });

    // Create row selectors & shifting buttons
    // Row 0 doesn't need shift, but Rows 1, 2, 3 need to match correct offset.
    // Let's create beautiful action arrows for row 0-3
    for (let r = 0; r < 4; r++) {
      const rowY = startY + r * spacing;

      if (r === 0) {
        // Row 0: always aligned (offset 0)
        this.rowAligned[r] = true;
        continue;
      }

      // Add a left shift arrow and right shift arrow to trigger shifting
      const leftBtn = this.add.container(startX - 52, rowY);
      const rightBtn = this.add.container(startX + 3 * spacing + 52, rowY);

      // Simple visual shapes
      const leftBg = this.add.circle(0, 0, 16, 0x112240).setStrokeStyle(1, 0x00f0ff);
      const leftArrow = this.add.text(0, 0, "◀", { fontSize: "14px", color: "#64ffda" }).setOrigin(0.5);
      leftBtn.add([leftBg, leftArrow]);
      leftBg.setInteractive({ useHandCursor: true });

      const rightBg = this.add.circle(0, 0, 16, 0x112240).setStrokeStyle(1, 0x00f0ff);
      const rightArrow = this.add.text(0, 0, "▶", { fontSize: "14px", color: "#64ffda" }).setOrigin(0.5);
      rightBtn.add([rightBg, rightArrow]);
      rightBg.setInteractive({ useHandCursor: true });

      // Keep them in a temporary structure
      this.mixButtons.push(leftBtn, rightBtn);

      // Store target offset based on AES level (Row r needs shift r, e.g. Row 1 -> offset 1, etc)
      const targetOffset = this.levelData.shiftOffsets[r];

      leftBg.on("pointerover", () => leftBg.setFillStyle(0x0a192f).setStrokeStyle(2, 0xbf5aff));
      leftBg.on("pointerout", () => leftBg.setFillStyle(0x112240).setStrokeStyle(1, 0x00f0ff));
      leftBg.on("pointerdown", () => this.shiftRowAction(r, -1, targetOffset));

      rightBg.on("pointerover", () => rightBg.setFillStyle(0x0a192f).setStrokeStyle(2, 0xbf5aff));
      rightBg.on("pointerout", () => rightBg.setFillStyle(0x112240).setStrokeStyle(1, 0x00f0ff));
      rightBg.on("pointerdown", () => this.shiftRowAction(r, 1, targetOffset));

      // Trigger initial evaluation
      this.checkRowAlignment(r, targetOffset);
    }

    this.blocks.forEach(b => {
      b.bg.setStrokeStyle(2, 0xd464ff); // Change color to lavender for row phase
    });
  }

  private shiftRowAction(rowIndex: number, direction: number, targetOffset: number) {
    this.callbacks.onPlaySound?.("click");
    // Rotate offset of row components (current col coords change)
    // There are 4 blocks in this row
    const rowBlocks = this.blocks.filter((b) => b.row === rowIndex);

    // Apply rotation
    this.rowOffsets[rowIndex] = (this.rowOffsets[rowIndex] + direction + 4) % 4;

    const startX = 90;
    const spacing = 70;

    rowBlocks.forEach((block) => {
      // New column is adjusted
      const newCol = (block.col + this.rowOffsets[rowIndex]) % 4;
      const targetX = startX + newCol * spacing;

      this.tweens.add({
        targets: block.container,
        x: targetX,
        duration: 200,
        ease: "Cubic.easeOut"
      });
    });

    this.checkRowAlignment(rowIndex, targetOffset);
  }

  private checkRowAlignment(rowIndex: number, targetOffset: number) {
    const isAligned = this.rowOffsets[rowIndex] === targetOffset;
    this.rowAligned[rowIndex] = isAligned;

    const rowBlocks = this.blocks.filter((b) => b.row === rowIndex);
    rowBlocks.forEach((block) => {
      if (isAligned) {
        block.bg.setStrokeStyle(2, 0x34c759); // Green aligned
      } else {
        block.bg.setStrokeStyle(2, 0xbf5aff); // Still unaligned purple
      }
    });

    this.updateStats();

    if (isAligned) {
      this.callbacks.onLogAdded(`[SHIFT_ROWS] Row ${rowIndex} successfully aligned (offset matches target algorithm offset ${targetOffset}).`, "success");
    }

    // Check if all rows aligned
    if (this.rowAligned.every(val => val)) {
      this.time.delayedCall(800, () => {
        this.callbacks.onLogAdded(`[SYSTEM] ShiftRows permuted successfully. Launching diffusion processor (MixColumns).`, "success");
        // Update original static col positions to actual current visual locations map
        this.blocks.forEach((block) => {
          block.col = (block.col + this.rowOffsets[block.row]) % 4;
        });
        this.switchPhase("MIX_COLUMNS");
      });
    }
  }

  private destroyDragArrows() {
    this.mixButtons.forEach(btn => btn.destroy());
    this.mixButtons = [];
  }

  // --- PHASE 3: MIXCOLUMNS INTERACTION ---
  private initMixColumnsPhase() {
    this.callbacks.onLogAdded(`[OP_PENDING] MixColumns instructions: Coordinate columns must be blended. Click "MIX" key generators below each column to diffuse data states.`, "info");
    
    const startX = 90;
    const spacing = 70;

    // Reset and lock blocks styling
    this.blocks.forEach((b) => {
      b.bg.removeAllListeners();
      b.bg.disableInteractive();
      b.bg.setStrokeStyle(2, 0x00f0ff);
    });

    const activeColorList = this.levelData.mixColumnsColors.targetColors;

    // Create column glow indicators, streaming lasers, and "Mix" buttons
    for (let c = 0; c < 4; c++) {
      const colX = startX + c * spacing;

      // 1. Column indicators (a tall glowing rectangle around the column)
      const indicator = this.add.rectangle(colX, 205, 70, 264, 0x000000, 0);
      indicator.setStrokeStyle(1.5, 0x005577);
      indicator.setDepth(-1);
      this.columnIndicators.push(indicator);

      // Create flowing laser scan line for each column
      const targetColorHex = activeColorList[c] || "#00f0ff";
      const decimalColor = Phaser.Display.Color.HexStringToColor(targetColorHex).color;
      const beam = this.add.rectangle(colX, 73, 68, 5, decimalColor, 0.45);
      beam.setDepth(1);
      
      this.tweens.add({
        targets: beam,
        y: 337,
        duration: 2000 - c * 250,
        repeat: -1,
        yoyo: false,
        ease: "Sine.easeInOut"
      });
      this.scanLines.push(beam);

      // 2. Add "MIX" action key module below each column (y = 375)
      const mixKey = this.add.container(colX, 375);
      const bgCircle = this.add.rectangle(0, 0, 60, 26, 0x112240, 1).setStrokeStyle(1.5, 0x00f0ff);
      const btnTxt = this.add.text(0, 0, "MIX", {
        fontFamily: "monospace",
        fontSize: "12px",
        fontStyle: "bold",
        color: "#64ffda"
      }).setOrigin(0.5);

      mixKey.add([bgCircle, btnTxt]);
      bgCircle.setInteractive({ useHandCursor: true });

      bgCircle.on("pointerover", () => bgCircle.setFillStyle(0x0a192f).setStrokeStyle(2, 0xbf5aff));
      bgCircle.on("pointerout", () => bgCircle.setFillStyle(0x112240).setStrokeStyle(1.5, 0x00f0ff));

      bgCircle.on("pointerdown", () => this.mixColumn(c));

      this.mixButtons.push(mixKey);
    }

    // Set initial column backgrounds dull
    this.updateColumnVisuals();
  }

  private getDiffusedHex(block: any): string {
    const c = block.col;
    const colBlocks = this.blocks.filter(b => b.col === c);
    let sum = 0;
    colBlocks.forEach((b, rIndex) => {
      const val = parseInt(b.subHex, 16) || 0;
      // Galois Field-like dynamic weight multiplication to simulate Column Multiplication
      sum += val * (rIndex + 2 + block.row);
    });
    const mixedByte = (sum % 243 + 13) & 0xFF;
    return mixedByte.toString(16).toUpperCase().padStart(2, "0");
  }

  private mixColumn(colIdx: number) {
    this.callbacks.onPlaySound?.("click");
    if (this.columnBlends[colIdx] < 3) {
      this.columnBlends[colIdx]++;
      
      const startX = 90;
      const spacing = 70;
      const colX = startX + colIdx * spacing;
      this.showFloatingText(colX, 337, `MIX x${this.columnBlends[colIdx]}`, "#bf5aff");
      this.callbacks.onLogAdded(`[MIX_COLUMNS] Column ${colIdx} state matrix diffused level ${this.columnBlends[colIdx]}/3.`, "info");
      
      this.updateColumnVisuals();
      this.updateStats();

      // Check if all mixed fully
      if (this.columnBlends.every(blend => blend === 3)) {
        this.time.delayedCall(400, () => {
          this.callbacks.onLogAdded(`[SYSTEM] MixColumns successfully matrix multiplied. All columns fully diffused. Initiating AddRoundKey.`, "success");
          this.switchPhase("ADD_ROUND_KEY");
        });
      }
    } else {
      this.callbacks.onLogAdded(`[ALERT] Column ${colIdx} is already at peak diffusion.`, "warn");
    }
  }

  private updateColumnVisuals() {
    const activeColorList = this.levelData.mixColumnsColors.targetColors;
    const startX = 90;
    const spacing = 70;

    for (let c = 0; c < 4; c++) {
      const blend = this.columnBlends[c];
      const indicator = this.columnIndicators[c];
      const nextBtn = this.mixButtons[c].list[0] as Phaser.GameObjects.Rectangle;
      const nextTxt = this.mixButtons[c].list[1] as Phaser.GameObjects.Text;

      const blockGroup = this.blocks.filter(b => b.col === c);

      if (blend === 0) {
        indicator.setStrokeStyle(1.5, 0x550055, 0.5);
        blockGroup.forEach(bg => bg.bg.setFillStyle(0x000000));
      } else if (blend === 1) {
        indicator.setStrokeStyle(1.5, 0x00f0ff, 0.4);
        blockGroup.forEach(bg => bg.bg.setFillStyle(0x0c253d));
      } else if (blend === 2) {
        indicator.setStrokeStyle(2, 0xbf5aff, 0.7);
        blockGroup.forEach(bg => bg.bg.setFillStyle(0x19102c));
      } else if (blend === 3) {
        // Fully mixed! Make blocks match target colors beautifully
        const finalColorHex = activeColorList[c];
        const decimalColor = Phaser.Display.Color.HexStringToColor(finalColorHex).color;
        
        indicator.setStrokeStyle(2.5, decimalColor, 1);
        blockGroup.forEach(bg => {
          const diffusedHex = this.getDiffusedHex(bg);
          bg.bg.setFillStyle(0x0a192f);
          bg.bg.setStrokeStyle(2, decimalColor);
          bg.charText.setText(diffusedHex);
          bg.charText.setColor(finalColorHex);
          bg.hexText.setText(`0x${diffusedHex}`);
          bg.hexText.setColor("#34c759");
        });

        // De-active button
        if (nextBtn) {
          nextBtn.setFillStyle(0x34c759, 0.2);
          nextBtn.setStrokeStyle(2, 0x34c759);
          nextBtn.disableInteractive();
          nextTxt.setText("DONE").setColor("#34c759");
        }
      }
    }
  }

  private destroyMixColumnsGadgets() {
    this.columnIndicators.forEach(ci => ci.destroy());
    this.columnIndicators = [];
    this.scanLines.forEach(sl => sl.destroy());
    this.scanLines = [];
  }

  private destroyMixControls() {
    this.destroyDragArrows();
    this.destroyMixColumnsGadgets();
  }

  // --- PHASE 4: ADD ROUND KEY INTERACTION (DRAG & DROP) ---
  private initAddRoundKeyPhase() {
    this.callbacks.onLogAdded(`[OP_PENDING] AddRoundKey: Four Key Spirits have generated subkeys on the right side. Drag-and-drop each Key Spirit into its corresponding Column Lock Slot below.`, "info");
    
    const startX = 90;
    const spacing = 70;

    // Create 4 lock slots beneath the columns (y = 375)
    for (let c = 0; c < 4; c++) {
      const colX = startX + c * spacing;

      const slot = this.add.container(colX, 375);
      const slotBg = this.add.ellipse(0, 0, 56, 32, 0x112240).setStrokeStyle(1.5, 0x00f0ff);
      
      const targetSubKey = this.levelData.roundKeys[c];
      
      const lockIcon = this.add.text(0, -1, "🔒", { fontSize: "12px" }).setOrigin(0.5);

      const targetTxt = this.add.text(0, 20, `COL ${c}`, {
        fontFamily: "monospace",
        fontSize: "10px",
        color: "#8892b0"
      }).setOrigin(0.5);

      slot.add([slotBg, lockIcon, targetTxt]);
      this.lockSlots.push(slot);
    }

    // Create 4 dynamic Round Key Spirits floating on the right side (around x = 405, y = 100 to 310)
    const keyData = this.levelData.roundKeys;
    const shuffledKeys = [...keyData].map((key, origIdx) => ({ key, origIdx }));
    // Shuffle slightly
    shuffledKeys.reverse();

    shuffledKeys.forEach((keyItem, viewIdx) => {
      const spiritX = 405;
      const spiritY = 100 + viewIdx * 70;

      const spirit = this.add.container(spiritX, spiritY);
      
      // Cyberpunk floating node element
      const spiritBg = this.add.circle(0, 0, 26, 0x1e2d3d).setStrokeStyle(2, 0xbf5aff);
      const spiritGhost = this.add.circle(0, 0, 29, 0xbf5aff, 0.1);
      
      const keyLabel = this.add.text(0, -4, `W[${keyItem.origIdx}]`, {
        fontFamily: "monospace",
        fontSize: "12px",
        fontStyle: "bold",
        color: "#00f0ff"
      }).setOrigin(0.5);

      const valLabel = this.add.text(0, 8, keyItem.key.substring(4, 9), {
        fontFamily: "monospace",
        fontSize: "8px",
        color: "#8892b0"
      }).setOrigin(0.5);

      spirit.add([spiritBg, spiritGhost, keyLabel, valLabel]);
      
      // Make spirit draggable in Phaser
      spiritBg.setInteractive({ useHandCursor: true });
      this.input.setDraggable(spiritBg);

      // Save references on the draggable handle for drag callbacks
      spiritBg.setData("container", spirit);
      spiritBg.setData("origIdx", keyItem.origIdx);
      spiritBg.setData("keyName", keyItem.key);
      spiritBg.setData("homeX", spiritX);
      spiritBg.setData("homeY", spiritY);

      this.keySpirits.push(spirit);

      // Float effect on each spirit
      this.tweens.add({
        targets: spirit,
        y: spiritY + 5,
        duration: 1500 + viewIdx * 200,
        yoyo: true,
        repeat: -1,
        ease: "Sine.easeInOut"
      });
    });

    // Wire Phaser standard drag-hold events
    this.input.on("dragstart", (pointer: Phaser.Input.Pointer, gameObject: Phaser.GameObjects.GameObject) => {
      this.callbacks.onPlaySound?.("click");
      const parentContainer = gameObject.getData("container");
      if (parentContainer) {
        // Stop floating tween immediately
        this.tweens.killTweensOf(parentContainer);
        
        // Save initial offset to prevent sudden jumping
        const offsetX = parentContainer.x - pointer.x;
        const offsetY = parentContainer.y - pointer.y;
        gameObject.setData("dragOffsetX", offsetX);
        gameObject.setData("dragOffsetY", offsetY);
      }
    });

    this.input.on("drag", (pointer: Phaser.Input.Pointer, gameObject: Phaser.GameObjects.GameObject) => {
      const parentContainer = gameObject.getData("container");
      if (parentContainer) {
        const offsetX = gameObject.getData("dragOffsetX") || 0;
        const offsetY = gameObject.getData("dragOffsetY") || 0;
        parentContainer.x = pointer.x + offsetX;
        parentContainer.y = pointer.y + offsetY;
      }
    });

    this.input.on("dragend", (pointer: Phaser.Input.Pointer, gameObject: Phaser.GameObjects.GameObject) => {
      const parentContainer = gameObject.getData("container");
      const origIdx = gameObject.getData("origIdx");
      const keyName = gameObject.getData("keyName");
      const homeX = gameObject.getData("homeX");
      const homeY = gameObject.getData("homeY");

      if (!parentContainer) return;

      // Check distance to the target column index lock slot (which is `origIdx`)
      const targetSlot = this.lockSlots[origIdx];
      const distance = Phaser.Math.Distance.Between(parentContainer.x, parentContainer.y, targetSlot.x, targetSlot.y);

      if (distance < 50 && !this.lockedColumns[origIdx]) {
        // Success snap drop!
        this.snapKeyToSlot(parentContainer, origIdx, keyName, targetSlot);
      } else {
        this.callbacks.onPlaySound?.("fail");
        // Fly back home
        this.tweens.add({
          targets: parentContainer,
          x: homeX,
          y: homeY,
          duration: 300,
          ease: "Back.easeOut",
          onComplete: () => {
            // Re-enable floating effect after returning home safely
            this.tweens.add({
              targets: parentContainer,
              y: homeY + 5,
              duration: 1500,
              yoyo: true,
              repeat: -1,
              ease: "Sine.easeInOut"
            });
          }
        });
      }
    });
  }

  private snapKeyToSlot(spirit: Phaser.GameObjects.Container, colIdx: number, keyName: string, slot: Phaser.GameObjects.Container) {
    this.callbacks.onPlaySound?.("success");
    this.lockedColumns[colIdx] = true;
    
    // Stop floating tween
    this.tweens.killTweensOf(spirit);

    // Disable dragging
    const handle = spirit.list[0] as Phaser.GameObjects.Shape;
    handle.disableInteractive();

    // Snap to slot center precisely
    this.tweens.add({
      targets: spirit,
      x: slot.x,
      y: slot.y,
      scale: 0.9,
      duration: 150,
      ease: "Cubic.easeOut",
      onComplete: () => {
        // Lock visuals
        const slotCircles = slot.list[0] as Phaser.GameObjects.Shape;
        slotCircles.setStrokeStyle(2.5, 0x34c759);
        slotCircles.setFillStyle(0x0c2522);
        
        const lockTxt = slot.list[1] as Phaser.GameObjects.Text;
        lockTxt.setText("🔓");

        // Flash column blocks green indicating Round Key applied XOR complete
        const colBlocks = this.blocks.filter(b => b.col === colIdx);
        colBlocks.forEach((cb) => {
          cb.bg.setStrokeStyle(3, 0x34c759);
          cb.hexText.setText("XOR-CYPHER");
          cb.hexText.setColor("#64ffda");
        });

        this.showFloatingText(slot.x, slot.y - 25, "XOR OK", "#34c759");
        this.callbacks.onLogAdded(`[ADD_ROUND_KEY] XOR lock columns complete [Col ${colIdx}] with ${keyName}.`, "success");
        this.updateStats();

        // Evaluate level clearance
        if (this.lockedColumns.every(locked => locked)) {
          this.switchPhase("COMPLETE");
        }
      }
    });
  }

  private destroyKeySpirits() {
    this.keySpirits.forEach(k => k.destroy());
    this.keySpirits = [];
    this.lockSlots.forEach(s => s.destroy());
    this.lockSlots = [];
    this.input.removeAllListeners("drag");
    this.input.removeAllListeners("dragend");
  }

  // --- FLOATING FEEDBACK TEXT ---
  private showFloatingText(x: number, y: number, text: string, color: string) {
    const floatTxt = this.add.text(x, y, text, {
      fontFamily: "monospace",
      fontSize: "13px",
      fontStyle: "bold",
      color: color
    }).setOrigin(0.5);

    this.tweens.add({
      targets: floatTxt,
      y: y - 40,
      alpha: 0,
      duration: 1000,
      onComplete: () => floatTxt.destroy()
    });
  }

  // --- LEVEL CLEARED AND TRANSITIONS ---
  private onLevelCleared() {
    this.timerEvent?.destroy();
    this.callbacks.onPlaySound?.("success");
    
    // Play victorious full matrix glow animation
    this.blocks.forEach((cb, idx) => {
      this.tweens.add({
        targets: cb.container,
        scaleY: 1.1,
        scaleX: 1.1,
        duration: 350,
        yoyo: true,
        repeat: 2,
        delay: idx * 30,
        ease: "Sine.easeInOut",
        onComplete: () => {
          if (idx === this.blocks.length - 1) {
            this.callbacks.onLevelComplete();
          }
        }
      });
    });

    this.callbacks.onLogAdded(`[SYSTEM_EVENT] Lock keys verified. Core stream decryption successful! 128-bit block fully encrypted using AES S-Box protocol.`, "success");
  }
}
