import { useState, useEffect, useRef, useMemo } from "react";
import Phaser from "phaser";
import {
  Volume2,
  VolumeX,
  HelpCircle,
  X,
  CheckCircle2,
  RefreshCw,
  ArrowRight
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

import { AES_LEVELS } from "./data";
import { AESLevel, AESPhase } from "./types";
import { AESStageScene, GameCallback } from "./AESStageScene";

// --- CLIENT-SIDE SYNTHESIZER SOUND ENGINE ---
class SoundEngine {
  private ctx: AudioContext | null = null;
  private muted: boolean = false;

  constructor() {}

  toggleMute(targetValue?: boolean) {
    if (typeof targetValue === "boolean") {
      this.muted = targetValue;
    } else {
      this.muted = !this.muted;
    }
    return this.muted;
  }

  isMuted() {
    return this.muted;
  }

  private init() {
    if (!this.ctx) {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioContextClass) {
        this.ctx = new AudioContextClass();
      }
    }
    if (this.ctx && this.ctx.state === "suspended") {
      this.ctx.resume().catch(() => {});
    }
  }

  playClick() {
    if (this.muted) return;
    try {
      this.init();
      if (!this.ctx) return;
      const osc = this.ctx.createOscillator();
      const gainNode = this.ctx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(800, this.ctx.currentTime);
      gainNode.gain.setValueAtTime(0.08, this.ctx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + 0.08);
      osc.connect(gainNode);
      gainNode.connect(this.ctx.destination);
      osc.start();
      osc.stop(this.ctx.currentTime + 0.08);
    } catch (e) {
      console.warn("Audio Context init blocked:", e);
    }
  }

  playSuccess() {
    if (this.muted) return;
    try {
      this.init();
      if (!this.ctx) return;
      const now = this.ctx.currentTime;
      // High sweet electronic notes chime: E5 -> G5 -> C6
      const notes = [659.25, 783.99, 1046.50];
      notes.forEach((freq, idx) => {
        const osc = this.ctx!.createOscillator();
        const gainNode = this.ctx!.createGain();
        osc.type = "sine";
        osc.frequency.setValueAtTime(freq, now + idx * 0.08);
        gainNode.gain.setValueAtTime(0.06, now + idx * 0.08);
        gainNode.gain.exponentialRampToValueAtTime(0.0001, now + idx * 0.08 + 0.2);
        osc.connect(gainNode);
        gainNode.connect(this.ctx!.destination);
        osc.start(now + idx * 0.08);
        osc.stop(now + idx * 0.08 + 0.22);
      });
    } catch (e) {
      console.warn("Audio Context success play blocked:", e);
    }
  }

  playFail() {
    if (this.muted) return;
    try {
      this.init();
      if (!this.ctx) return;
      const osc = this.ctx.createOscillator();
      const gainNode = this.ctx.createGain();
      osc.type = "sawtooth";
      osc.frequency.setValueAtTime(150, this.ctx.currentTime);
      gainNode.gain.setValueAtTime(0.1, this.ctx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + 0.18);
      osc.connect(gainNode);
      gainNode.connect(this.ctx.destination);
      osc.start();
      osc.stop(this.ctx.currentTime + 0.18);
    } catch (e) {
      console.warn("Audio Context fail play blocked:", e);
    }
  }
}

const soundEngine = new SoundEngine();

export default function App() {
  const [activeLevelIdx, setActiveLevelIdx] = useState<number>(0);
  const [resetCounter, setResetCounter] = useState<number>(0);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isHelpOpen, setIsHelpOpen] = useState<boolean>(false);
  const [helpLanguage, setHelpLanguage] = useState<"ZH" | "EN">("ZH");
  const [isVictoryOpen, setIsVictoryOpen] = useState<boolean>(false);

  const currentLevel: AESLevel = useMemo(() => {
    return AES_LEVELS[activeLevelIdx];
  }, [activeLevelIdx]);

  // Game execution states
  const [currentPhase, setCurrentPhase] = useState<AESPhase>("SUB_BYTES");
  
  // Progress tracking
  const [blockStats, setBlockStats] = useState({
    substitutedCount: 0,
    shiftRowsComplete: false,
    mixColsComplete: false,
    keysBound: 0
  });

  const phaserInstance = useRef<Phaser.Game | null>(null);

  // Sound play interface
  const handlePlaySound = (soundType: "click" | "success" | "fail") => {
    if (soundType === "click") {
      soundEngine.playClick();
    } else if (soundType === "success") {
      soundEngine.playSuccess();
    } else if (soundType === "fail") {
      soundEngine.playFail();
    }
  };

  // Setup / reset Phaser Game
  useEffect(() => {
    setCurrentPhase("SUB_BYTES");
    setIsVictoryOpen(false);
    setBlockStats({
      substitutedCount: 0,
      shiftRowsComplete: false,
      mixColsComplete: false,
      keysBound: 0
    });

    // Destroy existing Phaser Instance if it exists
    if (phaserInstance.current) {
      phaserInstance.current.destroy(true);
      phaserInstance.current = null;
    }

    const gameCallbacks: GameCallback = {
      onPhaseChanged: (phase: AESPhase) => {
        setCurrentPhase(phase);
      },
      onLogAdded: () => {},
      onBlockUpdated: (stats) => {
        setBlockStats(stats);
      },
      onLevelComplete: () => {
        setIsVictoryOpen(true);
        handlePlaySound("success");
      },
      onTimeTick: () => {},
      onPlaySound: (soundType) => {
        handlePlaySound(soundType);
      }
    };

    // Phaser 3 configuration
    const config: Phaser.Types.Core.GameConfig = {
      type: Phaser.CANVAS, // Force Canvas mode for iframe sandbox reliability
      parent: "game-viewport",
      width: 440,
      height: 440,
      scale: {
        mode: Phaser.Scale.FIT,
        autoCenter: Phaser.Scale.CENTER_BOTH
      },
      backgroundColor: "#020c1b",
      pixelArt: true,
      audio: {
        noAudio: true
      },
      physics: {
        default: "arcade"
      }
    };

    const game = new Phaser.Game(config);
    phaserInstance.current = game;

    const startSceneWhenReady = () => {
      if (game.isBooted) {
        game.scene.add("AESStageScene", AESStageScene, true, {
          level: currentLevel,
          callbacks: gameCallbacks
        });
      } else {
        game.events.once("ready", () => {
          game.scene.add("AESStageScene", AESStageScene, true, {
            level: currentLevel,
            callbacks: gameCallbacks
          });
        });
      }
    };
    startSceneWhenReady();

    return () => {
      if (game) {
        game.destroy(true);
        phaserInstance.current = null;
      }
    };
  }, [activeLevelIdx, resetCounter]);

  // Restart trigger
  const handleRestartLevel = () => {
    handlePlaySound("click");
    setResetCounter((prev) => prev + 1);
  };

  // Toggle Mute
  const handleToggleMute = () => {
    const nextMute = soundEngine.toggleMute();
    setIsMuted(nextMute);
    if (!nextMute) {
      soundEngine.playClick();
    }
  };

  // Toggle Help
  const handleToggleHelp = () => {
    handlePlaySound("click");
    setIsHelpOpen((prev) => !prev);
  };

  return (
    <div className="min-h-screen bg-[#020c1b] text-[#64ffda] font-mono antialiased flex flex-col justify-between selection:bg-[#64ffda] selection:text-[#020c1b] relative p-4 md:p-6 overflow-hidden">
      
      {/* BACKGROUND DECORATIVE GRID */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(100,255,218,0.1),rgba(0,0,0,0))] pointer-events-none z-0" />

      {/* TOP HEADER CONTROLS (Image 2 style) */}
      <header className="w-full max-w-[800px] mx-auto flex justify-between items-center gap-3.5 z-10 relative">
        <span className="text-xs md:text-sm tracking-[0.25em] font-bold text-[#64ffda] font-mono select-none" style={{ textShadow: "0 0 10px rgba(100,255,218,0.2)" }}>
          DES SIMULATION
        </span>
        <div className="flex items-center gap-3.5">
          {/* Sound toggle button */}
          <button
            id="sound-toggle-btn"
            onClick={handleToggleMute}
            className="bg-[#020c1b]/80 border-2 border-[#64ffda]/30 text-[#64ffda] hover:border-[#64ffda] hover:bg-[#64ffda]/10 p-3 rounded-xl transition-all duration-200 cursor-pointer flex items-center justify-center focus:outline-none focus:ring-1 focus:ring-[#64ffda]/50 shadow-[0_0_15px_rgba(100,255,218,0.1)] active:scale-95"
            title={isMuted ? "Unmute sounds" : "Mute sounds"}
          >
            {isMuted ? (
              <VolumeX className="w-6 h-6 text-red-400" />
            ) : (
              <Volume2 className="w-6 h-6" />
            )}
          </button>

          {/* Help button */}
          <button
            id="help-toggle-btn"
            onClick={handleToggleHelp}
            className="bg-[#020c1b]/80 border-2 border-[#64ffda]/30 text-[#64ffda] hover:border-[#64ffda] hover:bg-[#64ffda]/10 p-3 rounded-xl transition-all duration-200 cursor-pointer flex items-center justify-center focus:outline-none focus:ring-1 focus:ring-[#64ffda]/50 shadow-[0_0_15px_rgba(100,255,218,0.1)] active:scale-95"
            title="Show operational guide"
          >
            <HelpCircle className="w-6 h-6" />
          </button>
        </div>
      </header>

      {/* CENTER STAGE (Image 1 style) */}
      <main className="flex-1 flex flex-col justify-center items-center gap-5 z-10 relative my-2">
        <div className="w-full max-w-[800px] flex flex-col gap-4">
          
          {/* PHASER STAGE PORT */}
          <div className="relative rounded-xl border-2 border-[#64ffda]/25 bg-[#020c1b] overflow-hidden shadow-[0_0_35px_rgba(100,255,218,0.12)] max-w-[440px] w-full mx-auto">
            <div id="game-viewport" className="w-[440px] h-[440px] outline-none mx-auto" />

            {/* Aesthetic Tech Corner clips */}
            <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-[#64ffda]" />
            <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-[#64ffda]" />
            <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-[#64ffda]" />
            <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-[#64ffda]" />
          </div>

          {/* ACTIVE PROGRESS STEPPER FOOTER (Image 1 bottom row) */}
          <footer className="grid grid-cols-4 gap-3 bg-[#0a192f] p-3 rounded-xl border border-[#64ffda]/20">
            <div className={`py-3.5 px-2 rounded-lg font-bold flex flex-col justify-center items-center transition-all ${
              currentPhase === "SUB_BYTES" 
                ? "bg-[#64ffda] text-[#0a192f] shadow-[0_0_20px_rgba(100,255,218,0.35)] scale-[1.03]" 
                : "bg-[#020c1b] border border-[#64ffda]/30 text-[#64ffda] opacity-75 grayscale hover:grayscale-0"
            }`}>
              <span className="text-[9px] uppercase tracking-wider mb-0.5 opacity-85">Step 01</span>
              <span className="text-[11px] md:text-xs">SubBytes</span>
            </div>

            <div className={`py-3.5 px-2 rounded-lg font-bold flex flex-col justify-center items-center transition-all ${
              currentPhase === "SHIFT_ROWS" 
                ? "bg-[#64ffda] text-[#0a192f] shadow-[0_0_20px_rgba(100,255,218,0.35)] scale-[1.03]" 
                : "bg-[#020c1b] border border-[#64ffda]/30 text-[#64ffda] opacity-75 grayscale hover:grayscale-0"
            }`}>
              <span className="text-[9px] uppercase tracking-wider mb-0.5 opacity-85">Step 02</span>
              <span className="text-[11px] md:text-xs">ShiftRows</span>
            </div>

            <div className={`py-3.5 px-2 rounded-lg font-bold flex flex-col justify-center items-center transition-all ${
              currentPhase === "MIX_COLUMNS" 
                ? "bg-[#64ffda] text-[#0a192f] shadow-[0_0_20px_rgba(100,255,218,0.35)] scale-[1.03]" 
                : "bg-[#020c1b] border border-[#64ffda]/30 text-[#64ffda] opacity-75 grayscale hover:grayscale-0"
            }`}>
              <span className="text-[9px] uppercase tracking-wider mb-0.5 opacity-85">Step 03</span>
              <span className="text-[11px] md:text-xs">MixColumns</span>
            </div>

            <div className={`py-3.5 px-2 rounded-lg font-bold flex flex-col justify-center items-center transition-all ${
              currentPhase === "ADD_ROUND_KEY" || currentPhase === "COMPLETE"
                ? "bg-[#64ffda] text-[#0a192f] shadow-[0_0_20px_rgba(100,255,218,0.35)] scale-[1.03]" 
                : "bg-[#020c1b] border border-[#64ffda]/30 text-[#64ffda] opacity-75 grayscale hover:grayscale-0"
            }`}>
              <span className="text-[9px] uppercase tracking-wider mb-0.5 opacity-85">Step 04</span>
              <span className="text-[11px] md:text-xs">AddRoundKey</span>
            </div>
          </footer>

        </div>
      </main>

      {/* FIXED PAGE FOOTER ACCENTS */}
      <footer className="w-full flex justify-center items-center py-2 z-10 relative">
        <span className="text-xs md:text-sm tracking-[0.25em] font-semibold text-[#64ffda]/65 font-mono select-none" style={{ textShadow: "0 0 10px rgba(100,255,218,0.2)" }}>
          MIDKEY | DES SIMULATION
        </span>
      </footer>

      {/* BILINGUAL HELP MANUAL OVERLAY (CHINESE & ENGLISH GUIDE) */}
      <AnimatePresence>
        {isHelpOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-[#020c1b]/95 backdrop-blur-md flex items-center justify-center p-4 z-50"
          >
            <motion.div
              initial={{ scale: 0.95, y: 15 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 15 }}
              className="bg-[#050c18] border border-[#64ffda]/35 rounded-2xl max-w-[520px] w-full overflow-hidden shadow-[0_0_50px_rgba(0,240,255,0.15)] flex flex-col max-h-[85vh]"
            >
              {/* MODAL HEADER */}
              <div className="px-6 py-5 flex justify-between items-center border-b border-[#112240] shrink-0">
                <h3 className="text-base md:text-lg font-bold text-[#00f0ff] tracking-wide select-none font-sans">
                  {helpLanguage === "ZH" ? "AES加解密战术指南" : "AES DECRYPTOR GUIDE"}
                </h3>
                <div className="flex items-center gap-3">
                  {/* Language Switch Button */}
                  <button
                    onClick={() => {
                      handlePlaySound("click");
                      setHelpLanguage(prev => prev === "ZH" ? "EN" : "ZH");
                    }}
                    className="border border-[#00f0ff]/30 text-[#00f0ff] hover:bg-[#00f0ff]/10 px-3 py-1 rounded-lg text-xs font-mono font-bold tracking-wider transition-all cursor-pointer select-none active:scale-95"
                  >
                    {helpLanguage === "ZH" ? "EN" : "中"}
                  </button>
                  {/* Close Button */}
                  <button
                    onClick={handleToggleHelp}
                    className="text-[#8892b0] hover:text-[#00f0ff] transition-all cursor-pointer p-1 rounded-lg"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* HANDBOOK BODY */}
              <div className="p-6 overflow-y-auto flex-1 font-sans text-xs md:text-[13px] leading-relaxed text-slate-300 space-y-6 scrollbar-thin scrollbar-thumb-[#00f0ff]/20 scrollbar-track-[#020c1b]">
                {helpLanguage === "ZH" ? (
                  // CHINESE GUIDE
                  <div className="space-y-6">
                    {/* Section 1 */}
                    <div className="space-y-2">
                      <h4 className="text-[#00f0ff] font-bold text-sm md:text-base select-none">
                        1. 什么是 AES-128 对称加密？
                      </h4>
                      <p className="text-slate-300 leading-relaxed">
                        AES-128 是一种经典的<strong className="text-white font-semibold underline decoration-[#00f0ff]/30">多轮分组对称加密算法</strong>。它会循环使用“轮密钥”对 4x4 的数据字节矩阵进行迭代变换，在不同状态和位置上执行替代与扩散，实现坚不可摧的安全保护！
                      </p>
                    </div>

                    {/* Section 2 */}
                    <div className="space-y-3">
                      <h4 className="text-[#ec4899] font-bold text-sm md:text-base select-none">
                        2. 状态矩阵变换对齐法则
                      </h4>
                      <ul className="space-y-3 list-none pl-0">
                        <li className="relative pl-4">
                          <span className="absolute left-0 top-1.5 w-1.5 h-1.5 rounded-full bg-[#ec4899]" />
                          <strong className="text-[#00f0ff]">字节代换 (SubBytes) = 查表替换:</strong> 逐个点击状态矩阵中的数据方块，明文将基于非线性 S-Box 置换表进行映射替换，代换完成后方块亮起就绪绿边。
                        </li>
                        <li className="relative pl-4">
                          <span className="absolute left-0 top-1.5 w-1.5 h-1.5 rounded-full bg-[#ec4899]" />
                          <strong className="text-[#ec4899]">行移位 (ShiftRows) = 循环偏移:</strong> 点击行两侧的 <b>[◀] / [▶]</b> 按钮以进行水平循环偏移。当各行偏移量完美匹配算法对齐要求后（第 1/2/3 行分别偏移 1/2/3 字节），该行自动锁定并点亮绿光。
                        </li>
                        <li className="relative pl-4">
                          <span className="absolute left-0 top-1.5 w-1.5 h-1.5 rounded-full bg-[#ec4899]" />
                          <strong className="text-[#00f0ff]">列混淆 (MixColumns) = 矩阵乘法:</strong> 点击矩阵各列底部的 <b>[MIX]</b> 按钮多次，对列向量进行有限域乘法调和。哪怕仅改变一个单字节，其改动也会扩散并彻底重组整列（雪崩效应）。
                        </li>
                        <li className="relative pl-4">
                          <span className="absolute left-0 top-1.5 w-1.5 h-1.5 rounded-full bg-[#ec4899]" />
                          <strong className="text-[#ec4899]">轮密钥加 (AddRoundKey) = 异或异动:</strong> 拖拽右侧生成的轮密钥钥灵 (W[r] Vector) 精准放置到列底部的插槽锁定位置。四个钥灵匹配就位后，触发二进制异或 (XOR) 运算完成最终加密。
                        </li>
                      </ul>
                    </div>

                    {/* Section 3 */}
                    <div className="space-y-3">
                      <h4 className="text-[#00f0ff] font-bold text-sm md:text-base select-none">
                        3. 界面按钮代表含义
                      </h4>
                      <div className="bg-[#0b132b]/80 p-4 rounded-xl border border-[#00f0ff]/15 space-y-3 font-mono text-xs text-slate-300">
                        <div className="flex items-start gap-2">
                          <span className="text-[#00f0ff] font-bold">◎</span>
                          <div>
                            <strong className="text-[#00f0ff] font-sans">（重新演练）</strong>：一键还原当前关卡到初始字节状态，方便重新演练和学习全套变换流程。
                          </div>
                        </div>
                        <div className="flex items-start gap-2">
                          <span className="text-[#00f0ff] font-bold">◎</span>
                          <div>
                            <strong className="text-[#00f0ff] font-sans">（下一节点）</strong>：成功演示完成后，点击可进驻下一个关卡，验证不同的明文与密钥转换效果。
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  // ENGLISH GUIDE
                  <div className="space-y-6">
                    {/* Section 1 */}
                    <div className="space-y-2">
                      <h4 className="text-[#00f0ff] font-bold text-sm md:text-base select-none">
                        1. What is AES-128 Symmetric Cipher?
                      </h4>
                      <p className="text-slate-300 leading-relaxed">
                        AES-128 is a classical <strong className="text-white font-semibold underline decoration-[#00f0ff]/30">multi-round block symmetric encryption algorithm</strong>. It iteratively transforms a 4x4 data byte matrix using round subkeys, applying substitutions and diffusions to ensure impenetrable cryptographic protection.
                      </p>
                    </div>

                    {/* Section 2 */}
                    <div className="space-y-3">
                      <h4 className="text-[#ec4899] font-bold text-sm md:text-base select-none">
                        2. Matrix Transformation & Alignment Rules
                      </h4>
                      <ul className="space-y-3 list-none pl-0">
                        <li className="relative pl-4">
                          <span className="absolute left-0 top-1.5 w-1.5 h-1.5 rounded-full bg-[#ec4899]" />
                          <strong className="text-[#00f0ff]">Byte Substitution (SubBytes) = S-Box Mapping:</strong> Click individual data tiles within the matrix to perform non-linear mapping. Processed tiles will light up with green borders.
                        </li>
                        <li className="relative pl-4">
                          <span className="absolute left-0 top-1.5 w-1.5 h-1.5 rounded-full bg-[#ec4899]" />
                          <strong className="text-[#ec4899]">Row Permutation (ShiftRows) = Circular Shift:</strong> Click the <b>[◀] / [▶]</b> arrow buttons beside each row to shift blocks horizontally until they align perfectly (Rows 1, 2, and 3 are shifted left by 1, 2, and 3 offsets respectively).
                        </li>
                        <li className="relative pl-4">
                          <span className="absolute left-0 top-1.5 w-1.5 h-1.5 rounded-full bg-[#ec4899]" />
                          <strong className="text-[#00f0ff]">Column Mixing (MixColumns) = Galois Field Multiply:</strong> Click the <b>[MIX]</b> buttons below each column to run polynomial multiplications. Even a single byte variation will completely diffuse across the entire column (Avalanche Effect).
                        </li>
                        <li className="relative pl-4">
                          <span className="absolute left-0 top-1.5 w-1.5 h-1.5 rounded-full bg-[#ec4899]" />
                          <strong className="text-[#ec4899]">Key Overlay (AddRoundKey) = Bitwise XOR:</strong> Drag the floating Round Key Spirits (W[r] Vectors) and place them precisely into their column lock slots. Snapping all keys triggers the final bitwise XOR operation.
                        </li>
                      </ul>
                    </div>

                    {/* Section 3 */}
                    <div className="space-y-3">
                      <h4 className="text-[#00f0ff] font-bold text-sm md:text-base select-none">
                        3. Interactive Controls & Buttons
                      </h4>
                      <div className="bg-[#0b132b]/80 p-4 rounded-xl border border-[#00f0ff]/15 space-y-3 font-mono text-xs text-slate-300">
                        <div className="flex items-start gap-2">
                          <span className="text-[#00f0ff] font-bold">◎</span>
                          <div>
                            <strong className="text-[#00f0ff] font-sans">(Replay)</strong>: Reverts all matrix progress in the active mission, letting you practice the block transforms from the very beginning.
                          </div>
                        </div>
                        <div className="flex items-start gap-2">
                          <span className="text-[#00f0ff] font-bold">◎</span>
                          <div>
                            <strong className="text-[#00f0ff] font-sans">(Next Node)</strong>: After a successful encryption run, advance to the next level to experiment with a new plaintext/key combination.
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* MODAL FOOTER */}
              <div className="px-6 py-4 flex justify-end items-center border-t border-[#112240] shrink-0 bg-[#061022]">
                <button
                  onClick={handleToggleHelp}
                  className="px-6 py-2.5 bg-[#00f0ff] hover:bg-[#39f3ff] text-[#020c1b] font-bold font-mono text-xs rounded-xl transition-all cursor-pointer active:scale-95"
                >
                  {helpLanguage === "ZH" ? "开始演练" : "Launch Tutorial"}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* DETAILED VICTORY POPUP OVERLAY */}
      <AnimatePresence>
        {isVictoryOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-[#020c1b]/90 backdrop-blur-md flex items-center justify-center p-4 z-50"
          >
            <motion.div
              initial={{ scale: 0.9, y: 25 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 25 }}
              className="bg-[#0a192f] border-2 border-[#64ffda] rounded-2xl max-w-xs w-full text-center overflow-hidden shadow-[0_0_35px_rgba(100,255,218,0.25)] relative"
            >
              <div className="absolute top-0 left-0 right-0 h-1.5 bg-[#64ffda] shadow-[0_0_15px_#64ffda]" />
              
              <div className="p-8 flex flex-col items-center">
                {/* Glowing Checkmark Icon */}
                <div className="w-16 h-16 bg-[#64ffda]/10 border-2 border-[#64ffda] rounded-full flex items-center justify-center shadow-[0_0_20px_rgba(100,255,218,0.25)] mb-8">
                  <CheckCircle2 className="w-9 h-9 text-[#64ffda]" />
                </div>

                {/* Replay & Next Buttons */}
                <div className="flex flex-row gap-4 w-full">
                  <button
                    onClick={handleRestartLevel}
                    className="flex-1 py-3 bg-[#112240] hover:bg-[#112240]/80 text-white border border-[#64ffda]/30 hover:border-[#64ffda]/60 rounded-xl transition-all cursor-pointer flex items-center justify-center active:scale-95"
                    title="重新演练 / Replay"
                  >
                    <RefreshCw className="w-4 h-4 text-[#64ffda]" />
                  </button>
                  <button
                    onClick={() => {
                      handlePlaySound("click");
                      const nextIdx = (activeLevelIdx + 1) % AES_LEVELS.length;
                      setActiveLevelIdx(nextIdx);
                    }}
                    className="flex-1 py-3 bg-[#64ffda] hover:bg-[#52d1b2] text-[#020c1b] rounded-xl transition-all cursor-pointer flex items-center justify-center active:scale-95"
                    title="下一节点 / Next Level"
                  >
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
