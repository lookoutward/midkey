<script setup>
import { ref } from 'vue'
import { 
  Home as HomeIcon, 
  BarChart2 as BarChartIcon, 
  Wrench as WrenchIcon, 
  User as UserIcon, 
  ShieldCheck
} from 'lucide-vue-next'

// Import Pages
import Home from './pages/cn/Home.vue'
import Tools from './pages/cn/Tools.vue'
import Report from './pages/cn/Report.vue'
import About from './pages/cn/About.vue'

// Navigation state
const activeTab = ref('/cn/product')
const lang = ref('cn')

const navItems = {
  cn: [
    { name: '首页', path: '/cn/product', icon: HomeIcon },
    { name: '工具', path: '/cn/tool', icon: WrenchIcon },
    { name: '分析', path: '/cn/report', icon: BarChartIcon },
    { name: '关于', path: '/cn/about', icon: UserIcon },
  ],
  en: [
    { name: 'Home', path: '/en/product', icon: HomeIcon },
    { name: 'Tools', path: '/en/tool', icon: WrenchIcon },
    { name: 'Analysis', path: '/en/report', icon: BarChartIcon },
    { name: 'About', path: '/en/about', icon: UserIcon },
  ]
}

const features = [
  { title: 'AES-256-GCM', id: 'aesgcm' },
  { title: 'AES-256-CBC', id: 'aescbc' },
  { title: 'RSA-2048', id: 'rsa' },
  { title: 'RSA-2048-Signature', id: 'sign' },
  { title: 'SHA-256', id: 'hash' },
  { title: 'HMAC-SHA-256', id: 'hmac' },
  { title: 'DH-Key-Exchange', id: 'dhke' },
]

const analysisFeatures = [
  { title: '为什么密码管理至关重要？', url: 'https://mp.weixin.qq.com/s/FNOqjkXIig8s6hRSawzpXg' },
  { title: '信息安全观察-2025年漏洞报告', url: 'https://mp.weixin.qq.com/s/y1PFqARLn17RRCnCJ8jwdg' },
  { title: '信息安全进化史', url: 'https://mp.weixin.qq.com/s/Cot2AiOlaYnB4t22lAq3lw' },
  { title: '《AI进化史》', url: 'https://mp.weixin.qq.com/s/gy3csHC_UfcULi_cBBeimg' },
  { title: '物联网安全漏洞模拟演示', url: 'https://mp.weixin.qq.com/s/npHpakp9ZEi3gzUlG87_0w' },
  { title: '索尼影业被黑事件解析', url: 'https://mp.weixin.qq.com/s/W1emAxTglYpRzL2xkOO1ww' },
  { title: '供应链攻击模拟演示', url: 'https://mp.weixin.qq.com/s/RuSHAxvcdjpNrls60z_m7g' },
  { title: 'DDoS攻击模拟演示', url: 'https://mp.weixin.qq.com/s/eZj9ARpgVoUA7lr6tJMcSw' },
  { title: '勒索软件模拟演示', url: 'https://mp.weixin.qq.com/s/0WNxEh2wcdmC2Bv7zRhRyQ' },
  { title: 'AI推理引擎漏洞链《ShadowMQ》解析', url: 'https://mp.weixin.qq.com/s/5wog7W_lyWnM6xVm2FP0-A' },
  { title: 'Stuxnet第一次网络战争解析', url: 'https://mp.weixin.qq.com/s/hcL3SGgMeo2xaEA02xMxVg' },
  { title: '信息安全观察2024年', url: 'https://mp.weixin.qq.com/s/d49M2RxQzcgCas59uI8Rhg' },
]

const switchTab = (path) => {
  activeTab.value = path
  if (path.startsWith('/en/')) lang.value = 'en'
  else if (path.startsWith('/cn/')) lang.value = 'cn'
}

const toggleLang = () => {
  if (lang.value === 'cn') {
    lang.value = 'en'
    activeTab.value = activeTab.value.replace('/cn/', '/en/')
  } else {
    lang.value = 'cn'
    activeTab.value = activeTab.value.replace('/en/', '/cn/')
  }
}

// Toast Logic
const toastMessage = ref('')
const showToast = ref(false)

const displayToast = (msg) => {
  toastMessage.value = msg
  showToast.value = true
  setTimeout(() => {
    showToast.value = false
  }, 2000)
}
</script>

<template>
  <div class="min-h-screen bg-[#f7f8fa] text-gray-900 font-sans antialiased">
    
    <!-- Desktop Top Navigation -->
    <nav class="hidden md:flex fixed top-0 left-0 right-0 h-16 bg-white border-b border-gray-100 z-50 items-center justify-between px-8 shadow-sm">
      <div class="flex items-center gap-2">
        <img src="../public/logo.jpg" alt="Midkey Logo" class="w-8 h-8 rounded-lg object-cover" referrerPolicy="no-referrer" />
        <span class="font-bold text-lg text-gray-900">Midkey</span>
      </div>
      <div class="flex gap-8">
        <button
          v-for="item in navItems[lang]"
          :key="item.path"
          @click="switchTab(item.path)"
          :class="[
            'flex items-center gap-2 text-sm font-medium transition-colors hover:text-blue-600 cursor-pointer',
            activeTab === item.path ? 'text-blue-600' : 'text-gray-500'
          ]"
        >
          <component :is="item.icon" :size="18" />
          {{ item.name }}
        </button>
      </div>
      <div class="w-32" />
    </nav>

    <!-- Mobile Bottom Navigation -->
    <nav class="md:hidden fixed bottom-0 left-0 right-0 h-16 bg-white border-t border-gray-100 z-50 flex items-center justify-around px-2 shadow-[0_-2px_10px_rgba(0,0,0,0.05)]">
      <button
        v-for="item in navItems[lang]"
        :key="item.path"
        @click="switchTab(item.path)"
        :class="[
          'flex flex-col items-center justify-center gap-1 flex-1 h-full transition-colors cursor-pointer',
          activeTab === item.path ? 'text-blue-600' : 'text-gray-400'
        ]"
      >
        <component :is="item.icon" :size="22" />
        <span class="text-[10px] font-medium">{{ item.name }}</span>
      </button>
    </nav>

    <!-- Main Content Area -->
    <main class="md:pt-16 pb-24 md:pb-12">
      <!-- CN Pages -->
      <template v-if="lang === 'cn'">
        <Home v-if="activeTab === '/cn/product'" />
        <Tools v-else-if="activeTab === '/cn/tool'" :features="features" :displayToast="displayToast" />
        <Report v-else-if="activeTab === '/cn/report'" :analysisFeatures="analysisFeatures" />
        <About v-else-if="activeTab === '/cn/about'" />
      </template>

      <!-- EN Pages -->
      <template v-else-if="lang === 'en'">
        <div v-if="activeTab === '/en/product'" class="max-w-4xl mx-auto px-4 py-20 text-center">
          <h1 class="text-3xl font-bold text-gray-900 mb-4">Home (English)</h1>
          <p class="text-gray-500">Coming soon...</p>
        </div>
        <div v-else-if="activeTab === '/en/tool'" class="max-w-4xl mx-auto px-4 py-20 text-center">
          <h1 class="text-3xl font-bold text-gray-900 mb-4">Tools (English)</h1>
          <p class="text-gray-500">Coming soon...</p>
        </div>
        <div v-else-if="activeTab === '/en/report'" class="max-w-4xl mx-auto px-4 py-20 text-center">
          <h1 class="text-3xl font-bold text-gray-900 mb-4">Analysis (English)</h1>
          <p class="text-gray-500">Coming soon...</p>
        </div>
        <div v-else-if="activeTab === '/en/about'" class="max-w-4xl mx-auto px-4 py-20 text-center">
          <h1 class="text-3xl font-bold text-gray-900 mb-4">About (English)</h1>
          <p class="text-gray-500">Coming soon...</p>
        </div>
      </template>
      
      <!-- Fallback -->
      <div v-else class="max-w-4xl mx-auto px-4 py-20 text-center">
        <h1 class="text-3xl font-bold text-gray-900 mb-4">
          {{ navItems[lang]?.find(i => i.path === activeTab)?.name }}
        </h1>
        <p class="text-gray-500">页面开发中，敬请期待...</p>
      </div>

      <!-- Browser Recommendation -->
      <div class="mt-12 mb-8 text-center">
        <p class="text-xs text-gray-400 font-medium">
          {{ lang === 'cn' ? '推荐浏览器：Chrome / Edge' : 'Recommended Browser: Chrome / Edge' }}
        </p>
      </div>
    </main>

    <!-- Global Toast -->
    <transition name="fade">
      <div v-if="showToast" class="fixed top-20 left-1/2 -translate-x-1/2 z-[100] px-4 py-2 bg-gray-900 text-white text-sm rounded-full shadow-xl flex items-center gap-2">
        <ShieldCheck :size="16" class="text-green-400" />
        {{ toastMessage }}
      </div>
    </transition>
  </div>
</template>

<style>
.fade-enter-active, .fade-leave-active {
  transition: opacity 0.3s, transform 0.3s;
}
.fade-enter-from, .fade-leave-to {
  opacity: 0;
  transform: translate(-50%, -10px);
}
</style>
