<template>
  <div class="max-w-4xl mx-auto px-4 py-20 text-center">
    <h1 class="text-3xl font-bold text-gray-900 mb-4">Home (English)</h1>
    <p class="text-gray-500">Coming soon...</p>
  </div>
</template>
