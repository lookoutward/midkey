<script setup>
import { MessageCircle, ExternalLink } from 'lucide-vue-next'
</script>

<template>
  <div class="max-w-4xl mx-auto px-4 py-6 md:py-12">
    <div class="md:hidden mb-6 text-center">
      <h1 class="text-lg font-bold text-gray-900">首页</h1>
    </div>

    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
      <div class="p-6 md:p-10">
        <header class="mb-8">
          <h2 class="text-xl md:text-2xl font-bold text-gray-900 mb-2">
            Midkey Vault｜离线密码管理器
          </h2>
          <p class="text-gray-500 text-sm md:text-base">
            把密码真正留在自己手里，简单、安全、完全离线的密码管理方案
          </p>
        </header>

        <div class="space-y-6 text-gray-700 leading-relaxed">
          <p>在使用各种网站和在线服务时，我们每天都会创建新的账号与密码。但一个核心问题往往被忽略：这些密码最终由谁掌控？</p>
          <p>Midkey Vault 提供一种简单而清晰的答案：密码与密钥，应该由用户自己掌控。</p>
          <p>Midkey Vault是一款离线优先的密码管理工具。所有数据存储在本地加密数据库中，通过主密码进行保护。系统不依赖云端服务，也不会自动上传或同步任何数据。</p>
          <p>用户只需记住一个主密码，即可解锁整个密码库。在未解锁时，所有数据均以加密形式存储。</p>

          <hr class="border-gray-100" />

          <!-- Pricing Comparison Grid -->
          <div class="grid grid-cols-1 md:grid-cols-2 gap-8 items-stretch">
            <!-- Free Version -->
            <section class="flex flex-col h-full">
              <h3 class="text-lg font-bold text-gray-900 mb-3 flex items-center gap-2">
                <span class="w-2 h-6 bg-green-500 rounded-full" />
                基础版（Free）
              </h3>
              <p class="mb-4 text-gray-600 text-sm">基础版提供完整的离线密码管理功能，适合大多数个人用户。</p>
              <div class="flex-1 bg-gray-50 p-5 rounded-xl border border-gray-100 flex flex-col">
                <ul class="space-y-2 text-sm flex-1">
                  <li class="flex items-start gap-2"><span class="text-green-600 font-bold">•</span><span>本地加密密码库（JSON 文件）</span></li>
                  <li class="flex items-start gap-2"><span class="text-green-600 font-bold">•</span><span>主密码保护</span></li>
                  <li class="flex items-start gap-2"><span class="text-green-600 font-bold">•</span><span>PBKDF2 密钥派生</span></li>
                  <li class="flex items-start gap-2"><span class="text-green-600 font-bold">•</span><span>分组管理</span></li>
                  <li class="flex items-start gap-2"><span class="text-green-600 font-bold">•</span><span>自定义字段</span></li>
                  <li class="flex items-start gap-2"><span class="text-green-600 font-bold">•</span><span>API Key / Secret 信息存储</span></li>
                  <li class="flex items-start gap-2"><span class="text-green-600 font-bold">•</span><span>浏览器本地解密</span></li>
                  <li class="flex items-start gap-2"><span class="text-green-600 font-bold">•</span><span>完全离线运行</span></li>
                </ul>
                <div class="mt-6 pt-6 border-t border-gray-200">
                  <a 
                    href="https://www.midkey.xyz/cn/vault" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    class="flex items-center justify-center gap-2 w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-xl transition-all shadow-md shadow-blue-100 active:scale-[0.98] text-sm"
                  >
                    <ExternalLink :size="18" />
                    立即免费使用 Midkey Vault
                  </a>
                </div>
              </div>
            </section>

            <!-- Pro Version -->
            <section class="flex flex-col h-full">
              <h3 class="text-lg font-bold text-gray-900 mb-3 flex items-center gap-2">
                <span class="w-2 h-6 bg-blue-600 rounded-full" />
                专业版（Pro）
              </h3>
              <p class="mb-4 text-gray-600 text-sm">专业版在基础功能之上增加高级管理能力：</p>
              <div class="flex-1 bg-blue-50/30 p-5 rounded-xl border border-blue-100 flex flex-col">
                <div class="flex-1 space-y-2 text-sm">
                  <p class="flex items-start gap-2"><span class="text-blue-600 font-bold">•</span><span>附件加密存储（证书、密钥文件、笔记等）</span></p>
                  <p class="flex items-start gap-2"><span class="text-blue-600 font-bold">•</span><span>密码历史记录（查看密码修改历史）</span></p>
                  <p class="flex items-start gap-2"><span class="text-blue-600 font-bold">•</span><span>多库管理：最多 3 个 Vault</span></p>
                  <p class="flex items-start gap-2"><span class="text-blue-600 font-bold">•</span><span>授权码有效期：购买周期结束后自动失效</span></p>
                </div>
                <div class="mt-6 pt-6 border-t border-blue-100">
                  <p class="text-xl font-bold text-blue-700">120 元 / 年</p>
                  <p class="mt-2 text-xs text-blue-500 leading-relaxed">
                    如需使用 Pro 专业版，请直接通过微信联系我们获取授权。专业版不支持在线购买或自动开通。
                  </p>
                </div>
              </div>
            </section>
          </div>
        </div>

        <!-- 免费咨询卡片 -->
        <div class="mt-12 bg-blue-50 border border-blue-100 rounded-2xl p-6 flex flex-col md:flex-row gap-6 items-center">
          <div class="flex-1 text-center md:text-left">
            <h4 class="font-bold text-blue-900 mb-2 flex items-center justify-center md:justify-start gap-2">
              <MessageCircle :size="20" />
              免费咨询
            </h4>
            <p class="text-blue-800 text-sm leading-relaxed">
              提供一对一指导，包括个人密钥管理方案讲解、配置与备份实践、常见误区与风险边界说明，以及个性化长期维护建议。
            </p>
          </div>
          <div class="bg-white px-6 py-3 rounded-xl shadow-sm border border-blue-200 w-full md:w-auto text-center">
            <span class="text-xs text-blue-500 block mb-1 uppercase tracking-wider font-bold">微信联系方式</span>
            <span class="text-lg font-mono font-bold text-blue-900">midkeyxyz</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
