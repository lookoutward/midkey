<script setup>
import { MessageCircle } from 'lucide-vue-next'
</script>

<template>
  <div class="max-w-4xl mx-auto px-4 py-6 md:py-12">
    <div class="md:hidden mb-6 text-center">
      <h1 class="text-lg font-bold text-gray-900">关于 Midkey</h1>
    </div>

    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
      <div class="p-6 md:p-10">
        <header class="mb-8">
          <h2 class="text-xl md:text-2xl font-bold text-gray-900 mb-2">
            Midkey: 解密信息安全
          </h2>
          <div class="h-1 w-12 bg-blue-600 rounded-full" />
        </header>

        <div class="space-y-6 text-gray-700 leading-relaxed">
          <p>
            Midkey 致力于构建清晰、可控的个人信息安全实践框架，围绕个人密钥管理、轻量工具支持与安全分析三类能力展开。
          </p>
          <p>
            在密钥管理方面，Midkey 当前重点关注离线优先的个人使用场景，通过明确的使用方式与风险边界设计，帮助用户管理高敏感密码与密钥信息，降低长期暴露、集中存储与单点失效带来的系统性风险。
          </p>
          <p>
            工具板块强调克制与辅助，围绕加密、校验与基础安全计算等高频需求，提供轻量、可验证的工具支持，用于安全验证与辅助判断，而非替代专业安全系统或企业级防护方案。
          </p>
          <p>
            分析板块基于真实漏洞数据与安全事件，对风险形成路径进行结构化拆解，帮助用户理解安全问题的成因、传播机制与演化趋势，从个体视角建立对安全风险的长期认知框架。
          </p>
          <p class="font-medium text-gray-900">
            Midkey 关注的不是单点防护能力，而是一个更基础的问题：风险是如何形成的，以及个体应当如何建立稳定、长期、可迁移的安全判断能力。
          </p>

          <hr class="border-gray-100 my-8" />

          <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div class="flex items-center gap-3 text-gray-900">
              <div class="w-10 h-10 bg-green-50 rounded-full flex items-center justify-center text-green-600">
                <MessageCircle :size="20" />
              </div>
              <div>
                <p class="text-xs text-gray-500 uppercase font-bold tracking-wider">WeChat 联系方式</p>
                <p class="font-mono font-bold">midkeyxyz</p>
              </div>
            </div>
            
            <div class="text-right">
              <p class="text-gray-400 text-sm">Version: v2.3 (2026-01)</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
