<script setup>
import { ref } from 'vue'
import { JSEncrypt } from 'jsencrypt'
import CryptoJS from 'crypto-js'
import { sha3_256 } from 'js-sha3'
import BN from 'bn.js'
import { 
  Wrench, 
  ExternalLink, 
  ChevronLeft,
  Copy,
  Lock,
  Unlock,
  ShieldCheck,
  Info
} from 'lucide-vue-next'

const props = defineProps({
  features: {
    type: Array,
    required: true
  },
  displayToast: {
    type: Function,
    required: true
  }
})

const selectedTool = ref(null)

const openTool = (toolId) => {
  selectedTool.value = toolId
}

const closeTool = () => {
  selectedTool.value = null
}

// AES-256-GCM Logic
const plaintext = ref('')
const cryptoKey = ref('')
const ciphertext = ref('')

const toBase64 = (buffer) => btoa(String.fromCharCode(...new Uint8Array(buffer)))
const fromBase64 = (b64) => Uint8Array.from(atob(b64), c => c.charCodeAt(0))

async function deriveKey(password) {
  const encoder = new TextEncoder()
  const data = encoder.encode(password)
  const hash = await crypto.subtle.digest('SHA-256', data)
  return await crypto.subtle.importKey('raw', hash, 'AES-GCM', false, ['encrypt', 'decrypt'])
}

async function encryptGCM() {
  if (!cryptoKey.value) return props.displayToast('请输入密钥')
  try {
    const keyObj = await deriveKey(cryptoKey.value)
    const iv = crypto.getRandomValues(new Uint8Array(12))
    const encoded = new TextEncoder().encode(plaintext.value)
    const encrypted = await crypto.subtle.encrypt(
      { name: 'AES-GCM', iv },
      keyObj,
      encoded
    )
    const combined = new Uint8Array(iv.length + encrypted.byteLength)
    combined.set(iv)
    combined.set(new Uint8Array(encrypted), iv.length)
    ciphertext.value = toBase64(combined.buffer)
    props.displayToast('加密成功！')
  } catch (e) {
    props.displayToast('加密失败')
    console.error(e)
  }
}

async function decryptGCM() {
  if (!cryptoKey.value) return props.displayToast('请输入密钥')
  try {
    const keyObj = await deriveKey(cryptoKey.value)
    const data = fromBase64(ciphertext.value)
    const iv = data.slice(0, 12)
    const encrypted = data.slice(12)
    const decryptedBuffer = await crypto.subtle.decrypt(
      { name: 'AES-GCM', iv },
      keyObj,
      encrypted
    )
    plaintext.value = new TextDecoder().decode(decryptedBuffer)
    props.displayToast('解密成功！')
  } catch (e) {
    props.displayToast('解密失败')
    console.error(e)
  }
}

// AES-256-CBC Logic
const cbcPlaintext = ref('')
const cbcKey = ref('')
const cbcCiphertext = ref('')

function encryptCBC() {
  if (!cbcKey.value) return props.displayToast('请输入密钥')
  try {
    const encrypted = CryptoJS.AES.encrypt(cbcPlaintext.value, cbcKey.value, { keySize: 256 / 32 }).toString()
    cbcCiphertext.value = encrypted
    props.displayToast('加密成功！')
  } catch (e) {
    props.displayToast('加密失败')
    console.error(e)
  }
}

function decryptCBC() {
  if (!cbcKey.value) return props.displayToast('请输入密钥')
  try {
    const bytes = CryptoJS.AES.decrypt(cbcCiphertext.value, cbcKey.value, { keySize: 256 / 32 })
    const decrypted = bytes.toString(CryptoJS.enc.Utf8)
    if (!decrypted) throw new Error('Decryption failed')
    cbcPlaintext.value = decrypted
    props.displayToast('解密成功！')
  } catch (e) {
    props.displayToast('解密失败，请检查密钥或密文')
    console.error(e)
  }
}

const copyToClipboard = (text) => {
  if (!text) return
  navigator.clipboard.writeText(text).then(() => {
    props.displayToast('已复制到剪贴板')
  })
}

// RSA-2048 Logic
const rsaPlaintext = ref('')
const rsaKeyInput = ref('')
const rsaCiphertext = ref('')
const rsaPrivateKey = ref('')
const rsaPublicKey = ref('')

function generateKeyPair() {
  const crypt = new JSEncrypt({ default_key_size: 2048 })
  crypt.getKey()
  rsaPublicKey.value = crypt.getPublicKey()
  rsaPrivateKey.value = crypt.getPrivateKey()
  props.displayToast('密钥对生成成功！')
}

function encryptRSA() {
  if (!rsaKeyInput.value) return props.displayToast('请输入公钥')
  const encrypt = new JSEncrypt()
  encrypt.setPublicKey(rsaKeyInput.value)
  const result = encrypt.encrypt(rsaPlaintext.value)
  if (result) {
    rsaCiphertext.value = result
    props.displayToast('加密成功！')
  } else {
    props.displayToast('加密失败，请检查公钥')
  }
}

function decryptRSA() {
  if (!rsaKeyInput.value) return props.displayToast('请输入私钥')
  const decrypt = new JSEncrypt()
  decrypt.setPrivateKey(rsaKeyInput.value)
  const result = decrypt.decrypt(rsaCiphertext.value)
  if (result) {
    rsaPlaintext.value = result
    props.displayToast('解密成功！')
  } else {
    props.displayToast('解密失败，请检查私钥或密文')
  }
}

// RSA-2048-Signature Logic
const sigPlaintext = ref('')
const sigSignature = ref('')
const sigPrivateKey = ref('')
const sigPublicKey = ref('')

function generateSigKeyPair() {
  const crypt = new JSEncrypt({ default_key_size: 2048 })
  crypt.getKey()
  sigPublicKey.value = crypt.getPublicKey()
  sigPrivateKey.value = crypt.getPrivateKey()
  props.displayToast('密钥对生成成功！')
}

function signRSA() {
  if (!sigPrivateKey.value) return props.displayToast('请输入私钥')
  const encrypt = new JSEncrypt()
  encrypt.setPrivateKey(sigPrivateKey.value.trim())
  const hash = CryptoJS.SHA256(sigPlaintext.value).toString()
  const result = encrypt.sign(hash, CryptoJS.SHA256, 'sha256')
  if (result) {
    sigSignature.value = result
    props.displayToast('签名成功！')
  } else {
    props.displayToast('签名失败')
  }
}

function verifyRSA() {
  if (!sigPublicKey.value) return props.displayToast('请输入公钥')
  const encrypt = new JSEncrypt()
  encrypt.setPublicKey(sigPublicKey.value.trim())
  const hash = CryptoJS.SHA256(sigPlaintext.value).toString()
  const isValid = encrypt.verify(hash, sigSignature.value, CryptoJS.SHA256)
  props.displayToast(isValid ? '签名验证成功！' : '签名验证失败')
}

// SHA-256 Logic
const hashInput = ref('')
const hashSalt = ref('')
const hashResult = ref('')

function calculateHash() {
  const inputAndSalt = hashInput.value.trim() + hashSalt.value.trim()
  hashResult.value = CryptoJS.SHA256(inputAndSalt).toString()
  props.displayToast('哈希计算成功！')
}

// HMAC-SHA-256 Logic
const hmacKey = ref('')
const hmacMessage = ref('')
const hmacResult = ref('')

function calculateHMAC() {
  if (!hmacKey.value.trim() || !hmacMessage.value.trim()) {
    return props.displayToast('请输入密钥和消息')
  }
  hmacResult.value = CryptoJS.HmacSHA256(hmacMessage.value.trim(), hmacKey.value.trim()).toString(CryptoJS.enc.Hex)
  props.displayToast('HMAC 计算成功！')
}

// Diffie–Hellman Key Exchange Logic
const dhPrivateKeyA = ref('')
const dhPublicKeyA = ref('')
const dhPublicKeyB = ref('')
const dhSharedSecret = ref('')
const p = new BN('114179812305190573251285406962627163971195067122210512231600037100200647772758065447574577201147959')
const g = new BN('2')

function generateDHKeys() {
  const a = new BN(crypto.getRandomValues(new Uint8Array(32)), 'hex')
  const A = g.toRed(BN.red(p)).redPow(a)
  dhPrivateKeyA.value = a.toString('hex')
  dhPublicKeyA.value = A.toString('hex')
  props.displayToast('DH 密钥对生成成功！')
}

function calculateDHSharedSecret() {
  if (!dhPrivateKeyA.value || !dhPublicKeyB.value) {
    return props.displayToast('请输入私钥和对方公钥')
  }
  try {
    const a = new BN(dhPrivateKeyA.value, 'hex')
    const B = new BN(dhPublicKeyB.value, 'hex')
    const sharedKey = B.toRed(BN.red(p)).redPow(a).fromRed()
    dhSharedSecret.value = sharedKey.toString('hex')
    props.displayToast('共享密钥计算成功！')
  } catch (e) {
    props.displayToast('计算失败，请检查输入格式')
  }
}
</script>

<template>
  <div class="max-w-4xl mx-auto px-4 py-6 md:py-12">
    <!-- Tool List View -->
    <template v-if="!selectedTool">
      <div class="md:hidden mb-6 text-center">
        <h1 class="text-lg font-bold text-gray-900">工具</h1>
      </div>

      <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="divide-y divide-gray-50">
          <div 
            v-for="(item, index) in features" 
            :key="index"
            @click="openTool(item.id)"
            class="group flex items-center justify-between p-5 hover:bg-gray-50 transition-colors cursor-pointer"
          >
            <div class="flex items-center gap-4">
              <div class="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-all">
                <Wrench :size="20" />
              </div>
              <span class="font-medium text-gray-900">{{ item.title }}</span>
            </div>
            <ExternalLink :size="18" class="text-gray-300 group-hover:text-blue-600 transition-colors" />
          </div>
        </div>
      </div>
      
      <div class="mt-8 text-center">
        <p class="text-xs text-gray-400">
          所有工具均在浏览器本地运行，不向服务器发送任何敏感数据。
        </p>
      </div>
    </template>

    <!-- AES-256-GCM Tool View -->
    <template v-else-if="selectedTool === 'aesgcm'">
      <div class="mb-6 flex items-center gap-4">
        <button @click="closeTool" class="p-2 hover:bg-white rounded-full transition-colors">
          <ChevronLeft :size="24" />
        </button>
        <h1 class="text-xl font-bold text-gray-900">AES-256-GCM</h1>
      </div>

      <div class="space-y-6">
        <!-- Input Area -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <div class="flex items-center justify-between mb-4">
            <label class="text-sm font-bold text-gray-500 uppercase tracking-wider">明文 (Plaintext)</label>
            <button @click="copyToClipboard(plaintext)" class="text-blue-600 hover:text-blue-700 flex items-center gap-1 text-sm font-medium">
              <Copy :size="14" /> 复制
            </button>
          </div>
          <textarea 
            v-model="plaintext"
            rows="4"
            class="w-full p-4 bg-gray-50 rounded-xl border-none focus:ring-2 focus:ring-blue-500 transition-all resize-none"
            placeholder="在此输入需要加密的文本..."
          ></textarea>
        </div>

        <!-- Key Area -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <label class="block text-sm font-bold text-gray-500 uppercase tracking-wider mb-4">密钥 (Key)</label>
          <div class="relative">
            <input 
              v-model="cryptoKey"
              type="text"
              class="w-full p-4 pl-12 bg-gray-50 rounded-xl border-none focus:ring-2 focus:ring-blue-500 transition-all"
              placeholder="输入任意字符串作为密钥..."
            />
            <ShieldCheck class="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" :size="20" />
          </div>
        </div>

        <!-- Action Buttons -->
        <div class="grid grid-cols-2 gap-4">
          <button 
            @click="encryptGCM"
            class="flex items-center justify-center gap-2 p-4 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-200 active:scale-95"
          >
            <Lock :size="20" /> 加密
          </button>
          <button 
            @click="decryptGCM"
            class="flex items-center justify-center gap-2 p-4 bg-white text-blue-600 border-2 border-blue-600 rounded-xl font-bold hover:bg-blue-50 transition-all active:scale-95"
          >
            <Unlock :size="20" /> 解密
          </button>
        </div>

        <!-- Output Area -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <div class="flex items-center justify-between mb-4">
            <label class="text-sm font-bold text-gray-500 uppercase tracking-wider">密文 (Ciphertext / Base64)</label>
            <button @click="copyToClipboard(ciphertext)" class="text-blue-600 hover:text-blue-700 flex items-center gap-1 text-sm font-medium">
              <Copy :size="14" /> 复制
            </button>
          </div>
          <textarea 
            v-model="ciphertext"
            rows="4"
            class="w-full p-4 bg-gray-50 rounded-xl border-none focus:ring-2 focus:ring-blue-500 transition-all font-mono text-sm break-all resize-none"
            placeholder="加密结果将显示在此处..."
          ></textarea>
        </div>

        <!-- Info Card -->
        <div class="bg-blue-50 rounded-2xl p-6 border border-blue-100">
          <div class="flex items-center gap-2 text-blue-800 font-bold mb-3">
            <Info :size="18" />
            <span>AES-256-GCM 技术说明</span>
          </div>
          <ul class="space-y-2 text-sm text-blue-700 leading-relaxed">
            <li class="flex gap-2">
              <span class="font-bold">01.</span>
              <span>可高效加密任意长度的数据。</span>
            </li>
            <li class="flex gap-2">
              <span class="font-bold">02.</span>
              <span>一步完成加密、认证和完整性验证。</span>
            </li>
            <li class="flex gap-2">
              <span class="font-bold">03.</span>
              <span>使用 96 位 (12 字节) 初始化向量 (IV) 确保唯一性。</span>
            </li>
            <li class="flex gap-2">
              <span class="font-bold">04.</span>
              <span>采用 256 位密钥实现强大的加密安全性。</span>
            </li>
          </ul>
        </div>
      </div>
    </template>

    <!-- RSA-2048 Tool View -->
    <template v-else-if="selectedTool === 'rsa'">
      <div class="mb-6 flex items-center gap-4">
        <button @click="closeTool" class="p-2 hover:bg-white rounded-full transition-colors">
          <ChevronLeft :size="24" />
        </button>
        <h1 class="text-xl font-bold text-gray-900">RSA-2048</h1>
      </div>

      <div class="space-y-6">
        <!-- Action Buttons (Top) -->
        <div class="grid grid-cols-2 gap-4">
          <button 
            @click="encryptRSA"
            class="flex items-center justify-center gap-2 p-4 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-200 active:scale-95"
          >
            <Lock :size="20" /> 公钥加密
          </button>
          <button 
            @click="decryptRSA"
            class="flex items-center justify-center gap-2 p-4 bg-white text-blue-600 border-2 border-blue-600 rounded-xl font-bold hover:bg-blue-50 transition-all active:scale-95"
          >
            <Unlock :size="20" /> 私钥解密
          </button>
        </div>

        <!-- Plaintext Area -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <div class="flex items-center justify-between mb-4">
            <label class="text-sm font-bold text-gray-500 uppercase tracking-wider">明文 (Plaintext)</label>
            <button @click="copyToClipboard(rsaPlaintext)" class="text-blue-600 hover:text-blue-700 flex items-center gap-1 text-sm font-medium">
              <Copy :size="14" /> 复制
            </button>
          </div>
          <textarea 
            v-model="rsaPlaintext"
            rows="3"
            maxlength="100"
            class="w-full p-4 bg-gray-50 rounded-xl border-none focus:ring-2 focus:ring-blue-500 transition-all resize-none"
            placeholder="在此输入明文 (最大 100 字符)..."
          ></textarea>
        </div>

        <!-- Key Input Area -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <label class="block text-sm font-bold text-gray-500 uppercase tracking-wider mb-4">密钥 (Key)</label>
          <textarea 
            v-model="rsaKeyInput"
            rows="4"
            class="w-full p-4 bg-gray-50 rounded-xl border-none focus:ring-2 focus:ring-blue-500 transition-all font-mono text-xs resize-none"
            placeholder="加密时输入公钥 / 解密时输入私钥..."
          ></textarea>
        </div>

        <!-- Ciphertext Area -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <div class="flex items-center justify-between mb-4">
            <label class="text-sm font-bold text-gray-500 uppercase tracking-wider">密文 (Ciphertext)</label>
            <button @click="copyToClipboard(rsaCiphertext)" class="text-blue-600 hover:text-blue-700 flex items-center gap-1 text-sm font-medium">
              <Copy :size="14" /> 复制
            </button>
          </div>
          <textarea 
            v-model="rsaCiphertext"
            rows="4"
            class="w-full p-4 bg-gray-50 rounded-xl border-none focus:ring-2 focus:ring-blue-500 transition-all font-mono text-xs break-all resize-none"
            placeholder="加密结果将显示在此处，或在此输入密文进行解密..."
          ></textarea>
        </div>

        <hr class="border-gray-100" />

        <!-- Key Generation Area -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <div class="flex items-center justify-between mb-6">
            <h3 class="font-bold text-gray-900">密钥对生成</h3>
            <button 
              @click="generateKeyPair"
              class="px-4 py-2 bg-gray-900 text-white rounded-lg text-sm font-bold hover:bg-gray-800 transition-all active:scale-95"
            >
              生成新密钥对
            </button>
          </div>
          
          <div class="space-y-4">
            <div>
              <div class="flex items-center justify-between mb-2">
                <label class="text-xs font-bold text-gray-400 uppercase">私钥 (Private Key)</label>
                <button @click="copyToClipboard(rsaPrivateKey)" class="text-blue-600 hover:text-blue-700 text-xs font-bold">复制</button>
              </div>
              <textarea 
                v-model="rsaPrivateKey"
                readonly
                rows="3"
                class="w-full p-3 bg-gray-50 rounded-lg border-none font-mono text-[10px] resize-none"
              ></textarea>
            </div>
            <div>
              <div class="flex items-center justify-between mb-2">
                <label class="text-xs font-bold text-gray-400 uppercase">公钥 (Public Key)</label>
                <button @click="copyToClipboard(rsaPublicKey)" class="text-blue-600 hover:text-blue-700 text-xs font-bold">复制</button>
              </div>
              <textarea 
                v-model="rsaPublicKey"
                readonly
                rows="3"
                class="w-full p-3 bg-gray-50 rounded-lg border-none font-mono text-[10px] resize-none"
              ></textarea>
            </div>
          </div>
        </div>

        <!-- Info Card -->
        <div class="bg-blue-50 rounded-2xl p-6 border border-blue-100">
          <div class="flex items-center gap-2 text-blue-800 font-bold mb-3">
            <Info :size="18" />
            <span>RSA-2048 技术说明</span>
          </div>
          <ul class="space-y-2 text-sm text-blue-700 leading-relaxed">
            <li class="flex gap-2">
              <span class="font-bold">01.</span>
              <span>用于加密敏感数据（如密钥）。</span>
            </li>
            <li class="flex gap-2">
              <span class="font-bold">02.</span>
              <span>非对称加密：私钥保密，公钥公开。他人用你的公钥加密数据，只有你能用私钥解密。</span>
            </li>
          </ul>
        </div>
      </div>
    </template>

    <!-- RSA-2048-Signature Tool View -->
    <template v-else-if="selectedTool === 'sign'">
      <div class="mb-6 flex items-center gap-4">
        <button @click="closeTool" class="p-2 hover:bg-white rounded-full transition-colors">
          <ChevronLeft :size="24" />
        </button>
        <h1 class="text-xl font-bold text-gray-900">RSA-2048-Signature</h1>
      </div>

      <div class="space-y-6">
        <!-- Action Buttons (Top) -->
        <div class="grid grid-cols-2 gap-4">
          <button 
            @click="signRSA"
            class="flex items-center justify-center gap-2 p-4 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-200 active:scale-95"
          >
            <Lock :size="20" /> 私钥签名
          </button>
          <button 
            @click="verifyRSA"
            class="flex items-center justify-center gap-2 p-4 bg-white text-blue-600 border-2 border-blue-600 rounded-xl font-bold hover:bg-blue-50 transition-all active:scale-95"
          >
            <ShieldCheck :size="20" /> 公钥验证
          </button>
        </div>

        <!-- Plaintext Area -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <div class="flex items-center justify-between mb-4">
            <label class="text-sm font-bold text-gray-500 uppercase tracking-wider">待签名内容 (Clear Text)</label>
            <button @click="copyToClipboard(sigPlaintext)" class="text-blue-600 hover:text-blue-700 flex items-center gap-1 text-sm font-medium">
              <Copy :size="14" /> 复制
            </button>
          </div>
          <textarea 
            v-model="sigPlaintext"
            rows="3"
            class="w-full p-4 bg-gray-50 rounded-xl border-none focus:ring-2 focus:ring-blue-500 transition-all resize-none"
            placeholder="在此输入需要签名的内容..."
          ></textarea>
        </div>

        <!-- Signature Result Area -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <div class="flex items-center justify-between mb-4">
            <label class="text-sm font-bold text-gray-500 uppercase tracking-wider">签名结果 (Signature Result)</label>
            <button @click="copyToClipboard(sigSignature)" class="text-blue-600 hover:text-blue-700 flex items-center gap-1 text-sm font-medium">
              <Copy :size="14" /> 复制
            </button>
          </div>
          <textarea 
            v-model="sigSignature"
            rows="4"
            class="w-full p-4 bg-gray-50 rounded-xl border-none focus:ring-2 focus:ring-blue-500 transition-all font-mono text-xs break-all resize-none"
            placeholder="签名结果将显示在此处..."
          ></textarea>
        </div>

        <hr class="border-gray-100" />

        <!-- Key Generation Area -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <div class="flex items-center justify-between mb-6">
            <h3 class="font-bold text-gray-900">密钥对生成</h3>
            <button 
              @click="generateSigKeyPair"
              class="px-4 py-2 bg-gray-900 text-white rounded-lg text-sm font-bold hover:bg-gray-800 transition-all active:scale-95"
            >
              生成新密钥对
            </button>
          </div>
          
          <div class="space-y-4">
            <div>
              <div class="flex items-center justify-between mb-2">
                <label class="text-xs font-bold text-gray-400 uppercase">私钥 (Private Key)</label>
                <button @click="copyToClipboard(sigPrivateKey)" class="text-blue-600 hover:text-blue-700 text-xs font-bold">复制</button>
              </div>
              <textarea 
                v-model="sigPrivateKey"
                rows="3"
                class="w-full p-3 bg-gray-50 rounded-lg border-none font-mono text-[10px] resize-none"
                placeholder="签名时需输入私钥..."
              ></textarea>
            </div>
            <div>
              <div class="flex items-center justify-between mb-2">
                <label class="text-xs font-bold text-gray-400 uppercase">公钥 (Public Key)</label>
                <button @click="copyToClipboard(sigPublicKey)" class="text-blue-600 hover:text-blue-700 text-xs font-bold">复制</button>
              </div>
              <textarea 
                v-model="sigPublicKey"
                rows="3"
                class="w-full p-3 bg-gray-50 rounded-lg border-none font-mono text-[10px] resize-none"
                placeholder="验证时需输入公钥..."
              ></textarea>
            </div>
          </div>
        </div>

        <!-- Info Card -->
        <div class="bg-blue-50 rounded-2xl p-6 border border-blue-100">
          <div class="flex items-center gap-2 text-blue-800 font-bold mb-3">
            <Info :size="18" />
            <span>RSA-2048-Signature 技术说明</span>
          </div>
          <ul class="space-y-2 text-sm text-blue-700 leading-relaxed">
            <li class="flex gap-2">
              <span class="font-bold">01.</span>
              <span>私钥签名：证明消息确实由你发送。</span>
            </li>
            <li class="flex gap-2">
              <span class="font-bold">02.</span>
              <span>公钥验证：任何人都可以用你的公钥验证消息的真实性。</span>
            </li>
          </ul>
        </div>
      </div>
    </template>

    <!-- SHA-256 Tool View -->
    <template v-else-if="selectedTool === 'hash'">
      <div class="mb-6 flex items-center gap-4">
        <button @click="closeTool" class="p-2 hover:bg-white rounded-full transition-colors">
          <ChevronLeft :size="24" />
        </button>
        <h1 class="text-xl font-bold text-gray-900">哈希 SHA-256</h1>
      </div>

      <div class="space-y-6">
        <!-- Input Area -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <label class="block text-sm font-bold text-gray-500 uppercase tracking-wider mb-4">输入文本 (Text)</label>
          <textarea 
            v-model="hashInput"
            rows="4"
            class="w-full p-4 bg-gray-50 rounded-xl border-none focus:ring-2 focus:ring-blue-500 transition-all resize-none"
            placeholder="在此输入需要计算哈希的文本..."
          ></textarea>
        </div>

        <!-- Salt Area -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <label class="block text-sm font-bold text-gray-500 uppercase tracking-wider mb-4">哈希盐值 (Hash Salt - 可选)</label>
          <input 
            v-model="hashSalt"
            type="text"
            class="w-full p-4 bg-gray-50 rounded-xl border-none focus:ring-2 focus:ring-blue-500 transition-all"
            placeholder="输入随机字符串作为盐值..."
          />
        </div>

        <!-- Action Button -->
        <button 
          @click="calculateHash"
          class="w-full flex items-center justify-center gap-2 p-4 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-200 active:scale-95"
        >
          <Wrench :size="20" /> 计算哈希
        </button>

        <!-- Result Area -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <div class="flex items-center justify-between mb-4">
            <label class="text-sm font-bold text-gray-500 uppercase tracking-wider">哈希值 (Hash Value)</label>
            <button @click="copyToClipboard(hashResult)" class="text-blue-600 hover:text-blue-700 flex items-center gap-1 text-sm font-medium">
              <Copy :size="14" /> 复制
            </button>
          </div>
          <textarea 
            v-model="hashResult"
            readonly
            rows="2"
            class="w-full p-4 bg-gray-50 rounded-xl border-none font-mono text-sm break-all resize-none"
            placeholder="哈希结果将显示在此处..."
          ></textarea>
        </div>

        <!-- Info Card -->
        <div class="bg-blue-50 rounded-2xl p-6 border border-blue-100">
          <div class="flex items-center gap-2 text-blue-800 font-bold mb-3">
            <Info :size="18" />
            <span>SHA-256 技术说明</span>
          </div>
          <ul class="space-y-2 text-sm text-blue-700 leading-relaxed">
            <li class="flex gap-2">
              <span class="font-bold">01.</span>
              <span>单向加密：将任意长度的文本转换为固定长度的字符串。</span>
            </li>
            <li class="flex gap-2">
              <span class="font-bold">02.</span>
              <span>完整性校验：内容哪怕只有微小改动，哈希值也会完全不同。</span>
            </li>
          </ul>
        </div>
      </div>
    </template>

    <!-- AES-256-CBC Tool View -->
    <template v-else-if="selectedTool === 'aescbc'">
      <div class="mb-6 flex items-center gap-4">
        <button @click="closeTool" class="p-2 hover:bg-white rounded-full transition-colors">
          <ChevronLeft :size="24" />
        </button>
        <h1 class="text-xl font-bold text-gray-900">AES-256-CBC</h1>
      </div>

      <div class="space-y-6">
        <!-- Input Area -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <div class="flex items-center justify-between mb-4">
            <label class="text-sm font-bold text-gray-500 uppercase tracking-wider">明文 (Plaintext)</label>
            <button @click="copyToClipboard(cbcPlaintext)" class="text-blue-600 hover:text-blue-700 flex items-center gap-1 text-sm font-medium">
              <Copy :size="14" /> 复制
            </button>
          </div>
          <textarea 
            v-model="cbcPlaintext"
            rows="4"
            class="w-full p-4 bg-gray-50 rounded-xl border-none focus:ring-2 focus:ring-blue-500 transition-all resize-none"
            placeholder="在此输入需要加密的文本..."
          ></textarea>
        </div>

        <!-- Key Area -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <label class="block text-sm font-bold text-gray-500 uppercase tracking-wider mb-4">密钥 (Key)</label>
          <div class="relative">
            <input 
              v-model="cbcKey"
              type="text"
              class="w-full p-4 pl-12 bg-gray-50 rounded-xl border-none focus:ring-2 focus:ring-blue-500 transition-all"
              placeholder="输入任意字符串作为密钥..."
            />
            <ShieldCheck class="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" :size="20" />
          </div>
        </div>

        <!-- Action Buttons -->
        <div class="grid grid-cols-2 gap-4">
          <button 
            @click="encryptCBC"
            class="flex items-center justify-center gap-2 p-4 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-200 active:scale-95"
          >
            <Lock :size="20" /> 加密
          </button>
          <button 
            @click="decryptCBC"
            class="flex items-center justify-center gap-2 p-4 bg-white text-blue-600 border-2 border-blue-600 rounded-xl font-bold hover:bg-blue-50 transition-all active:scale-95"
          >
            <Unlock :size="20" /> 解密
          </button>
        </div>

        <!-- Output Area -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <div class="flex items-center justify-between mb-4">
            <label class="text-sm font-bold text-gray-500 uppercase tracking-wider">密文 (Ciphertext / Base64)</label>
            <button @click="copyToClipboard(cbcCiphertext)" class="text-blue-600 hover:text-blue-700 flex items-center gap-1 text-sm font-medium">
              <Copy :size="14" /> 复制
            </button>
          </div>
          <textarea 
            v-model="cbcCiphertext"
            rows="4"
            class="w-full p-4 bg-gray-50 rounded-xl border-none focus:ring-2 focus:ring-blue-500 transition-all font-mono text-sm break-all resize-none"
            placeholder="加密结果将显示在此处..."
          ></textarea>
        </div>

        <!-- Info Card -->
        <div class="bg-blue-50 rounded-2xl p-6 border border-blue-100">
          <div class="flex items-center gap-2 text-blue-800 font-bold mb-3">
            <Info :size="18" />
            <span>AES-256-CBC 技术说明</span>
          </div>
          <ul class="space-y-2 text-sm text-blue-700 leading-relaxed">
            <li class="flex gap-2">
              <span class="font-bold">01.</span>
              <span>分组密码：将明文分成固定长度的块进行加密。</span>
            </li>
            <li class="flex gap-2">
              <span class="font-bold">02.</span>
              <span>链式模式：每个块的加密都依赖于前一个块的加密结果。</span>
            </li>
            <li class="flex gap-2">
              <span class="font-bold">03.</span>
              <span>初始化向量 (IV)：使用 128 位 (16 字节) IV 增加随机性。</span>
            </li>
          </ul>
        </div>
      </div>
    </template>
    <template v-else-if="selectedTool === 'hmac'">
      <div class="mb-6 flex items-center gap-4">
        <button @click="closeTool" class="p-2 hover:bg-white rounded-full transition-colors">
          <ChevronLeft :size="24" />
        </button>
        <h1 class="text-xl font-bold text-gray-900">HMAC-SHA-256</h1>
      </div>

      <div class="space-y-6">
        <!-- Key Area -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <label class="block text-sm font-bold text-gray-500 uppercase tracking-wider mb-4">密钥 (Key)</label>
          <textarea 
            v-model="hmacKey"
            rows="2"
            class="w-full p-4 bg-gray-50 rounded-xl border-none focus:ring-2 focus:ring-blue-500 transition-all resize-none"
            placeholder="输入密钥..."
          ></textarea>
        </div>

        <!-- Message Area -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <label class="block text-sm font-bold text-gray-500 uppercase tracking-wider mb-4">消息 (Message)</label>
          <textarea 
            v-model="hmacMessage"
            rows="4"
            class="w-full p-4 bg-gray-50 rounded-xl border-none focus:ring-2 focus:ring-blue-500 transition-all resize-none"
            placeholder="输入需要计算 HMAC 的消息..."
          ></textarea>
        </div>

        <!-- Action Button -->
        <button 
          @click="calculateHMAC"
          class="w-full flex items-center justify-center gap-2 p-4 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-200 active:scale-95"
        >
          <Wrench :size="20" /> 计算 HMAC
        </button>

        <!-- Result Area -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <div class="flex items-center justify-between mb-4">
            <label class="text-sm font-bold text-gray-500 uppercase tracking-wider">HMAC 值 (HMAC Value)</label>
            <button @click="copyToClipboard(hmacResult)" class="text-blue-600 hover:text-blue-700 flex items-center gap-1 text-sm font-medium">
              <Copy :size="14" /> 复制
            </button>
          </div>
          <textarea 
            v-model="hmacResult"
            readonly
            rows="2"
            class="w-full p-4 bg-gray-50 rounded-xl border-none font-mono text-sm break-all resize-none"
            placeholder="HMAC 结果将显示在此处..."
          ></textarea>
        </div>

        <!-- Info Card -->
        <div class="bg-blue-50 rounded-2xl p-6 border border-blue-100">
          <div class="flex items-center gap-2 text-blue-800 font-bold mb-3">
            <Info :size="18" />
            <span>HMAC-SHA-256 技术说明</span>
          </div>
          <ul class="space-y-2 text-sm text-blue-700 leading-relaxed">
            <li class="flex gap-2">
              <span class="font-bold">01.</span>
              <span>认证与完整性：同时验证消息的真实来源和完整性。</span>
            </li>
            <li class="flex gap-2">
              <span class="font-bold">02.</span>
              <span>API 安全：常用于 API 请求签名，确保请求在传输过程中未被篡改。</span>
            </li>
          </ul>
        </div>
      </div>
    </template>

    <!-- DH-Key-Exchange Tool View -->
    <template v-else-if="selectedTool === 'dhke'">
      <div class="mb-6 flex items-center gap-4">
        <button @click="closeTool" class="p-2 hover:bg-white rounded-full transition-colors">
          <ChevronLeft :size="24" />
        </button>
        <h1 class="text-xl font-bold text-gray-900">Diffie–Hellman 密钥交换</h1>
      </div>

      <div class="space-y-6">
        <!-- Key Generation Area -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <div class="flex items-center justify-between mb-6">
            <h3 class="font-bold text-gray-900">我的密钥对</h3>
            <button 
              @click="generateDHKeys"
              class="px-4 py-2 bg-gray-900 text-white rounded-lg text-sm font-bold hover:bg-gray-800 transition-all active:scale-95"
            >
              生成密钥对
            </button>
          </div>
          
          <div class="space-y-4">
            <div>
              <div class="flex items-center justify-between mb-2">
                <label class="text-xs font-bold text-gray-400 uppercase">我的私钥 (Private Key A)</label>
                <button @click="copyToClipboard(dhPrivateKeyA)" class="text-blue-600 hover:text-blue-700 text-xs font-bold">复制</button>
              </div>
              <textarea 
                v-model="dhPrivateKeyA"
                rows="2"
                class="w-full p-3 bg-gray-50 rounded-lg border-none font-mono text-xs resize-none"
                placeholder="在此输入或生成私钥..."
              ></textarea>
            </div>
            <div>
              <div class="flex items-center justify-between mb-2">
                <label class="text-xs font-bold text-gray-400 uppercase">我的公钥 (Public Key A)</label>
                <button @click="copyToClipboard(dhPublicKeyA)" class="text-blue-600 hover:text-blue-700 text-xs font-bold">复制</button>
              </div>
              <textarea 
                v-model="dhPublicKeyA"
                rows="2"
                class="w-full p-3 bg-gray-50 rounded-lg border-none font-mono text-xs resize-none"
                placeholder="在此输入或生成公钥..."
              ></textarea>
            </div>
          </div>
        </div>

        <!-- Other Party's Public Key Area -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <label class="block text-sm font-bold text-gray-500 uppercase tracking-wider mb-4">对方公钥 (Other Party's Public Key)</label>
          <textarea 
            v-model="dhPublicKeyB"
            rows="2"
            class="w-full p-4 bg-gray-50 rounded-xl border-none focus:ring-2 focus:ring-blue-500 transition-all font-mono text-xs resize-none"
            placeholder="在此输入对方提供的公钥..."
          ></textarea>
        </div>

        <!-- Action Button -->
        <button 
          @click="calculateDHSharedSecret"
          class="w-full flex items-center justify-center gap-2 p-4 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-200 active:scale-95"
        >
          <Wrench :size="20" /> 计算共享密钥
        </button>

        <!-- Shared Secret Area -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <div class="flex items-center justify-between mb-4">
            <label class="text-sm font-bold text-gray-500 uppercase tracking-wider">共享密钥 (Shared Key)</label>
            <button @click="copyToClipboard(dhSharedSecret)" class="text-blue-600 hover:text-blue-700 flex items-center gap-1 text-sm font-medium">
              <Copy :size="14" /> 复制
            </button>
          </div>
          <textarea 
            v-model="dhSharedSecret"
            readonly
            rows="2"
            class="w-full p-4 bg-gray-50 rounded-xl border-none font-mono text-sm break-all resize-none"
            placeholder="共享密钥结果将显示在此处..."
          ></textarea>
        </div>

        <!-- Info Card -->
        <div class="bg-blue-50 rounded-2xl p-6 border border-blue-100">
          <div class="flex items-center gap-2 text-blue-800 font-bold mb-3">
            <Info :size="18" />
            <span>DH 密钥交换技术说明</span>
          </div>
          <ul class="space-y-2 text-sm text-blue-700 leading-relaxed">
            <li class="flex gap-2">
              <span class="font-bold">01.</span>
              <span>安全通信：双方通过 DH 算法生成共享密钥，用于后续加密通信。</span>
            </li>
            <li class="flex gap-2">
              <span class="font-bold">02.</span>
              <span>交换流程：A 生成密钥对并将公钥发给 B；B 同样生成密钥对并将公钥发给 A。</span>
            </li>
            <li class="flex gap-2">
              <span class="font-bold">03.</span>
              <span>结果一致：每一方使用自己的私钥和对方的公钥计算共享密钥，结果应完全相同。</span>
            </li>
          </ul>
        </div>
      </div>
    </template>

    <!-- Other Tools Placeholder -->
    <template v-else>
      <div class="mb-6 flex items-center gap-4">
        <button @click="closeTool" class="p-2 hover:bg-white rounded-full transition-colors">
          <ChevronLeft :size="24" />
        </button>
        <h1 class="text-xl font-bold text-gray-900">{{ features.find(f => f.id === selectedTool)?.title }}</h1>
      </div>
      <div class="bg-white rounded-2xl p-12 text-center border border-dashed border-gray-200">
        <p class="text-gray-400">该工具正在开发中...</p>
      </div>
    </template>
  </div>
</template>
