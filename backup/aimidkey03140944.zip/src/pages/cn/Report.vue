<script setup>
import { BarChart2, ExternalLink } from 'lucide-vue-next'

defineProps({
  analysisFeatures: {
    type: Array,
    required: true
  }
})
</script>

<template>
  <div class="max-w-4xl mx-auto px-4 py-6 md:py-12">
    <div class="md:hidden mb-6 text-center">
      <h1 class="text-lg font-bold text-gray-900">分析</h1>
    </div>

    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
      <div class="divide-y divide-gray-50">
        <a 
          v-for="(item, index) in analysisFeatures" 
          :key="index"
          :href="item.url"
          target="_blank"
          class="group flex items-center justify-between p-5 hover:bg-gray-50 transition-colors"
        >
          <div class="flex items-center gap-4">
            <div class="w-10 h-10 bg-orange-50 rounded-xl flex items-center justify-center text-orange-600 group-hover:bg-orange-600 group-hover:text-white transition-all">
              <BarChart2 :size="20" />
            </div>
            <span class="font-medium text-gray-900">{{ item.title }}</span>
          </div>
          <ExternalLink :size="18" class="text-gray-300 group-hover:text-orange-600 transition-colors" />
        </a>
      </div>
    </div>
    
    <div class="mt-8 text-center">
      <p class="text-xs text-gray-400">
        点击条目将跳转至微信公众号查看深度解析文章。
      </p>
    </div>
  </div>
</template>
